#!/bin/bash
# 主控交互菜单，调用 extr../act_snps.sh 和 run_flare.sh

set -euo pipefail

# ========== 配置 ==========
FLARE_JAR="flare.jar"
DATA_DIR="your_project/data"
SUBSET_DIR="your_project/subsets"
RESULT_DIR="your_project/results"
LOG_DIR="your_project/logs"
MASTER_LOG="$LOG_DIR/master.log"
RESULT_FILE="$LOG_DIR/timing_results.txt"
NTHREADS=.
MEM_GB="32"
PYTHON_SCRIPT="your_project/extract_snps.py"  
# 导出环境变量供 generate_report.py 使用
export RESULTS_FILE="$RESULT_FILE"
export PLOT_FILE="$LOG_DIR/timing_plot.png"
export REPORT_FILE="$LOG_DIR/report.md"
# 完整测试 SNP 列表
FULL_SNP_LIST=(1000 5000 10000 25000 50000 75000 100000 150000 200000 250000 300000 400000 500000 600000 700000 796678)
# 快速测试 SNP 列表
QUICK_SNP_LIST=(1000 5000 10000 50000 100000 200000 300000 400000 500000 600000 700000 796678)

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

# ========== 函数 ==========
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1" | tee -a "$MASTER_LOG"
}
log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$MASTER_LOG"
}
log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1" | tee -a "$MASTER_LOG"
}
log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$MASTER_LOG"
}
check_files() {
    local missing=0
    for f in "$FLARE_JAR" "$DATA_DIR/ref.vcf.gz" "$DATA_DIR/sample.vcf.gz" \
             "$DATA_DIR/ref_panel.txt" "$DATA_DIR/your_genetic_map.map"; do
        if [ ! -f "$f" ]; then
            log_error "Missing file: $f"
            missing=1
        fi
    done
    if [ $missing -eq 1 ]; then
        exit 1
    fi
}

run_test() {
    local -n snp_list=$1
    local test_name=$2
    local mode=$(echo "$test_name" | tr '[:upper:]' '[:lower:]')  # Full -> full, Quick -> quick
    log_info "Starting $test_name test (SNPs: ${snp_list[@]})"
    
    # 如果数据尚未生成，调用 Python 脚本生成所有子集（仅第一次）
    if [ ! -d "$DATA_DIR/snp_${snp_list[0]}" ]; then
        log_info "Generating SNP subsets using Python script (mode: $mode)..."
        python3 "$PYTHON_SCRIPT" --mode "$mode"
        if [ $? -ne 0 ]; then
            log_error "Failed to generate SNP subsets."
            exit 1
        fi
    fi
    
    > "$RESULT_FILE"   # 清空结果文件
    for n in "${snp_list[@]}"; do
        TEST_SUBDIR="$DATA_DIR/snp_${n}"
        if [ ! -d "$TEST_SUBDIR" ]; then
            log_error "Subset directory for $n not found: $TEST_SUBDIR"
            continue
        fi
        
        # 确定子集文件路径（与 Python 脚本输出名称一致）
        REF_SUBSET="$TEST_SUBDIR/ref_subset.vcf.gz"
        GT_SUBSET="$TEST_SUBDIR/study_subset.vcf.gz"
        REF_PANEL="$TEST_SUBDIR/ref_panel.txt"
        MAP="$TEST_SUBDIR/genetic_map.txt"
        
        # 检查文件是否存在
        if [ ! -f "$REF_SUBSET" ] || [ ! -f "$GT_SUBSET" ] || [ ! -f "$REF_PANEL" ] || [ ! -f "$MAP" ]; then
            log_error "Missing files for $n SNPs. Skipping."
            continue
        fi
        
        OUT_PREFIX="$RESULT_DIR/run_${n}"
        # 调用 run_flare.sh 并捕获时间输出
        TIME=$(./run_flare.sh "$n" "$REF_SUBSET" "$GT_SUBSET" "$REF_PANEL" "$MAP" \
                               "$OUT_PREFIX" "$NTHREADS" "$MEM_GB")
        echo "$n $TIME" >> "$RESULT_FILE"
    done
    log_info "$test_name test finished. Results saved to $RESULT_FILE"
}

generate_report() {

    if [ ! -f "$RESULT_FILE" ]; then
        log_error "No timing results found. Please run a test first."
        return
    fi
    log_info "Generating report..."
    if python3 generate_report.py --mode report-only; then
        log_success "报告生成完成"
        
        if [[ -f "$REPORT_FILE" ]]; then
            echo ""
            echo "报告摘要:"
            echo "=========================================="
            grep -E "^(测试模式|总测试点|总耗时|最小时间|最大时间)" "$REPORT_FILE" 2>/dev/null || head -10 "$REPORT_FILE"
            echo "=========================================="
        fi
    else
        log_error "报告生成失败"
        return 1
    fi
}

clean_data() {
    log_warn "Cleaning up test data..."
    rm -rf "$SUBSET_DIR" "$RESULT_DIR" "$LOG_DIR/flare_"*.log
    log_info "Cleanup completed. Removed subset VCFs, result directories, and flare logs."
}

# ========== 主菜单 ==========
main_menu() {
    echo "=========================================="
    echo "        Flare Performance Test Suite      "
    echo "=========================================="
    echo "1) Full test (all SNP counts)"
    echo "2) Quick test (reduced SNP counts)"
    echo "3) Generate data report (plot)"
    echo "4) Clean test data"
    echo "5) Exit"
    echo "=========================================="
    read -p "Choose an option [1-5]: " choice
    case $choice in
        1) run_test FULL_SNP_LIST "Full" ;;
        2) run_test QUICK_SNP_LIST "Quick" ;;
        3) generate_report ;;
        4) clean_data ;;
        5) exit 0 ;;
        *) log_error "Invalid option"; main_menu ;;
    esac
}

# ========== 初始化 ==========
mkdir -p "$SUBSET_DIR" "$RESULT_DIR" "$LOG_DIR"
touch "$MASTER_LOG"
check_files
main_menu
