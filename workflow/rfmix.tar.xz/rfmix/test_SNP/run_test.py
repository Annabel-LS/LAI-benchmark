#!/usr/bin/env python3
# run_test.py
# 功能：执行 RFMIX 测试，记录运行时间

import subprocess
import time
import os
import sys

def run_rmix_test(snp_list, mode, base_output_dir="rfmix_results"):
    """
    执行 RFMIX 测试
    """
    os.makedirs(base_output_dir, exist_ok=True)
    log_file = os.path.join(base_output_dir, f"timing_{mode}.tsv")
    
    with open(log_file, 'w') as f:
        f.write("SNP_Count\tTime_Seconds\tStatus\n")

    # 基础路径配置 (请修改为你的实际路径)
    BASE_DIR = "your_project"
    GEN_MAP_BASE = os.path.join(BASE_DIR, "genetic_map.loca")
    POP_MAP_FILE = os.path.join(BASE_DIR, "your_ref-panel.txt") # --m 参数
    
    # 注意：-G 16 (Expectation-Maximization steps) 和 --chromosome=1 保持不变
    # -G 16 可能会增加计算量，用于测试性能

    for snp_count in snp_list:
        # 构建输入路径 (对应 split_snp.sh 的输出)
        target_vcf = f"sliced_datasets/target_{snp_count}.vcf.gz"
        ref_vcf = f"sliced_datasets/ref_{snp_count}.vcf.gz"
        
        # 检查切分后的文件是否存在
        if not (os.path.exists(target_vcf) and os.path.exists(ref_vcf)):
            print(f"警告: 文件缺失: {target_vcf} 或 {ref_vcf}, 跳过...")
            with open(log_file, 'a') as f:
                f.write(f"{snp_count}\t0\tMISSING_FILE\n")
            continue
        
        # 构建输出前缀
        output_prefix = os.path.join(base_output_dir, f"rfmix_out_{snp_count}")
        
        # 构建命令 (完全按照你提供的格式)
        cmd = [
            "your_project",
            "-f", target_vcf,
            "-r", ref_vcf,
            "-m", POP_MAP_FILE,      # 注意：这里假设 ref_panel.txt 是通用的
            "-g", GEN_MAP_BASE,     # 注意：这里未切分 map，如果 SNP 少，可能需要切分 map 文件
            "-o", output_prefix,
            "--chromosome=1",       # 假设所有测试都是 chr1
            "-G", "16",             # EM steps
            "--n-threads=#"
        ]
        
        print(f"运行命令: {' '.join(cmd)}")
        start_time = time.time()
        
        try:
            # 运行命令
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            elapsed = time.time() - start_time
            
            print(f"成功: {snp_count} SNPs, 耗时: {elapsed:.2f} 秒")
            with open(log_file, 'a') as f:
                f.write(f"{snp_count}\t{elapsed}\tSUCCESS\n")
                
        except subprocess.CalledProcessError as e:
            print(f"失败: {snp_count} SNPs, 错误: {e}")
            print(f"标准错误输出: {e.stderr}")
            with open(log_file, 'a') as f:
                f.write(f"{snp_count}\t-1\tERROR\n")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "quick":
        gradients = [1000, 5000, 10000, 50000, 100000, 200000, 300000, 400000, 500000, 600000, 700000, 796678]
        run_rmix_test(gradients, "quick")
    else:
        gradients = [1000, 5000, 10000, 25000, 50000, 75000, 100000, 150000, 200000, 250000, 300000, 400000, 500000, 600000, 700000, 796678]
        run_rmix_test(gradients, "full")
