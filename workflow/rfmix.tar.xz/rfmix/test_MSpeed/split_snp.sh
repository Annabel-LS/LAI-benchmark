#!/bin/bash
# split_snp.sh
# 功能：针对 VCF.GZ 格式，切分指定数量的 SNP

# --- 配置区域 (请根据实际情况修改) ---
# 你的原始目标文件 (Target VCF)
ORIGINAL_TARGET_VCF="sample.gz" # 例如: /path/to/01_ancestry.vcf.gz
# 你的原始参考文件 (Reference VCF)
ORIGINAL_REF_VCF="ref.vcf.gz"  # 例如: /path/to/CHS_..._de.vcf.gz
# 遗传图谱文件 (保持不变，不需要切分)
GEN_MAP_FILE="your_genetic_map.loca"      # 例如: /path/to/plink.chr1.GRCh38.loca

# 输出目录
OUTPUT_DIR="sliced_datasets"
mkdir -p $OUTPUT_DIR

# --- 函数：切分 VCF ---
# $1: 原始 VCF.GZ 文件
# $2: 输出文件名 (不含 .gz)
# $3: SNP 数量
slice_vcf() {
    local input_vcf=$1
    local output_prefix=$2
    local snp_num=$3

    echo "处理: 从 $input_vcf 中提取前 $snp_num 个 SNP 到 $output_prefix"

    # 1. 解压并读取 header (以 '#' 开头的行)
    # 2. 使用 awk 提取数据行，直到达到指定的 SNP 数量
    # 3. 重新压缩
    zcat "$input_vcf" | awk -v limit="$snp_num" '
    BEGIN { snp_count = 0; }
    /^#/ { 
        # 打印 header 行
        print; 
        next; 
    }
    {
        if (snp_count < limit) {
            print;
            snp_count++;
        } else {
            # 达到限制后退出，提高大文件效率
            exit;
        }
    }' | bgzip -c > "${output_prefix}.vcf.gz"

    # 建立索引 (RFMIX 可能需要，或者 plink 处理时需要)
    if [ -f "${output_prefix}.vcf.gz" ]; then
        tabix -p vcf "${output_prefix}.vcf.gz"
    fi
}

# --- 主逻辑 ---
case "$1" in
    "quick")
        GRADIENTS=(1000 5000 10000 50000 100000 200000 300000 400000 500000 600000 700000 796678)
        ;;
    "full")
        GRADIENTS=(1000 5000 10000 25000 50000 75000 100000 150000 200000 250000 300000 400000 500000 600000 700000 796678)
        ;;
    *)
        echo "用法: $0 [quick|full]"
        exit 1
        ;;
esac

# 执行切分
for snp_count in "${GRADIENTS[@]}"; do
    # 生成输出前缀
    TARGET_OUT="${OUTPUT_DIR}/target_${snp_count}"
    REF_OUT="${OUTPUT_DIR}/ref_${snp_count}"
    
    # 切分目标文件
    slice_vcf "$ORIGINAL_TARGET_VCF" "$TARGET_OUT" $snp_count
    # 切分参考文件 (确保 SNP 数量一致)
    slice_vcf "$ORIGINAL_REF_VCF" "$REF_OUT" $snp_count
    
    # 复制遗传图谱文件 (假设图谱文件是按染色体分的，且我们只测试 chr1)
    # 注意：这里假设你的 map 文件前缀是 plink.chr1...
    # 你需要根据 snp_count 创建对应的 map 目录结构，或者脚本中动态处理
    # 简化处理：我们假设 map 文件不需要按 SNP 切分，或者你有一个通用的 chr1 map
    # 如果必须切分 map 文件，需要更复杂的逻辑（根据 VCF 中的 POS 列过滤）
done

echo "所有切分任务完成。数据位于 $OUTPUT_DIR/"
