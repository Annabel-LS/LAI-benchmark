#!/bin/bash
# master.sh

echo "=================================="
echo "   RFMIX VCF 性能测试框架         "
echo "=================================="

while true; do
    echo ""
    echo "1) 快速测试 (Quick Test)"
    echo "2) 完整测试 (Full Test)"
    echo "3) 生成报告 (需先运行测试)"
    echo "0) 退出"
    read -p "选择: " opt

    case $opt in
        1)
            echo "开始快速测试..."
            # 步骤1: 切分数据
            bash split_snp.sh quick
            # 步骤2: 运行测试
            python3 run_test.py quick
            ;;
        2)
            echo "开始完整测试..."
            bash split_snp.sh full
            python3 run_test.py full
            ;;
        3)
                
            echo -e "${GREEN}生成数据报告 (Generate Report)${NC}"
            # 提示用户选择模式
            echo "请选择要生成报告的模式:"
            echo "1) 快速测试 (Quick)"
            echo "2) 完整测试 (Full)"
            echo "3) 两者都生成"
            read -p "选择: " report_opt
            
            case $report_opt in
                1)
                    python3 generate_report.py quick
                    ;;
                2)
                    python3 generate_report.py full
                    ;;
                3)
                    python3 generate_report.py quick
                    python3 generate_report.py full
                    ;;
                *)
                    echo "无效选择"
                    ;;
            esac
            ;;
        0)
            exit 0
            ;;
    esac
done
