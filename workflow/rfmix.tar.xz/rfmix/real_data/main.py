#!/usr/bin/env python3
"""
RFMIX v2 自动化流水线 - 主程序
功能：复制文件 → 创建参考面板标签 → 运行 RFMIX（先对照组后实验组） → 转换 LOCA
"""

import os
import subprocess
import sys
import shutil
import logging
from datetime import datetime

# ========== 用户配置区域 ==========
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = CURRENT_DIR
GENETIC_MAP_DIR = os.path.join(PROJECT_DIR, "plink.GRCh38.map_Rfmix_input")
GENETIC_MAP_PATTERN = "plink.chr{chr}.GRCh38.loca"

SOURCE_DATA_DIR = "your_real_data"

CHROMOSOMES = list(range(1, 23))

CONTROL_RANGES = "CHS:1-160 CEU:161-336 YRI:337-511"
EXPERIMENT_RANGES = "CHS:1-160 CEU:161-336"

QUERY_VCF_PATTERN = "sample_chr{chr}.vcf.gz"
REF_CONTROL_VCF_PATTERN = "ref_chr{chr}.vcf.gz"
REF_EXPERIMENT_VCF_PATTERN = "ref_experiment.vcf.gz"
PHASED_PATTERN = "sample_chr{chr}.phased"

CREATE_REF_SCRIPT = os.path.join(PROJECT_DIR, "scripts", "create_rfmix_ref.py")
CONVERT_SCRIPT = os.path.join(PROJECT_DIR, "scripts", "RfmixResult_to_loca.py")

RFMIX_BIN = "your_project"
RFMIX_OPTIONS = "--n-threads="

MAIN_LOG = os.path.join(CURRENT_DIR, "main.log")
# ===================================

# 检查必需脚本
for script in [CREATE_REF_SCRIPT, CONVERT_SCRIPT]:
    if not os.path.exists(script):
        sys.stderr.write(f"错误: 缺少脚本 {script}\n")
        sys.exit(1)

# 设置主日志
def setup_main_logger():
    logger = logging.getLogger('main')
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(MAIN_LOG, mode='a', encoding='utf-8')
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

logger = setup_main_logger()

def run_cmd(cmd, description, log_file, dry_run=False):
    logger.info(f"执行: {description}")
    logger.info(f"命令: {cmd}")
    if dry_run:
        logger.info("[DRY RUN] 跳过实际执行")
        return True
    try:
        with open(log_file, 'w', encoding='utf-8') as log_f:
            proc = subprocess.Popen(cmd, shell=True, stdout=log_f, stderr=subprocess.STDOUT, text=True)
            proc.wait()
            if proc.returncode == 0:
                logger.info(f"{description} 成功完成 (日志: {log_file})")
                return True
            else:
                logger.error(f"{description} 失败，返回码 {proc.returncode} (日志: {log_file})")
                return False
    except Exception as e:
        logger.error(f"{description} 异常: {e}")
        return False

def select_chromosomes():
    logger.info("用户选择染色体")
    print("\n可用的染色体: 1-22")
    choice = input("请输入染色体编号（单个: 5, 多个用逗号: 1,3,5, 范围: 1-5, 或'all'）: ").strip()
    if choice.lower() == 'all':
        return CHROMOSOMES
    selected = []
    for part in choice.split(','):
        part = part.strip()
        if '-' in part:
            a, b = map(int, part.split('-'))
            selected.extend(range(a, b+1))
        else:
            if part:
                selected.append(int(part))
    selected = sorted(set(selected))
    selected = [c for c in selected if c in CHROMOSOMES]
    if not selected:
        logger.warning("未选择有效染色体，使用全部")
        return CHROMOSOMES
    logger.info(f"选择的染色体: {selected}")
    return selected

def select_group():
    logger.info("用户选择运行方向")
    print("\n运行方向选择:")
    print("1. 仅运行对照组参考 (Control Reference)")
    print("2. 仅运行实验组参考 (Experiment Reference)")
    print("3. 两者均运行（先对照组后实验组）")
    g = input("请输入数字 (1/2/3): ").strip()
    if g == '1':
        run_modes = ['control']
    elif g == '2':
        run_modes = ['experiment']
    else:
        run_modes = ['control', 'experiment']
    logger.info(f"选择的运行方向: {run_modes}")
    return run_modes

def select_operation():
    logger.info("用户选择操作")
    print("\n操作选择:")
    print("1. 全流程 (复制 → 建标签 → 运行RFMIX → 转换)")
    print("2. 仅复制文件")
    print("3. 仅创建参考面板标签 (.pop_labels)")
    print("4. 仅运行 RFMIX")
    print("5. 仅转换结果 (.loca)")
    print("6. 自定义步骤组合")
    op = input("请输入数字: ").strip()
    logger.info(f"选择的操作: {op}")
    return op

def custom_steps():
    steps = []
    print("\n请依次输入要执行的步骤（输入字母，完成后直接回车）:")
    print("  a. 复制文件")
    print("  b. 创建参考面板标签")
    print("  c. 运行 RFMIX")
    print("  d. 转换结果")
    while True:
        s = input("步骤 (a/b/c/d，直接回车结束): ").strip().lower()
        if not s:
            break
        if s in ['a','b','c','d']:
            steps.append(s)
        else:
            print("无效输入，请输入 a/b/c/d")
    logger.info(f"自定义步骤: {steps}")
    return steps

def get_paths(chr_num):
    chr_dir = os.path.join(PROJECT_DIR, f"chr{chr_num}")
    log_dir = os.path.join(chr_dir, "logs")
    results_dir = os.path.join(chr_dir, "results")
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    paths = {
        'dir': chr_dir,
        'log_dir': log_dir,
        'results_dir': results_dir,
        'query_vcf': os.path.join(chr_dir, "query.vcf.gz"),
        'ref_control_vcf': os.path.join(chr_dir, "ref_control.vcf.gz"),
        'ref_experiment_vcf': os.path.join(chr_dir, "ref_experiment.vcf.gz"),
        'phased_file': os.path.join(chr_dir, "query.phased"),
        'genetic_map': os.path.join(GENETIC_MAP_DIR, GENETIC_MAP_PATTERN.format(chr=chr_num)),
        'control_labels': os.path.join(chr_dir, "control.pop_labels"),
        'experiment_labels': os.path.join(chr_dir, "experiment.pop_labels"),
        'control_out_prefix': os.path.join(results_dir, "control_ref"),
        'experiment_out_prefix': os.path.join(results_dir, "experiment_ref"),
        'control_loca': os.path.join(results_dir, "control_ref.loca"),
        'experiment_loca': os.path.join(results_dir, "experiment_ref.loca"),
    }
    return paths

def step_copy_files(chr_num, paths, dry_run=False):
    logger.info(f"开始复制文件: 染色体 {chr_num}")
    src_chr_dir = os.path.join(SOURCE_DATA_DIR, f"chr{chr_num}")
    if not os.path.isdir(src_chr_dir):
        logger.error(f"源染色体目录不存在: {src_chr_dir}")
        return False
    os.makedirs(paths['dir'], exist_ok=True)

    files_to_copy = [
        (paths['query_vcf'], QUERY_VCF_PATTERN.format(chr=chr_num)),
        (paths['ref_control_vcf'], REF_CONTROL_VCF_PATTERN.format(chr=chr_num)),
        (paths['ref_experiment_vcf'], REF_EXPERIMENT_VCF_PATTERN.format(chr=chr_num)),
        (paths['phased_file'], PHASED_PATTERN.format(chr=chr_num)),
    ]

    for dst, src_filename in files_to_copy:
        src = os.path.join(src_chr_dir, src_filename)
        if not os.path.exists(src):
            logger.error(f"源文件不存在: {src}")
            return False
        if os.path.exists(dst):
            logger.info(f"目标文件已存在，跳过复制: {dst}")
            continue
        logger.info(f"复制: {src} -> {dst}")
        if not dry_run:
            try:
                shutil.copy2(src, dst)
            except Exception as e:
                logger.error(f"复制失败: {e}")
                return False

    # 为 VCF 文件建立索引（如果缺失）
    if not dry_run:
        for vcf in [paths['query_vcf'], paths['ref_control_vcf']]:
            if os.path.exists(vcf) and vcf.endswith('.gz'):
                idx_file = vcf + '.tbi'
                if not os.path.exists(idx_file):
                    logger.info(f"为 {vcf} 建立 tabix 索引")
                    subprocess.run(f"tabix -p vcf {vcf}", shell=True, check=False)
        if os.path.exists(paths['ref_experiment_vcf']):
            idx_file = paths['ref_experiment_vcf'] + '.csi'
            if not os.path.exists(idx_file):
                logger.info(f"为 {paths['ref_experiment_vcf']} 建立 bcftools 索引")
                subprocess.run(f"bcftools index {paths['ref_experiment_vcf']}", shell=True, check=False)

    logger.info(f"染色体 {chr_num} 复制完成")
    return True

def step_create_ref_panels(chr_num, paths, run_modes, dry_run=False):
    logger.info(f"创建参考面板标签: 染色体 {chr_num}")
    mode_config = {
        'control': {
            'vcf': paths['ref_control_vcf'],
            'labels': paths['control_labels'],
            'ranges': CONTROL_RANGES,
            'name': '对照组'
        },
        'experiment': {
            'vcf': paths['ref_experiment_vcf'],
            'labels': paths['experiment_labels'],
            'ranges': EXPERIMENT_RANGES,
            'name': '实验组'
        }
    }
    for mode in run_modes:
        cfg = mode_config[mode]
        if os.path.exists(cfg['labels']):
            logger.info(f"{cfg['name']} 标签文件已存在，跳过: {cfg['labels']}")
            continue
        log_file = os.path.join(paths['log_dir'], f"create_labels_{mode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        cmd = f"python {CREATE_REF_SCRIPT} --vcf {cfg['vcf']} --ranges \"{cfg['ranges']}\" --output {cfg['labels']}"
        if not run_cmd(cmd, f"创建 {cfg['name']} 标签文件", log_file, dry_run):
            return False
    return True

def step_run_rfmix(chr_num, paths, run_modes, dry_run=False):
    logger.info(f"运行 RFMIX: 染色体 {chr_num}")
    for f in [paths['query_vcf'], paths['genetic_map']]:
        if not os.path.exists(f):
            logger.error(f"必要文件不存在: {f}")
            return False

    mode_config = {
        'control': {
            'ref_vcf': paths['ref_control_vcf'],
            'ref_labels': paths['control_labels'],
            'out_prefix': paths['control_out_prefix'],
            'name': '对照组参考'
        },
        'experiment': {
            'ref_vcf': paths['ref_experiment_vcf'],
            'ref_labels': paths['experiment_labels'],
            'out_prefix': paths['experiment_out_prefix'],
            'name': '实验组参考'
        }
    }

    for mode in run_modes:
        cfg = mode_config[mode]
        if not os.path.exists(cfg['ref_vcf']):
            logger.error(f"参考VCF不存在: {cfg['ref_vcf']}")
            return False
        if not os.path.exists(cfg['ref_labels']):
            logger.error(f"标签文件不存在: {cfg['ref_labels']}")
            return False

        msp_output = f"{cfg['out_prefix']}.msp.tsv"
        if os.path.exists(msp_output):
            logger.info(f"RFMIX 输出已存在，跳过: {msp_output}")
            continue

        log_file = os.path.join(paths['log_dir'], f"rfmix_{mode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        # 添加 -c 参数指定染色体
        cmd = (f"{RFMIX_BIN} -f {paths['query_vcf']} -r {cfg['ref_vcf']} "
       f"-g {paths['genetic_map']} -m {cfg['ref_labels']} "
       f"-o {cfg['out_prefix']} --chromosome={chr_num} {RFMIX_OPTIONS}")
       
        if not run_cmd(cmd, f"RFMIX ({cfg['name']})", log_file, dry_run):
            return False
    return True

def step_convert_to_loca(chr_num, paths, run_modes, dry_run=False):
    logger.info(f"转换结果: 染色体 {chr_num}")
    if not os.path.exists(paths['phased_file']):
        logger.error(f"phased 文件不存在: {paths['phased_file']}")
        return False

    mode_config = {
        'control': {
            'msp_file': f"{paths['control_out_prefix']}.msp.tsv",
            'loca_file': paths['control_loca'],
            'name': '对照组参考'
        },
        'experiment': {
            'msp_file': f"{paths['experiment_out_prefix']}.msp.tsv",
            'loca_file': paths['experiment_loca'],
            'name': '实验组参考'
        }
    }

    for mode in run_modes:
        cfg = mode_config[mode]
        if not os.path.exists(cfg['msp_file']):
            logger.warning(f"{cfg['name']} 的 .msp.tsv 不存在，跳过转换: {cfg['msp_file']}")
            continue
        if os.path.exists(cfg['loca_file']):
            logger.info(f"{cfg['name']} 的 .loca 已存在，跳过: {cfg['loca_file']}")
            continue

        log_file = os.path.join(paths['log_dir'], f"convert_{mode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        cmd = f"python {CONVERT_SCRIPT} -I1 {paths['phased_file']} -I2 {cfg['msp_file']} -O {cfg['loca_file']}"
        if not run_cmd(cmd, f"转换 {cfg['name']} 结果到 LOCA", log_file, dry_run):
            return False
    return True

def main():
    global SOURCE_DATA_DIR, GENETIC_MAP_DIR
    # 检查 RFMIX 可执行性
    if not os.path.exists(RFMIX_BIN):
        logger.error(f"RFMIX 可执行文件不存在: {RFMIX_BIN}")
        sys.exit(1)
    if not os.access(RFMIX_BIN, os.X_OK):
        logger.error(f"RFMIX 文件没有执行权限，请运行: chmod +x {RFMIX_BIN}")
        sys.exit(1)

    logger.info("="*60)
    logger.info("RFMIX v2 自动化流水线启动")
    logger.info("="*60)

    logger.info(f"当前源数据目录: {SOURCE_DATA_DIR}")
    change_src = input("是否修改源数据目录？(y/N): ").strip().lower()
    if change_src == 'y':
        new_src = input("请输入新的源数据目录路径: ").strip()
        if os.path.isdir(new_src):
            SOURCE_DATA_DIR = new_src
            logger.info(f"源数据目录已更新: {SOURCE_DATA_DIR}")
        else:
            logger.warning("目录无效，保持原有设置")

    logger.info(f"当前遗传图谱目录: {GENETIC_MAP_DIR}")
    change_map = input("是否修改遗传图谱目录？(y/N): ").strip().lower()
    if change_map == 'y':
        new_map = input("请输入新的遗传图谱目录路径: ").strip()
        if os.path.isdir(new_map):
            GENETIC_MAP_DIR = new_map
            logger.info(f"遗传图谱目录已更新: {GENETIC_MAP_DIR}")
        else:
            logger.warning("目录无效，保持原有设置")

    chrs = select_chromosomes()
    run_modes = select_group()
    op = select_operation()

    if op == '1':
        steps = ['copy', 'create_ref', 'run', 'convert']
    elif op == '2':
        steps = ['copy']
    elif op == '3':
        steps = ['create_ref']
    elif op == '4':
        steps = ['run']
    elif op == '5':
        steps = ['convert']
    elif op == '6':
        steps_codes = custom_steps()
        step_map = {'a':'copy', 'b':'create_ref', 'c':'run', 'd':'convert'}
        steps = [step_map[s] for s in steps_codes if s in step_map]
        if not steps:
            logger.warning("未选择任何步骤，退出")
            return
    else:
        logger.error("无效选择，退出")
        return

    dry = input("\n是否仅预览命令而不执行？(y/N): ").strip().lower() == 'y'
    if dry:
        logger.info("DRY RUN 模式：仅预览，不实际执行")

    for chr_num in chrs:
        logger.info(f"===== 开始处理染色体 {chr_num} =====")
        paths = get_paths(chr_num)

        if 'copy' not in steps:
            missing = []
            for key in ['query_vcf', 'ref_control_vcf', 'ref_experiment_vcf', 'phased_file']:
                if not os.path.exists(paths[key]):
                    missing.append(paths[key])
            if missing:
                logger.warning(f"缺少文件: {missing}")
                cont = input("是否继续？(y/N): ").strip().lower()
                if cont != 'y':
                    continue

        success = True
        for step in steps:
            if step == 'copy':
                success = step_copy_files(chr_num, paths, dry)
            elif step == 'create_ref':
                success = step_create_ref_panels(chr_num, paths, run_modes, dry)
            elif step == 'run':
                success = step_run_rfmix(chr_num, paths, run_modes, dry)
            elif step == 'convert':
                success = step_convert_to_loca(chr_num, paths, run_modes, dry)
            if not success:
                logger.error(f"染色体 {chr_num} 处理失败，停止后续步骤")
                break
        if success:
            logger.info(f"染色体 {chr_num} 处理完成")
        else:
            logger.error(f"染色体 {chr_num} 处理失败")

    logger.info("所有任务结束")
    print("\n主程序日志已保存至:", MAIN_LOG)

if __name__ == "__main__":
    main()
