#!/usr/bin/env python3
import subprocess
import argparse
import sys

def parse_ranges(ranges_str):
    """解析 'CHS:1-160 CEU:161-336' 格式，返回 dict {pop: (start, end)}"""
    ranges = {}
    for item in ranges_str.split():
        pop, idx_range = item.split(':')
        start, end = map(int, idx_range.split('-'))
        ranges[pop] = (start, end)
    return ranges

def create_ref_panel(vcf_path, ranges, output_path):
    # 提取样本列表
    cmd = ["bcftools", "query", "-l", vcf_path]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(f"Error: bcftools failed: {proc.stderr}\n")
        return False
    samples = [s.strip() for s in proc.stdout.splitlines() if s.strip()]
    total = len(samples)

    # 检查范围有效性
    assigned = {}
    for pop, (start, end) in ranges.items():
        if end > total:
            sys.stderr.write(f"Error: {pop} range {end} > total samples {total}\n")
            return False
        for idx in range(start-1, end):
            samp = samples[idx]
            if samp in assigned:
                sys.stderr.write(f"Warning: {samp} already assigned to {assigned[samp]}, overwriting with {pop}\n")
            assigned[samp] = pop

    # 写入输出文件
    with open(output_path, 'w') as f:
        for samp in samples:
            if samp in assigned:
                f.write(f"{samp}\t{assigned[samp]}\n")
    print(f"Generated {output_path} with {len(assigned)} samples")
    return True

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--vcf", required=True, help="Input VCF file")
    parser.add_argument("--ranges", required=True, help='e.g., "CHS:1-160 CEU:161-336 YRI:337-511"')
    parser.add_argument("--output", required=True, help="Output map file")
    args = parser.parse_args()
    ranges = parse_ranges(args.ranges)          # 解析为字典
    success = create_ref_panel(args.vcf, ranges, args.output)  # 传入字典
    sys.exit(0 if success else 1)
