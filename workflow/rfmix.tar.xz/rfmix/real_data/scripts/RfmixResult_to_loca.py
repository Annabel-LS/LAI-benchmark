#!/usr/bin/env python3
"""
Rfmix结果转化loca格式

使用方法：
python3 RfmixResult_to_loca.py -I1 chr5.hap -I2 chr5.msp -O output.loca

或：
python3 RfmixResult_to_loca.py \
  -I1 "merged_sample_chr1.phased"【单倍型文件路径】\
  -I2 "chr1_Result.msp.tsv"【Rfmix文件路径】\
  -O "chr1_output.loca"【输出文件路径】

  python3 RfmixResult_to_loca.py \
  -I1 "sample.phased"\
  -I2 "result_.msp.tsv"\
  -O "output.loca"
"""

import os
import sys
import bisect
import argparse


def convert_single_file(hap_file, rfmix_file, output_file):
    intervals = []
    with open(rfmix_file) as f:
        for _ in range(2):
            next(f)

        for line in f:
            cols = line.strip().split()
            if len(cols) >= 8:
                try:
                    intervals.append({
                        'start': float(cols[1]),
                        'end': float(cols[2]),
                        'data': [str(int(x) + 1) if x.isdigit() else x
                                 for x in cols[6:len(cols)]]
                    })
                except (ValueError, IndexError):
                    continue

    intervals.sort(key=lambda x: x['start'])
    start_positions = [x['start'] for x in intervals]

    with open(hap_file) as fin, open(output_file, 'w') as fout:
        header = fin.readline().strip()
        fout.write(header + "\n")

        processed = 0
        for line in fin:
            cols = line.strip().split()
            if len(cols) < 2:
                continue

            try:
                pos = float(cols[1])
                idx = bisect.bisect_right(start_positions, pos) - 1

                if idx >= 0 and intervals[idx]['start'] <= pos <= intervals[idx]['end']:
                    merged_data = cols[:2] + intervals[idx]['data']
                    fout.write("\t".join(merged_data) + "\n")
                    processed += 1
            except ValueError:
                continue


def main():
    parser = argparse.ArgumentParser(description='Rfmix结果转化loca格式')
    parser.add_argument('-I1', '--input1', required=True, help='单倍型文件路径')
    parser.add_argument('-I2', '--input2', required=True, help='RFmix文件路径')
    parser.add_argument('-O', '--output', required=True, help='输出文件路径')

    args = parser.parse_args()

    convert_single_file(args.input1, args.input2, args.output)


if __name__ == "__main__":
    main()
