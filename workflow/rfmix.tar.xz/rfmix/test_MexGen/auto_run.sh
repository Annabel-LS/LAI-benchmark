#!/bin/bash
# batch_rfmix.sh - 批量运行RFMIX分析脚本

# 基础配置
BASE_DIR="your_project"
PROJECT_DIR="$BASE_DIR/project"
INPUT_DIR="$PROJECT_DIR/input_files"
OUTPUT_DIR="$PROJECT_DIR/output"
RFMIX_PATH="$BASE_DIR/rfmix"

# 输入文件定义
REFERENCE_FILE="$INPUT_DIR/CHS_YRI.vcf.gz"
GENETIC_MAP="$INPUT_DIR/your_genetic_map.loca"
REF_PANEL="$INPUT_DIR/ref-panel.txt"

# 待分析样本列表（根据你的实际情况修改）
SAMPLE_FILES=(
    "40_ancestry.vcf.gz"
    "60_ancestry.vcf.gz" 
    "80_ancestry.vcf.gz"
    "100_ancestry.vcf.gz"
)

# 参数配置
CHROMOSOME="1"
GENERATIONS="16"
THREADS="."

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 检查目录和文件
check_environment() {
    echo -e "${BLUE}检查环境和文件...${NC}"
    
    # 检查项目目录
    if [ ! -d "$PROJECT_DIR" ]; then
        echo -e "${YELLOW}创建项目目录: $PROJECT_DIR${NC}"
        mkdir -p "$PROJECT_DIR"
    fi
    
    # 检查输入目录
    if [ ! -d "$INPUT_DIR" ]; then
        echo -e "${RED}错误: 输入目录不存在: $INPUT_DIR${NC}"
        echo "请确保所有输入文件在正确位置"
        return 1
    fi
    
    # 检查输出目录
    if [ ! -d "$OUTPUT_DIR" ]; then
        echo -e "${YELLOW}创建输出目录: $OUTPUT_DIR${NC}"
        mkdir -p "$OUTPUT_DIR"
    fi
    
    # 检查RFMIX可执行文件
    if [ ! -f "$RFMIX_PATH" ]; then
        echo -e "${RED}错误: 未找到rfmix可执行文件${NC}"
        echo "请确保rfmix在: $RFMIX_PATH"
        return 1
    fi
    
    # 检查参考文件
    if [ ! -f "$REFERENCE_FILE" ]; then
        echo -e "${RED}错误: 未找到参考文件: $REFERENCE_FILE${NC}"
        return 1
    fi
    
    # 检查遗传图谱
    if [ ! -f "$GENETIC_MAP" ]; then
        echo -e "${RED}错误: 未找到遗传图谱: $GENETIC_MAP${NC}"
        return 1
    fi
    
    # 检查参考面板
    if [ ! -f "$REF_PANEL" ]; then
        echo -e "${RED}错误: 未找到参考面板: $REF_PANEL${NC}"
        return 1
    fi
    
    # 检查待分析样本
    missing_samples=()
    for sample in "${SAMPLE_FILES[@]}"; do
        sample_path="$INPUT_DIR/$sample"
        if [ ! -f "$sample_path" ]; then
            missing_samples+=("$sample")
        fi
    done
    
    if [ ${#missing_samples[@]} -gt 0 ]; then
        echo -e "${YELLOW}警告: 以下待分析样本未找到:${NC}"
        for missing in "${missing_samples[@]}"; do
            echo "  - $missing"
        done
        echo "是否继续? (y/N): "
        read -p "" confirm
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            return 1
        fi
    fi
    
    echo -e "${GREEN}环境检查完成✓${NC}"
    return 0
}

# 显示配置信息
show_config() {
    echo "=========================================="
    echo "       RFMIX批量分析配置信息"
    echo "=========================================="
    echo ""
    echo "项目目录: $PROJECT_DIR"
    echo "参考文件: $(basename $REFERENCE_FILE)"
    echo "遗传图谱: $(basename $GENETIC_MAP)"
    echo "参考面板: $(basename $REF_PANEL)"
    echo "染色体: $CHROMOSOME"
    echo "世代数: $GENERATIONS"
    echo "线程数: $THREADS"
    echo ""
    echo "待分析样本 (${#SAMPLE_FILES[@]}个):"
    for i in "${!SAMPLE_FILES[@]}"; do
        sample_path="$INPUT_DIR/${SAMPLE_FILES[$i]}"
        if [ -f "$sample_path" ]; then
            status="✓"
        else
            status="✗"
        fi
        echo "  $((i+1)). ${SAMPLE_FILES[$i]} $status"
    done
    echo ""
    echo "=========================================="
}

# 运行单个样本分析
run_single_analysis() {
    local sample_file=$1
    local sample_name=$(basename "$sample_file" .vcf.gz)
    local query_file="$INPUT_DIR/$sample_file"
    local output_prefix="$OUTPUT_DIR/${sample_name}_output"
    local log_file="$OUTPUT_DIR/${sample_name}.log"
    
    echo -e "${BLUE}分析样本: $sample_name${NC}"
    
    # 检查样本文件是否存在
    if [ ! -f "$query_file" ]; then
        echo -e "${RED}错误: 样本文件不存在: $query_file${NC}"
        return 1
    fi
    
    # 开始时间
    local start_time=$(date +%s.%N)
    
    echo "开始运行RFMIX..." | tee "$log_file"
    echo "================================" | tee -a "$log_file"
    echo "分析时间: $(date)" | tee -a "$log_file"
    echo "样本文件: $sample_file" | tee -a "$log_file"
    echo "输出前缀: $output_prefix" | tee -a "$log_file"
    echo "================================" | tee -a "$log_file"
    
    # 运行RFMIX
    echo -e "${BLUE}执行命令:${NC}"
    echo "$RFMIX_PATH \\" | tee -a "$log_file"
    echo "  -f $query_file \\" | tee -a "$log_file"
    echo "  -r $REFERENCE_FILE \\" | tee -a "$log_file"
    echo "  -m $REF_PANEL \\" | tee -a "$log_file"
    echo "  -g $GENETIC_MAP \\" | tee -a "$log_file"
    echo "  -o $output_prefix \\" | tee -a "$log_file"
    echo "  --chromosome=$CHROMOSOME \\" | tee -a "$log_file"
    echo "  -G $GENERATIONS \\" | tee -a "$log_file"
    echo "  --n-threads=$THREADS" | tee -a "$log_file"
    echo "" | tee -a "$log_file"
    
    # 执行命令
    "$RFMIX_PATH" \
        -f "$query_file" \
        -r "$REFERENCE_FILE" \
        -m "$REF_PANEL" \
        -g "$GENETIC_MAP" \
        -o "$output_prefix" \
        --chromosome="$CHROMOSOME" \
        -G "$GENERATIONS" \
        --n-threads="$THREADS" 2>&1 | tee -a "$log_file"
    
    local exit_code=${PIPESTATUS[0]}
    
    # 结束时间
    local end_time=$(date +%s.%N)
    local runtime=$(echo "$end_time - $start_time" | bc)
    
    # 记录结果
    echo "================================" | tee -a "$log_file"
    echo "结束时间: $(date)" | tee -a "$log_file"
    echo "运行时间: ${runtime}秒" | tee -a "$log_file"
    echo "退出代码: $exit_code" | tee -a "$log_file"
    echo "================================" | tee -a "$log_file"
    
    # 检查输出文件
    local output_files=0
    if [ -f "${output_prefix}.fb.tsv" ]; then
        output_files=$((output_files + 1))
        echo "主要输出文件: ${output_prefix}.fb.tsv" | tee -a "$log_file"
    fi
    
    if [ -f "${output_prefix}.runtimes.tsv" ]; then
        output_files=$((output_files + 1))
        echo "运行时间文件: ${output_prefix}.runtimes.tsv" | tee -a "$log_file"
    fi
    
    # 更新总体结果文件
    echo "${sample_name},${runtime},${exit_code},${output_files}" >> "$OUTPUT_DIR/batch_results.csv"
    
    if [ $exit_code -eq 0 ] && [ $output_files -ge 1 ]; then
        echo -e "${GREEN}样本分析完成: $sample_name (用时: ${runtime}秒)✓${NC}"
        return 0
    else
        echo -e "${RED}样本分析失败或输出不全: $sample_name${NC}"
        return 1
    fi
}

# 批量运行分析
run_batch_analysis() {
    echo -e "${BLUE}开始批量分析...${NC}"
    
    # 初始化结果文件
    echo "Sample,RunTime_Seconds,Exit_Code,Output_Files" > "$OUTPUT_DIR/batch_results.csv"
    
    local total_samples=${#SAMPLE_FILES[@]}
    local completed=0
    local failed=0
    
    # 记录开始时间
    local batch_start=$(date +%s.%N)
    
    for i in "${!SAMPLE_FILES[@]}"; do
        sample="${SAMPLE_FILES[$i]}"
        sample_num=$((i+1))
        
        echo ""
        echo "=========================================="
        echo "处理样本 $sample_num/$total_samples: $sample"
        echo "=========================================="
        
        if run_single_analysis "$sample"; then
            completed=$((completed + 1))
        else
            failed=$((failed + 1))
        fi
        
        echo ""
    done
    
    # 计算总运行时间
    local batch_end=$(date +%s.%N)
    local batch_runtime=$(echo "$batch_end - $batch_start" | bc)
    
    # 显示总结
    echo "=========================================="
    echo "批量分析完成"
    echo "=========================================="
    echo "总样本数: $total_samples"
    echo "成功完成: $completed"
    echo "分析失败: $failed"
    echo "总运行时间: ${batch_runtime}秒 (约 $(echo "scale=0; $batch_runtime/60" | bc)分钟)"
    echo ""
    echo "输出目录: $OUTPUT_DIR"
    echo "结果文件: $OUTPUT_DIR/batch_results.csv"
    echo "=========================================="
    
    if [ $failed -eq 0 ]; then
        echo -e "${GREEN}所有样本分析成功完成✓${NC}"
    else
        echo -e "${YELLOW}有 $failed 个样本分析失败${NC}"
    fi
}

# 生成分析报告
generate_batch_report() {
    echo -e "${BLUE}生成批量分析报告...${NC}"
    
    if [ ! -f "$OUTPUT_DIR/batch_results.csv" ]; then
        echo -e "${RED}错误: 未找到结果文件${NC}"
        return 1
    fi
    
    # 生成简单报告
    python3 << EOF
import pandas as pd
import numpy as np
from datetime import datetime

# 读取结果
try:
    results = pd.read_csv("$OUTPUT_DIR/batch_results.csv")
    
    # 计算统计信息
    total_samples = len(results)
    successful = len(results[results['Exit_Code'] == 0])
    failed = total_samples - successful
    
    total_time = results['RunTime_Seconds'].sum()
    avg_time = results['RunTime_Seconds'].mean()
    min_time = results['RunTime_Seconds'].min()
    max_time = results['RunTime_Seconds'].max()
    
    # 生成报告
    report_file = "$OUTPUT_DIR/batch_analysis_report.txt"
    with open(report_file, 'w') as f:
        f.write("RFMIX批量分析报告\n")
        f.write("=" * 50 + "\n")
        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"项目目录: $PROJECT_DIR\n")
        f.write("\n")
        f.write("统计摘要:\n")
        f.write(f"  总样本数: {total_samples}\n")
        f.write(f"  成功分析: {successful}\n")
        f.write(f"  分析失败: {failed}\n")
        f.write(f"  总运行时间: {total_time:.1f} 秒\n")
        f.write(f"  平均时间: {avg_time:.1f} 秒\n")
        f.write(f"  最短时间: {min_time:.1f} 秒\n")
        f.write(f"  最长时间: {max_time:.1f} 秒\n")
        f.write("\n")
        f.write("详细结果:\n")
        f.write("-" * 50 + "\n")
        
        for _, row in results.iterrows():
            status = "成功" if row['Exit_Code'] == 0 else "失败"
            f.write(f"样本: {row['Sample']}\n")
            f.write(f"  状态: {status}\n")
            f.write(f"  运行时间: {row['RunTime_Seconds']:.1f} 秒\n")
            f.write(f"  输出文件数: {row['Output_Files']}\n")
            f.write("-" * 50 + "\n")
        
        f.write("\n")
        f.write("参数配置:\n")
        f.write(f"  参考文件: CHS_YRI_DE9.vcf.gz\n")
        f.write(f"  遗传图谱: plink.chr1.GRCh38.loca\n")
        f.write(f"  参考面板: ref-panel.txt\n")
        f.write(f"  染色体: $CHROMOSOME\n")
        f.write(f"  世代数: $GENERATIONS\n")
        f.write(f"  线程数: $THREADS\n")
    
    print(f"报告已生成: {report_file}")
    
    # 显示摘要
    print("\n批量分析摘要:")
    print(f"总样本数: {total_samples}")
    print(f"成功: {successful}")
    print(f"失败: {failed}")
    print(f"总时间: {total_time:.1f}秒 ({total_time/3600:.1f}小时)")
    
except Exception as e:
    print(f"生成报告时出错: {e}")
EOF
    
    echo -e "${GREEN}批量分析报告生成完成✓${NC}"
}

# 显示菜单
show_menu() {
    clear
    echo "=========================================="
    echo "       RFMIX批量分析自动化脚本"
    echo "=========================================="
    echo ""
    echo "请选择操作:"
    echo "  1) 检查环境和文件"
    echo "  2) 显示配置信息"
    echo "  3) 运行批量分析"
    echo "  4) 生成分析报告"
    echo "  5) 清理输出目录"
    echo "  0) 退出"
    echo ""
    echo "=========================================="
}

# 清理输出目录
cleanup_output() {
    echo -e "${YELLOW}警告: 这将删除所有分析输出文件${NC}"
    echo "将删除以下目录内容:"
    echo "  - $OUTPUT_DIR/*"
    echo ""
    read -p "是否继续? (y/N): " confirm
    
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        echo -e "${BLUE}清理输出目录...${NC}"
        
        # 保留批处理结果文件
        keep_files=("batch_results.csv" "batch_analysis_report.txt")
        
        if [ -d "$OUTPUT_DIR" ]; then
            for file in "$OUTPUT_DIR"/*; do
                if [ -f "$file" ]; then
                    filename=$(basename "$file")
                    keep=0
                    for pattern in "${keep_files[@]}"; do
                        if [[ "$filename" == "$pattern" ]]; then
                            keep=1
                            break
                        fi
                    done
                    if [ $keep -eq 0 ]; then
                        rm -f "$file"
                    fi
                fi
            done
            echo "已清理: $OUTPUT_DIR"
        fi
        
        echo -e "${GREEN}输出目录清理完成✓${NC}"
    else
        echo -e "${BLUE}取消清理操作${NC}"
    fi
}

# 主程序
main() {
    # 检查是否在正确目录
    if [ ! -d "$PROJECT_DIR" ]; then
        echo -e "${YELLOW}创建项目目录: $PROJECT_DIR${NC}"
        mkdir -p "$PROJECT_DIR"
        mkdir -p "$INPUT_DIR"
        echo -e "${BLUE}请在 $INPUT_DIR 目录中放置以下文件:${NC}"
        echo "1. CHS_YRI.vcf.gz (参考文件)"
        echo "2. ref-panel.txt (参考面板)"
        echo "3. plink.chr1.GRCh38.loca (遗传图谱)"
        echo "4. 待分析样本文件 (*.vcf.gz)"
        echo ""
        read -p "按Enter键继续..." dummy
    fi
    
    while true; do
        show_menu
        read -p "请输入选择 (0-5): " choice
        
        case $choice in
            1)
                echo ""
                check_environment
                echo ""
                read -p "按Enter键继续..." dummy
                ;;
            2)
                echo ""
                show_config
                echo ""
                read -p "按Enter键继续..." dummy
                ;;
            3)
                echo ""
                if check_environment; then
                    run_batch_analysis
                fi
                echo ""
                read -p "按Enter键继续..." dummy
                ;;
            4)
                echo ""
                generate_batch_report
                echo ""
                read -p "按Enter键继续..." dummy
                ;;
            5)
                echo ""
                cleanup_output
                echo ""
                read -p "按Enter键继续..." dummy
                ;;
            0)
                echo -e "${GREEN}退出程序${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}无效选择，请重新输入${NC}"
                sleep 1
                ;;
        esac
    done
}

# 运行主程序
main
