#!/usr/bin/env python3
"""
RFMix 速度测试脚本（主控）
功能：
- 从99个样本中分别抽取20、60、80、99个样本
- 对每个样本数量运行 RFMix，记录运行时间
- 支持交互菜单：开始测试、生成报告、删除测试数据、退出
- 测试结果保存为 JSON 和 CSV 文件
- 生成报告时调用独立的绘图脚本
"""

import os
import sys
import subprocess
import time
import json
import random
import shutil
from datetime import datetime

# ========== 用户必须修改的路径配置 ==========
RFMIX_BIN = "your_project"           # RFMix 可执行文件路径
REF_VCF = "ref.vcf.gz"  # 参考VCF（含所有参考样本）
QUERY_VCF = "sample.vcf.gz"    # 待分析VCF（含99个样本）
SAMPLE_MAP = "your_ref_panel.txt" # 样本映射文件（参考面板用）
GENETIC_MAP = "your_genetic_map.loca" # 遗传图谱文件
OUTPUT_BASE = "./rfmix_speed_test"     # 临时输出根目录
THREADS = #                            # 线程数
# ==========================================

# 测试样本数量列表
SAMPLE_SIZES = [20, 60, 80, 99]
RANDOM_SEED = None 
random.seed(RANDOM_SEED)

# 结果存储文件
RESULT_JSON = "speed_test_results.json"
RESULT_CSV = "timings.csv"

def get_sample_names_from_vcf(vcf_file):
    """从VCF文件中获取所有样本名"""
    cmd = f"bcftools query -l {vcf_file}"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print("错误：无法读取VCF样本列表")
        sys.exit(1)
    samples = result.stdout.strip().split('\n')
    return [s for s in samples if s]

def subset_vcf(input_vcf, output_vcf, sample_list):
    """使用bcftools提取指定样本子集"""
    # 确保输出目录存在
    os.makedirs(os.path.dirname(output_vcf), exist_ok=True)
    
    sample_file = "temp_samples.txt"
    with open(sample_file, 'w') as f:
        f.write('\n'.join(sample_list))
    cmd = f"bcftools view -S {sample_file} {input_vcf} -Oz -o {output_vcf}"
    subprocess.run(cmd, shell=True, check=True)
    subprocess.run(f"tabix -p vcf {output_vcf}", shell=True, check=True)
    os.remove(sample_file)
    print(f"  已生成子集VCF: {output_vcf} ({len(sample_list)} 个样本)")

def run_rfmix(query_vcf, output_dir, sample_size):
    """运行RFMix并返回运行时间（秒）"""
    os.makedirs(output_dir, exist_ok=True)
    cmd = (
        f"{RFMIX_BIN} -f {query_vcf} -r {REF_VCF} -m {SAMPLE_MAP} -g {GENETIC_MAP} "
        f"-o {output_dir}/rfmix_out --chromosome=1 ---n-threads={THREADS}"
    )
    print(f"  运行命令: {cmd}")
    start_time = time.time()
    try:
        subprocess.run(cmd, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        print(f"  RFMix运行失败: {e}")
        print(e.stderr.decode())
        return None
    elapsed = time.time() - start_time
    return elapsed
    
def save_results_json(results):
    """保存JSON结果"""
    with open(RESULT_JSON, 'w') as f:
        json.dump(results, f, indent=2)

def save_results_csv(results_dict):
    """将结果保存为CSV文件"""
    with open(RESULT_CSV, 'w') as f:
        f.write("sample_size,runtime_seconds\n")
        for size_str, data in results_dict.items():
            size = data["samples"]
            runtime = data["time_seconds"]
            f.write(f"{size},{runtime:.2f}\n")

def start_test():
    """执行速度测试"""
    os.makedirs(OUTPUT_BASE, exist_ok=True)
    print("\n===== 开始速度测试 =====")
    all_samples = get_sample_names_from_vcf(QUERY_VCF)
    total_available = len(all_samples)
    if total_available < max(SAMPLE_SIZES):
        print(f"错误：总样本数({total_available})不足最大测试数{max(SAMPLE_SIZES)}")
        return

    results = {}
    for size in SAMPLE_SIZES:
        print(f"\n测试样本数: {size}")
        selected = random.sample(all_samples, size)
        temp_vcf = f"{OUTPUT_BASE}/query_subset_{size}.vcf.gz"
        subset_vcf(QUERY_VCF, temp_vcf, selected)
        out_dir = f"{OUTPUT_BASE}/out_{size}"
        elapsed = run_rfmix(temp_vcf, out_dir, size)
        if elapsed is not None:
            results[str(size)] = {
                "time_seconds": elapsed,
                "samples": size,
                "timestamp": datetime.now().isoformat()
            }
            print(f"  完成！耗时: {elapsed:.2f} 秒")
        else:
            print(f"  测试失败，跳过 {size}")
    
    save_results_json(results)
    save_results_csv(results)
    print("\n测试完成，结果已保存为 JSON 和 CSV。")

def generate_report():
    """调用独立绘图脚本生成报告"""
    if not os.path.exists(RESULT_CSV):
        print("没有找到测试结果 CSV 文件，请先运行测试。")
        return
    # 假定绘图脚本名为 plot_speed_results.py，位于同一目录
    plot_script = os.path.join(os.path.dirname(__file__), "plot_speed_results.py")
    if not os.path.exists(plot_script):
        print(f"错误：未找到绘图脚本 {plot_script}")
        return
    cmd = f"python3 {plot_script} {RESULT_CSV} rfmix_speed_curve.png"
    print(f"运行绘图命令: {cmd}")
    subprocess.run(cmd, shell=True, check=True)

def delete_test_data():
    """删除所有测试生成的临时文件和结果"""
    print("\n删除测试数据...")
    if os.path.exists(OUTPUT_BASE):
        shutil.rmtree(OUTPUT_BASE)
        print(f"已删除目录: {OUTPUT_BASE}")
    for f in [RESULT_JSON, RESULT_CSV]:
        if os.path.exists(f):
            os.remove(f)
            print(f"已删除文件: {f}")
    # 删除可能遗留的临时样本列表
    if os.path.exists("temp_samples.txt"):
        os.remove("temp_samples.txt")
    print("清理完成。")

def main():
    while True:
        print("\n" + "="*40)
        print("RFMix 速度测试工具")
        print("1. 开始测试")
        print("2. 生成数据报告")
        print("3. 删除测试数据")
        print("4. 退出")
        choice = input("请选择操作: ").strip()
        if choice == '1':
            start_test()
        elif choice == '2':
            generate_report()
        elif choice == '3':
            delete_test_data()
        elif choice == '4':
            print("退出程序。")
            break
        else:
            print("无效输入，请重新选择。")

if __name__ == "__main__":
    # 检查必要文件是否存在
    required = [RFMIX_BIN, REF_VCF, QUERY_VCF, SAMPLE_MAP, GENETIC_MAP]
    missing = [f for f in required if not os.path.exists(f)]
    if missing:
        print("错误：以下文件或程序不存在，请先修改脚本中的路径：")
        for m in missing:
            print(f"  - {m}")
        sys.exit(1)
    main()
