#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SALAI-Net 性能测试主程序 - 第9代样本（修正版）
"""

import os
import sys
import subprocess
import time
import random
import shutil
import logging
import pandas as pd

# ==================== 配置参数 ====================
SALAI_SCRIPT = "SALAI.py"
MODEL_PATH = "best_model.pth"
REF_VCF = "ref.vcf.gz"
REF_MAP = "genetic_map.txt"
QUERY_ORIGINAL = "sample.vcf.gz"

BASE_DIR = "your_project"
TEST_DIR = os.path.join(BASE_DIR, "test_sample")
RESULTS_FILE = os.path.join(TEST_DIR, "speed_results.csv")
SAMPLE_SIZES = [20, 60, 80, 99]
BATCH_SIZE = 16
NUM_THREADS = .
RANDOM_SEED = None
REPORT_SCRIPT = os.path.join(os.path.dirname(__file__), "generate_speed_report.py")

random.seed(RANDOM_SEED)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==================== 辅助函数 ====================
def check_dependencies():
    deps = ['bcftools', 'bgzip', 'tabix']
    for dep in deps:
        if shutil.which(dep) is None:
            logger.error(f"依赖工具 {dep} 未安装")
            return False
    for path in [SALAI_SCRIPT, MODEL_PATH, REF_VCF, REF_MAP, QUERY_ORIGINAL]:
        if not os.path.exists(path):
            logger.error(f"文件不存在: {path}")
            return False
    return True

def get_sample_ids(vcf_file):
    cmd = f"bcftools query -l {vcf_file}"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"获取样本ID失败: {result.stderr}")
    return result.stdout.strip().split('\n')

def extract_subset_vcf(input_vcf, output_vcf, sample_ids):
    if os.path.exists(output_vcf):
        os.remove(output_vcf)
        logger.info(f"已删除已存在的子集文件: {output_vcf}")
    sample_file = output_vcf + ".samples.txt"
    with open(sample_file, 'w') as f:
        f.write('\n'.join(sample_ids))
    cmd = f"bcftools view -S {sample_file} {input_vcf} -Oz -o {output_vcf}"
    ret = subprocess.run(cmd, shell=True)
    if ret.returncode != 0:
        os.remove(sample_file)
        raise RuntimeError("提取子集失败")
    subprocess.run(f"bcftools index {output_vcf}", shell=True, check=True)
    os.remove(sample_file)
    return True

def run_salai(query_vcf, output_base_dir):
    """运行 SALAI，输出到 output_base_dir/results（避免删除输入文件）"""
    results_dir = os.path.join(output_base_dir, "results")
    if os.path.exists(results_dir):
        shutil.rmtree(results_dir)
        logger.info(f"已删除已存在的输出目录: {results_dir}")
    
    env = os.environ.copy()
    env['OMP_NUM_THREADS'] = str(NUM_THREADS)
    env['MKL_NUM_THREADS'] = str(NUM_THREADS)
    env['OPENBLAS_NUM_THREADS'] = str(NUM_THREADS)
    env['CUDA_VISIBLE_DEVICES'] = ''  # 强制CPU
    cmd = [sys.executable, SALAI_SCRIPT,
           "--model-cp", MODEL_PATH,
           "-q", query_vcf,
           "-r", REF_VCF,
           "-m", REF_MAP,
           "-o", results_dir,
           "--batch-size", str(BATCH_SIZE)]
    start = time.time()
    proc = subprocess.run(cmd, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        logger.error(f"SALAI运行失败: {proc.stderr}")
        return None
    return time.time() - start

def delete_test_data():
    confirm = input("确定要删除所有测试数据吗？(y/n): ")
    if confirm.lower() == 'y':
        if os.path.exists(TEST_DIR):
            shutil.rmtree(TEST_DIR)
            logger.info(f"已删除 {TEST_DIR}")
        else:
            logger.info("测试目录不存在")
    else:
        logger.info("取消删除")

def run_tests():
    if not check_dependencies():
        return
    os.makedirs(TEST_DIR, exist_ok=True)
    logger.info("读取原始样本ID...")
    all_ids = get_sample_ids(QUERY_ORIGINAL)
    if len(all_ids) != 99:
        logger.warning(f"实际样本数 {len(all_ids)}，预期99")
    results = []
    for n in SAMPLE_SIZES:
        logger.info(f"\n========== 测试样本数: {n} ==========")
        selected = all_ids if n == 99 else random.sample(all_ids, n)
        sample_dir = os.path.join(TEST_DIR, f"samples_{n}")
        os.makedirs(sample_dir, exist_ok=True)
        query_subset = os.path.join(sample_dir, "query_subset.vcf.gz")
        try:
            extract_subset_vcf(QUERY_ORIGINAL, query_subset, selected)
        except Exception as e:
            results.append({'sample_size': n, 'time_seconds': None, 'status': 'failed', 'error': str(e)})
            continue
        runtime = run_salai(query_subset, sample_dir)
        if runtime is not None:
            results.append({'sample_size': n, 'time_seconds': runtime, 'status': 'success', 'error': ''})
        else:
            results.append({'sample_size': n, 'time_seconds': None, 'status': 'failed', 'error': 'SALAI error'})
    df = pd.DataFrame(results)
    df.to_csv(RESULTS_FILE, index=False)
    logger.info(f"结果已保存至 {RESULTS_FILE}")
    if os.path.exists(REPORT_SCRIPT):
        subprocess.run([sys.executable, REPORT_SCRIPT])
    else:
        logger.warning(f"报告脚本不存在: {REPORT_SCRIPT}")

def main():
    while True:
        print("\n" + "="*50)
        print("SALAI-Net 性能测试工具 - 第9代样本")
        print("="*50)
        print("1. 开始测试")
        print("2. 生成数据报告（仅基于已有结果）")
        print("3. 删除测试数据")
        print("4. 退出")
        choice = input("请选择 (1/2/3/4): ").strip()
        if choice == '1':
            run_tests()
        elif choice == '2':
            if os.path.exists(REPORT_SCRIPT):
                subprocess.run([sys.executable, REPORT_SCRIPT])
            else:
                print(f"报告脚本不存在: {REPORT_SCRIPT}")
        elif choice == '3':
            delete_test_data()
        elif choice == '4':
            break
        else:
            print("无效输入")

if __name__ == "__main__":
    main()
    
