#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试数据清理脚本
用于清理测试过程中生成的临时文件
"""

import os
import sys
import shutil
import argparse
import logging
from pathlib import Path

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/cleanup.log')
    ]
)
logger = logging.getLogger(__name__)

def confirm_action(prompt: str) -> bool:
    """确认操作"""
    response = input(f"{prompt} (y/N): ").strip().lower()
    return response in ['y', 'yes']

def cleanup_directory(dir_path: str, force: bool = False, 
                     dry_run: bool = False) -> int:
    """清理目录"""
    if not os.path.exists(dir_path):
        logger.info(f"目录不存在: {dir_path}")
        return 0
    
    try:
        # 获取目录内容
        contents = os.listdir(dir_path)
        if not contents:
            logger.info(f"目录为空: {dir_path}")
            return 0
        
        logger.info(f"目录 {dir_path} 包含 {len(contents)} 个项目")
        
        if not force:
            if not confirm_action(f"确认删除目录 {dir_path} 中的所有内容?"):
                logger.info("取消删除")
                return 0
        
        if dry_run:
            logger.info(f"[模拟] 将删除: {dir_path}")
            return len(contents)
        else:
            shutil.rmtree(dir_path)
            logger.info(f"已删除目录: {dir_path}")
            return len(contents)
            
    except Exception as e:
        logger.error(f"删除目录失败 {dir_path}: {e}")
        return 0

def cleanup_files(pattern: str, force: bool = False, 
                 dry_run: bool = False) -> int:
    """清理匹配模式的文件"""
    import glob
    
    files = glob.glob(pattern)
    if not files:
        logger.info(f"未找到匹配文件: {pattern}")
        return 0
    
    logger.info(f"找到 {len(files)} 个匹配文件")
    
    if not force:
        if not confirm_action(f"确认删除 {len(files)} 个匹配文件?"):
            logger.info("取消删除")
            return 0
    
    deleted_count = 0
    for file_path in files:
        try:
            if dry_run:
                logger.info(f"[模拟] 将删除: {file_path}")
            else:
                os.remove(file_path)
                logger.debug(f"已删除文件: {file_path}")
            deleted_count += 1
        except Exception as e:
            logger.error(f"删除文件失败 {file_path}: {e}")
    
    return deleted_count

def preserve_original_data(processed_dir: str, results_dir: str, 
                          logs_dir: str, reports_dir: str):
    """保护原始数据不被删除"""
    protected_files = []
    
    # 检查原始数据目录
    original_dir = os.path.dirname(processed_dir) if processed_dir else None
    if original_dir and os.path.exists(original_dir):
        original_files = os.listdir(original_dir)
        protected_files.extend([os.path.join(original_dir, f) for f in original_files])
    
    # 检查配置文件
    config_files = ['config/test_config.sh', 'config/fast_gradients.txt', 
                   'config/full_gradients.txt']
    for config_file in config_files:
        if os.path.exists(config_file):
            protected_files.append(config_file)
    
    # 检查源代码
    src_files = ['src/prepare_test_data.py', 'src/run_salai_test.py',
                'src/generate_report.py', 'src/cleanup.py']
    for src_file in src_files:
        if os.path.exists(src_file):
            protected_files.append(src_file)
    
    logger.info(f"保护 {len(protected_files)} 个原始文件和配置文件")
    return protected_files

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='清理SALAI-Net测试数据')
    parser.add_argument('--processed-dir', '-p', default='data/processed',
                       help='处理数据目录')
    parser.add_argument('--results-dir', '-r', default='data/results',
                       help='结果目录')
    parser.add_argument('--reports-dir', '-R', default='reports',
                       help='报告目录')
    parser.add_argument('--logs-dir', '-l', default='logs',
                       help='日志目录')
    parser.add_argument('--keep-original', '-k', action='store_true',
                       help='保留原始数据')
    parser.add_argument('--force', '-f', action='store_true',
                       help='强制删除，无需确认')
    parser.add_argument('--dry-run', '-n', action='store_true',
                       help='模拟运行，不实际删除')
    parser.add_argument('--keep-reports', action='store_true',
                       help='保留报告文件')
    parser.add_argument('--keep-logs', action='store_true',
                       help='保留日志文件')
    
    args = parser.parse_args()
    
    if args.dry_run:
        logger.info("=== 模拟运行模式 ===")
    
    # 显示要清理的内容
    logger.info("将清理以下目录:")
    if os.path.exists(args.processed_dir):
        logger.info(f"  - {args.processed_dir}")
    if os.path.exists(args.results_dir):
        logger.info(f"  - {args.results_dir}")
    if os.path.exists(args.reports_dir) and not args.keep_reports:
        logger.info(f"  - {args.reports_dir}")
    if os.path.exists(args.logs_dir) and not args.keep_logs:
        logger.info(f"  - {args.logs_dir}")
    
    if not args.force:
        if not confirm_action("确认执行清理操作?"):
            logger.info("清理操作已取消")
            return 0
    
    # 清理目录
    total_deleted = 0
    
    # 清理处理数据
    deleted = cleanup_directory(args.processed_dir, args.force, args.dry_run)
    total_deleted += deleted
    
    # 清理结果数据
    deleted = cleanup_directory(args.results_dir, args.force, args.dry_run)
    total_deleted += deleted
    
    # 清理报告数据
    if not args.keep_reports:
        deleted = cleanup_directory(args.reports_dir, args.force, args.dry_run)
        total_deleted += deleted
    
    # 清理日志数据（保留最新的）
    if not args.keep_logs:
        # 保留最近3个日志文件
        if os.path.exists(args.logs_dir):
            log_files = sorted([f for f in os.listdir(args.logs_dir) 
                              if f.endswith('.log')])
            for log_file in log_files[:-3]:  # 删除除了最近3个之外的所有文件
                file_path = os.path.join(args.logs_dir, log_file)
                try:
                    if args.dry_run:
                        logger.info(f"[模拟] 将删除日志: {file_path}")
                    else:
                        os.remove(file_path)
                        logger.info(f"已删除日志: {file_path}")
                    total_deleted += 1
                except Exception as e:
                    logger.error(f"删除日志失败 {file_path}: {e}")
    
    # 清理临时文件
    temp_patterns = ['temp_*.txt', 'temp_*.vcf', 'temp_*.vcf.gz',
                    '*.tmp', 'tmp_*']
    for pattern in temp_patterns:
        deleted = cleanup_files(pattern, args.force, args.dry_run)
        total_deleted += deleted
    
    # 输出总结
    logger.info("=" * 50)
    logger.info("清理操作完成")
    logger.info(f"总共删除项目: {total_deleted}")
    
    if args.dry_run:
        logger.info("注意: 这是模拟运行，没有实际删除文件")
    
    # 显示剩余磁盘空间
    try:
        import psutil
        usage = psutil.disk_usage('.')
        free_gb = usage.free / (1024**3)
        logger.info(f"当前目录剩余空间: {free_gb:.2f} GB")
    except ImportError:
        logger.info("无法获取磁盘空间信息")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
