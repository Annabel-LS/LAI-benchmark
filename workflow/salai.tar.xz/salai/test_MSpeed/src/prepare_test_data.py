#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SALAI-Net测试数据准备脚本
用于生成不同SNP数量的测试数据集
"""

import os
import sys
import subprocess
import random
import gzip
import shutil
import argparse
import logging
import hashlib
import traceback
from pathlib import Path
from typing import List, Tuple

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/data_preparation.log')
    ]
)
logger = logging.getLogger(__name__)

def check_bcftools() -> bool:
    """检查bcftools是否可用"""
    try:
        subprocess.run(['bcftools', '--version'], 
                      stdout=subprocess.PIPE, 
                      stderr=subprocess.PIPE, 
                      check=True)
        logger.info("bcftools可用")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        logger.error("bcftools未安装或不在PATH中")
        return False

def get_vcf_snp_count(vcf_file: str) -> int:
    """获取VCF文件中的SNP数量"""
    try:
        # 如果是压缩文件，使用zcat
        if vcf_file.endswith('.gz'):
            cmd = f"bcftools view -H {vcf_file} 2>/dev/null | wc -l"
        else:
            cmd = f"bcftools view -H {vcf_file} 2>/dev/null | wc -l"
        
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            count = int(result.stdout.strip())
            return count
        else:
            logger.error(f"无法获取SNP数量: {result.stderr}")
            return 0
    except Exception as e:
        logger.error(f"获取SNP数量时出错: {e}")
        return 0

def create_snp_subset(input_vcf: str, output_vcf: str, n_snps: int, 
                     seed: int = 42) -> bool:
    """
    从VCF文件中随机抽取指定数量的SNP（简化版）
    """
    try:
        # 创建临时文件
        temp_file = f"temp_{seed}_{n_snps}.vcf"
        
        # 1. 使用vcftools或bcftools随机抽取SNP
        # 这里使用简单的方法：先抽取，后排序
        cmd_extract = f"bcftools view -h {input_vcf} > {temp_file}"
        subprocess.run(cmd_extract, shell=True, check=True)
        
        # 2. 抽取指定数量的随机行
        # 使用awk生成随机数，然后排序选择
        cmd_random = f"""
        bcftools view -H {input_vcf} | \
        awk -v n={n_snps} -v seed={seed} 'BEGIN {{srand(seed)}} {{print rand(), $0}}' | \
        sort -k1,1n | \
        head -n {n_snps} | \
        cut -d' ' -f2- >> {temp_file}
        """
        subprocess.run(cmd_random, shell=True, executable='/bin/bash', check=True)
        
        # 3. 排序VCF文件
        temp_sorted = f"{temp_file}.sorted"
        cmd_sort = f"bcftools sort {temp_file} -o {temp_sorted}"
        subprocess.run(cmd_sort, shell=True, check=True)
        
        # 4. 清理临时文件
        os.remove(temp_file)
        
        # 5. 压缩（如果需要）
        if output_vcf.endswith('.gz'):
            cmd_compress = f"bgzip -c {temp_sorted} > {output_vcf}"
            subprocess.run(cmd_compress, shell=True, check=True)
            os.remove(temp_sorted)
            
            # 6. 创建索引
            cmd_index = f"tabix -p vcf {output_vcf}"
            subprocess.run(cmd_index, shell=True, check=True)
        else:
            os.rename(temp_sorted, output_vcf)
        
        # 验证
        output_count = get_vcf_snp_count(output_vcf)
        logger.info(f"成功创建 {output_vcf}，包含 {output_count:,} 个SNP")
        return True
        
    except Exception as e:
        logger.error(f"创建SNP子集失败: {e}")
        # 清理可能留下的临时文件
        for f in [temp_file, f"{temp_file}.sorted"]:
            if os.path.exists(f):
                os.remove(f)
        return False

def prepare_dataset_for_snps(n_snps: int, ref_vcf: str, query_vcf: str, 
                            map_file: str, output_dir: str) -> bool:
    """
    为指定SNP数量准备完整的测试数据集
    
    Args:
        n_snps: SNP数量
        ref_vcf: 参考VCF文件路径
        query_vcf: 查询VCF文件路径
        map_file: 映射文件路径
        output_dir: 输出目录
    
    Returns:
        bool: 操作是否成功
    """
    try:
        # 创建输出目录
        snp_dir = os.path.join(output_dir, str(n_snps))
        os.makedirs(snp_dir, exist_ok=True)
        
        logger.info(f"为 {n_snps:,} 个SNP准备数据集")
        
        # 文件路径
        ref_output = os.path.join(snp_dir, "reference.vcf.gz")
        query_output = os.path.join(snp_dir, "query.vcf.gz")
        map_output = os.path.join(snp_dir, "ref_panel.txt")
        
        # 检查文件是否已存在
        if os.path.exists(ref_output) and os.path.exists(query_output):
            logger.info(f"数据集 {n_snps} 已存在，跳过")
            return True
        
         
    # 1 生成参考文件子集
        logger.info(f"生成参考文件子集: {ref_vcf} -> {ref_output}")
        if not create_snp_subset(ref_vcf, ref_output, n_snps, seed=n_snps):
            logger.error(f"生成参考文件子集失败: {n_snps}")
            return False
        
        # 生成查询文件子集
        logger.info(f"生成查询文件子集: {query_vcf} -> {query_output}")
        if not create_snp_subset(query_vcf, query_output, n_snps, seed=n_snps):
            logger.error(f"生成查询文件子集失败: {n_snps}")
            return False
        
        # 复制映射文件
        shutil.copy2(map_file, map_output)
        logger.info(f"复制映射文件: {map_file} -> {map_output}")
        
        # 验证数据集
        ref_count = get_vcf_snp_count(ref_output)
        query_count = get_vcf_snp_count(query_output)
        
        if ref_count == query_count and ref_count == n_snps:
            logger.info(f"数据集 {n_snps} 准备完成: {ref_count}/{n_snps} 个SNP")
            return True
        else:
            logger.warning(f"数据集 {n_snps} SNP数量不匹配: 参考={ref_count}, 查询={query_count}")
            # 即使数量不匹配，也返回True，因为文件已创建
            return ref_count > 0 and query_count > 0
            
    except Exception as e:
        logger.error(f"准备数据集 {n_snps} 时出错: {e}")
        logger.error(f"详细错误: {traceback.format_exc()}")
        return False

def validate_data_files(ref_vcf: str, query_vcf: str, map_file: str) -> bool:
    """验证输入数据文件"""
    errors = []
    
    # 检查文件是否存在
    if not os.path.exists(ref_vcf):
        errors.append(f"参考文件不存在: {ref_vcf}")
    
    if not os.path.exists(query_vcf):
        errors.append(f"查询文件不存在: {query_vcf}")
    
    if not os.path.exists(map_file):
        errors.append(f"映射文件不存在: {map_file}")
    
    # 检查文件格式
    if ref_vcf and not (ref_vcf.endswith('.vcf') or ref_vcf.endswith('.vcf.gz')):
        errors.append(f"参考文件格式不支持: {ref_vcf}")
    
    if query_vcf and not (query_vcf.endswith('.vcf') or query_vcf.endswith('.vcf.gz')):
        errors.append(f"查询文件格式不支持: {query_vcf}")
    
    if errors:
        for error in errors:
            logger.error(error)
        return False
    
    return True

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='准备SALAI-Net测试数据')
    parser.add_argument('--reference', '-r', required=True,
                       help='参考VCF文件路径')
    parser.add_argument('--query', '-q', required=True,
                       help='查询VCF文件路径')
    parser.add_argument('--map', '-m', required=True,
                       help='样本映射文件路径')
    parser.add_argument('--gradients', '-g', nargs='+', type=int, required=True,
                       help='SNP梯度列表')
    parser.add_argument('--output-dir', '-o', default='data/processed',
                       help='输出目录')
    parser.add_argument('--seed', '-s', type=int, default=42,
                       help='随机种子')
    parser.add_argument('--force', '-f', action='store_true',
                       help='强制重新生成已存在的数据')
    
    args = parser.parse_args()
    
    # 检查bcftools
    if not check_bcftools():
        sys.exit(1)
    
    # 验证数据文件
    if not validate_data_files(args.reference, args.query, args.map):
        sys.exit(1)
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 获取原始文件SNP数量
    logger.info("分析原始数据文件...")
    ref_snps = get_vcf_snp_count(args.reference)
    query_snps = get_vcf_snp_count(args.query)
    
    logger.info(f"参考文件: {ref_snps:,} 个SNP")
    logger.info(f"查询文件: {query_snps:,} 个SNP")
    
    # 检查梯度值是否有效
    max_snps = min(ref_snps, query_snps)
    valid_gradients = []
    
    for n in args.gradients:
        if n > max_snps:
            logger.warning(f"梯度值 {n:,} 超过最大可用SNP数 {max_snps:,}，调整为最大值")
            n = max_snps
        valid_gradients.append(n)
    
    # 去重并排序
    valid_gradients = sorted(list(set(valid_gradients)))
    logger.info(f"将生成 {len(valid_gradients)} 个测试数据集")
    
    # 准备数据集
    success_count = 0
    for n_snps in valid_gradients:
        success = prepare_dataset_for_snps(
            n_snps, args.reference, args.query, 
            args.map, args.output_dir
        )
        if success:
            success_count += 1
        else:
            logger.error(f"数据集 {n_snps} 准备失败")
    
    # 输出总结
    logger.info("=" * 50)
    logger.info(f"数据准备完成")
    logger.info(f"成功: {success_count}/{len(valid_gradients)}")
    logger.info(f"输出目录: {args.output_dir}")
    logger.info("=" * 50)
    
    if success_count == len(valid_gradients):
        return 0
    else:
        return 1

if __name__ == "__main__":
    sys.exit(main())
