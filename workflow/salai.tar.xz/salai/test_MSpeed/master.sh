#!/bin/bash

# ============================================
# SALAI-Net SNP数量与运行时间测试系统
# 主控制脚本
# ============================================

# 加载配置
source config/test_config.sh

# 创建日志文件
CURRENT_TIME=$(date +"$DATE_FORMAT")
LOG_FILE="logs/test_${CURRENT_TIME}.log"
exec 3>&1 4>&2
exec > >(tee -a "$LOG_FILE") 2>&1

# 函数定义
print_header() {
    echo -e "${CYAN}"
    echo "====================================="
    echo "  SALAI-Net M_SNP Runtime Benchmark"
    echo "====================================="
    echo -e "${NC}"
}

print_menu() {
    echo -e "${GREEN}请选择测试模式:${NC}"
    echo "1. 完整测试 (16个数据点)"
    echo "2. 快速测试 (12个数据点)"
    echo "3. 模拟测试 (不生成数据文件)"
    echo "4. 生成数据报告"
    echo "5. 清除测试数据"
    echo "0. 退出"
    echo ""
    echo -n "请输入选择 [0-5]: "
}

check_dependencies() {
    echo -e "${BLUE}[INFO] 检查系统依赖...${NC}"
    
    local missing_deps=()
    
    # 检查Python
    if ! command -v python3 &> /dev/null; then
        missing_deps+=("Python3")
    fi
    
    # 检查bcftools
    if ! command -v bcftools &> /dev/null; then
        missing_deps+=("bcftools")
    fi
    
    # 检查bgzip
    if ! command -v bgzip &> /dev/null; then
        missing_deps+=("bgzip")
    fi
    
    # 检查tabix
    if ! command -v tabix &> /dev/null; then
        missing_deps+=("tabix")
    fi
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        echo -e "${RED}[ERROR] 缺少以下依赖:${NC}"
        for dep in "${missing_deps[@]}"; do
            echo "  - $dep"
        done
        echo -e "${YELLOW}请安装缺失的依赖后重试${NC}"
        return 1
    fi
    
    echo -e "${GREEN}[OK] 所有依赖已安装${NC}"
    return 0
}

check_salai_script() {
    echo -e "${BLUE}[INFO] 检查SALAI-Net脚本...${NC}"
    
    if [ ! -f "$SALAI_SCRIPT" ]; then
        echo -e "${RED}[ERROR] 找不到SALAI-Net脚本: $SALAI_SCRIPT${NC}"
        echo -e "${YELLOW}请确保SALAI-Net安装在项目目录的上一级${NC}"
        return 1
    fi
    
    if [ ! -f "$MODEL_PATH" ]; then
        echo -e "${YELLOW}[WARNING] 找不到模型文件: $MODEL_PATH${NC}"
        echo -e "${YELLOW}测试可能需要预训练模型${NC}"
    fi
    
    echo -e "${GREEN}[OK] SALAI-Net脚本可用${NC}"
    return 0
}

check_data_files() {
    echo -e "${BLUE}[INFO] 检查数据文件...${NC}"
    
    local missing_files=()
    
    # 检查参考文件
    if [ ! -f "$REFERENCE_FILE" ]; then
        missing_files+=("$REFERENCE_FILE")
    fi
    
    # 检查查询文件
    if [ ! -f "$QUERY_FILE" ]; then
        missing_files+=("$QUERY_FILE")
    fi
    
    # 检查映射文件
    if [ ! -f "$MAP_FILE" ]; then
        missing_files+=("$MAP_FILE")
    fi
    
    if [ ${#missing_files[@]} -gt 0 ]; then
        echo -e "${YELLOW}[WARNING] 以下文件未找到:${NC}"
        for file in "${missing_files[@]}"; do
            echo "  - $file"
        done
        echo -e "${YELLOW}请将文件放置在data/original/目录下${NC}"
        return 1
    fi
    
    echo -e "${GREEN}[OK] 数据文件已就绪${NC}"
    return 0
}

prepare_data() {
    local gradients=("$@")
    
    echo -e "${BLUE}[INFO] 准备测试数据...${NC}"
    echo "将生成 ${#gradients[@]} 个测试数据集"
    
    # 创建处理数据目录
    mkdir -p data/processed
    
    # 调用Python脚本准备数据
    python3 src/prepare_test_data.py \
        --reference "$REFERENCE_FILE" \
        --query "$QUERY_FILE" \
        --map "$MAP_FILE" \
        --gradients "${gradients[@]}" \
        --output-dir data/processed
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[OK] 测试数据准备完成${NC}"
        return 0
    else
        echo -e "${RED}[ERROR] 数据准备失败${NC}"
        return 1
    fi
}

run_complete_test() {
    echo -e "${BLUE}[INFO] 开始完整测试...${NC}"
    
    # 读取完整梯度
    local gradients=()
    while IFS= read -r line; do
        gradients+=("$line")
    done < config/full_gradients.txt
    
    # 准备数据
    prepare_data "${gradients[@]}"
    if [ $? -ne 0 ]; then
        return 1
    fi
    
    # 运行测试
    echo -e "${BLUE}[INFO] 执行SALAI-Net测试...${NC}"
    python3 src/run_salai_test.py \
        --salai-script "$SALAI_SCRIPT" \
        --model-path "$MODEL_PATH" \
        --gradients "${gradients[@]}" \
        --data-dir data/processed \
        --results-dir data/results \
        --batch-size "$BATCH_SIZE" \
        --max-wait "$MAX_WAIT_TIME"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[OK] 完整测试完成${NC}"
        return 0
    else
        echo -e "${RED}[ERROR] 测试执行失败${NC}"
        return 1
    fi
}

run_quick_test() {
    echo -e "${BLUE}[INFO] 开始快速测试...${NC}"
    
    # 读取快速梯度
    local gradients=()
    while IFS= read -r line; do
        gradients+=("$line")
    done < config/fast_gradients.txt
    
    # 检查数据是否已存在
    local need_prepare=0
    for snp in "${gradients[@]}"; do
        if [ ! -d "data/processed/$snp" ]; then
            need_prepare=1
            break
        fi
    done
    
    if [ $need_prepare -eq 1 ]; then
        prepare_data "${gradients[@]}"
        if [ $? -ne 0 ]; then
            return 1
        fi
    fi
    
    # 运行测试
    echo -e "${BLUE}[INFO] 执行快速测试...${NC}"
    python3 src/run_salai_test.py \
        --salai-script "$SALAI_SCRIPT" \
        --model-path "$MODEL_PATH" \
        --gradients "${gradients[@]}" \
        --data-dir data/processed \
        --results-dir data/results \
        --batch-size "$BATCH_SIZE" \
        --quick-mode \
        --max-wait "$MAX_WAIT_TIME"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[OK] 快速测试完成${NC}"
        return 0
    else
        echo -e "${RED}[ERROR] 测试执行失败${NC}"
        return 1
    fi
}

run_simulation() {
    echo -e "${BLUE}[INFO] 开始模拟测试...${NC}"
    
    # 读取完整梯度
    local gradients=()
    while IFS= read -r line; do
        gradients+=("$line")
    done < config/full_gradients.txt
    
    # 运行模拟测试
    python3 src/run_salai_test.py \
        --salai-script "$SALAI_SCRIPT" \
        --model-path "$MODEL_PATH" \
        --gradients "${gradients[@]}" \
        --data-dir data/processed \
        --results-dir data/results \
        --batch-size "$BATCH_SIZE" \
        --simulation \
        --max-wait "$MAX_WAIT_TIME"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[OK] 模拟测试完成${NC}"
        return 0
    else
        echo -e "${RED}[ERROR] 模拟测试失败${NC}"
        return 1
    fi
}

generate_report() {
    echo -e "${BLUE}[INFO] 生成数据报告...${NC}"
    
    python3 src/generate_report.py \
        --results-dir data/results \
        --output-dir reports \
        --date "$CURRENT_TIME"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[OK] 报告生成完成${NC}"
        echo -e "${YELLOW}报告保存在: reports/${NC}"
        return 0
    else
        echo -e "${RED}[ERROR] 报告生成失败${NC}"
        return 1
    fi
}

cleanup_data() {
    echo -e "${YELLOW}[WARNING] 即将清除测试数据${NC}"
    echo "这将删除以下目录:"
    echo "  - data/processed/"
    echo "  - data/results/"
    echo "  - reports/"
    echo ""
    echo -n "是否继续? (y/N): "
    read -r confirm
    
    if [[ "$confirm" =~ ^[Yy]$ ]]; then
        echo -e "${BLUE}[INFO] 清除测试数据...${NC}"
        
        # 调用清理脚本
        python3 src/cleanup.py \
            --processed-dir data/processed \
            --results-dir data/results \
            --reports-dir reports \
            --logs-dir logs \
            --keep-original
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}[OK] 数据清理完成${NC}"
        else
            echo -e "${RED}[ERROR] 数据清理失败${NC}"
        fi
    else
        echo -e "${BLUE}[INFO] 取消数据清理${NC}"
    fi
}

# 主程序
main() {
    # 打印标题
    print_header
    
    # 检查依赖
    check_dependencies || exit 1
    
    # 检查SALAI脚本
    check_salai_script || exit 1
    
    # 检查数据文件
    check_data_files || {
        echo -e "${YELLOW}[WARNING] 数据文件不完整，但测试仍可继续${NC}"
        echo ""
    }
    
    while true; do
        print_menu
        read -r choice
        
        case $choice in
            1)
                echo ""
                run_complete_test
                ;;
            2)
                echo ""
                run_quick_test
                ;;
            3)
                echo ""
                run_simulation
                ;;
            4)
                echo ""
                generate_report
                ;;
            5)
                echo ""
                cleanup_data
                ;;
            0)
                echo ""
                echo -e "${GREEN}感谢使用SALAI-Net测试系统！${NC}"
                break
                ;;
            *)
                echo ""
                echo -e "${RED}无效选择，请重新输入${NC}"
                ;;
        esac
        
        echo ""
        echo -n "按Enter键继续..."
        read -r
        clear
        print_header
    done
    
    # 恢复标准输出
    exec 1>&3 2>&4
}

# 运行主程序
main "$@"
