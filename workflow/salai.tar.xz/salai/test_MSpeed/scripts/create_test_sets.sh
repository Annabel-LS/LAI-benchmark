#!/bin/bash

# 快速创建测试数据集的脚本

set -e

# 加载配置
source ../config/test_config.sh

echo "正在创建测试数据集..."
echo "使用梯度: ${FAST_GRADIENTS[*]}"

# 运行Python脚本
python3 ../src/prepare_test_data.py \
    --reference "$REFERENCE_FILE" \
    --query "$QUERY_FILE" \
    --map "$MAP_FILE" \
    --gradients "${FAST_GRADIENTS[@]}" \
    --output-dir ../data/processed \
    --force

echo "测试数据集创建完成!"
