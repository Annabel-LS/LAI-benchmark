#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据验证脚本
用于验证测试数据的完整性和正确性
"""

import os
import sys
import subprocess
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def validate_vcf_file(vcf_path):
    """验证VCF文件"""
    if not os.path.exists(vcf_path):
        logger.error(f"文件不存在: {vcf_path}")
        return False
    
    try:
        # 使用bcftools验证
        cmd = f"bcftools query -f '%CHROM\t%POS\n' {vcf_path} | head -5"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        if result.returncode == 0:
            logger.info(f"VCF文件验证通过: {vcf_path}")
            return True
        else:
            logger.error(f"VCF文件验证失败: {vcf_path}")
            logger.error(f"错误: {result.stderr}")
            return False
            
    except Exception as e:
        logger.error(f"验证VCF文件时出错: {e}")
        return False

def validate_map_file(map_path):
    """验证映射文件"""
    if not os.path.exists(map_path):
        logger.error(f"文件不存在: {map_path}")
        return False
    
    try:
        with open(map_path, 'r') as f:
            lines = f.readlines()
            
        if len(lines) < 2:
            logger.warning(f"映射文件行数较少: {len(lines)}")
        
        # 检查格式
        for i, line in enumerate(lines, 1):
            parts = line.strip().split()
            if len(parts) < 2:
                logger.warning(f"第{i}行格式可能不正确: {line}")
        
        logger.info(f"映射文件验证通过: {map_path}")
        return True
        
    except Exception as e:
        logger.error(f"验证映射文件时出错: {e}")
        return False

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='验证测试数据')
    parser.add_argument('--data-dir', default='data/processed',
                       help='数据目录')
    parser.add_argument('--check-all', action='store_true',
                       help='检查所有测试集')
    
    args = parser.parse_args()
    
    if args.check_all:
        # 检查所有测试集
        import glob
        test_dirs = glob.glob(os.path.join(args.data_dir, '*'))
        
        for test_dir in test_dirs:
            if os.path.isdir(test_dir):
                logger.info(f"验证测试集: {os.path.basename(test_dir)}")
                
                ref_vcf = os.path.join(test_dir, "reference.vcf.gz")
                query_vcf = os.path.join(test_dir, "query.vcf.gz")
                map_file = os.path.join(test_dir, "ref-panel.txt")
                
                validate_vcf_file(ref_vcf)
                validate_vcf_file(query_vcf)
                validate_map_file(map_file)
    else:
        # 检查最新测试集
        import glob
        test_dirs = sorted(glob.glob(os.path.join(args.data_dir, '*')))
        
        if test_dirs:
            latest_dir = test_dirs[-1]
            logger.info(f"验证最新测试集: {os.path.basename(latest_dir)}")
            
            ref_vcf = os.path.join(latest_dir, "reference.vcf.gz")
            query_vcf = os.path.join(latest_dir, "query.vcf.gz")
            map_file = os.path.join(latest_dir, "ref-panel.txt")
            
            validate_vcf_file(ref_vcf)
            validate_vcf_file(query_vcf)
            validate_map_file(map_file)
        else:
            logger.warning("未找到测试集")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
