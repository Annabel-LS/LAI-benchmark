#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SALAI-Net运行时间测试脚本 - 修复目录创建问题
"""

import os
import sys
import time
import subprocess
import csv
import argparse
import logging
import shutil
from datetime import datetime
from typing import Dict, List, Tuple

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/test_execution.log')
    ]
)
logger = logging.getLogger(__name__)

def run_salai_command(salai_script: str, model_path: str, data_dir: str, 
                     n_snps: int, batch_size: int, output_dir: str, run_id: str = None,
                     use_cpu: bool = False, max_retries: int = 2) -> Tuple[bool, float, Dict]:
    """
    运行SALAI-Net命令 - 支持重试和CPU模式
    """
    import copy
    
    # 配置不同的运行参数
    run_configs = []
    
    # 第一尝试：使用GPU，正常batch-size
    if not use_cpu:
        run_configs.append({
            'name': 'GPU正常batch-size',
            'batch_size': batch_size,
            'env': None,  # 使用默认环境（GPU）
            'description': f'GPU, batch-size={batch_size}'
        })
        
        # 第二尝试：使用GPU，减小batch-size
        if n_snps >= 100000:
            reduced_bs = max(8, batch_size // 2)
            run_configs.append({
                'name': 'GPU减小batch-size',
                'batch_size': reduced_bs,
                'env': None,
                'description': f'GPU, batch-size={reduced_bs}'
            })
    
    # 第三尝试：使用CPU
    run_configs.append({
        'name': 'CPU模式',
        'batch_size': min(batch_size, 16),  # CPU上使用更小的batch-size
        'env': {'CUDA_VISIBLE_DEVICES': ''},  # 禁用GPU
        'description': f'CPU, batch-size={min(batch_size, 16)}'
    })
    
    last_error = None
    last_stderr = None
    
    for attempt, config in enumerate(run_configs[:max_retries]):
        try:
            logger.info(f"尝试 {attempt+1}/{len(run_configs[:max_retries])}: {config['name']}")
            
            result_dir = os.path.join(output_dir, str(n_snps), 
                                     f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{attempt}")
            
            # 确保父目录存在
            parent_dir = os.path.dirname(result_dir)
            os.makedirs(parent_dir, exist_ok=True)
            
            # 确保输出目录不存在
            if os.path.exists(result_dir):
                shutil.rmtree(result_dir, ignore_errors=True)
            
            # 构建命令
            cmd = [
                "python3", salai_script,
                "--model-cp", model_path,
                "--query", os.path.join(data_dir, str(n_snps), "query.vcf.gz"),
                "--reference", os.path.join(data_dir, str(n_snps), "reference.vcf.gz"),
                "--map", os.path.join(data_dir, str(n_snps), "ref-panel.txt"),
                "--out-folder", result_dir,
                "--batch-size", str(config['batch_size'])
            ]
            
            logger.info(f"运行命令: {' '.join(cmd)}")
            logger.info(f"配置: {config['description']}")
            
            # 记录开始时间
            start_time = time.time()
            
            # 准备环境变量
            env = os.environ.copy()
            if config['env']:
                env.update(config['env'])
            
            # 运行命令
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                env=env
            )
            
            stdout, stderr = process.communicate(timeout=3600)
            
            # 计算运行时间
            end_time = time.time()
            run_time = end_time - start_time
            
            # 检查返回码
            if process.returncode == 0:
                logger.info(f"✓ SNP={n_snps:,}: 成功 ({config['name']})，时间={run_time:.2f}秒")
                
                # 保存日志
                if os.path.exists(result_dir):
                    log_file = os.path.join(result_dir, "run.log")
                    with open(log_file, 'w') as f:
                        f.write(f"命令: {' '.join(cmd)}\n")
                        f.write(f"配置: {config['description']}\n")
                        f.write(f"运行时间: {run_time:.2f}秒\n\n")
                        f.write("输出:\n")
                        f.write(stdout)
                
                return True, run_time, {}
            else:
                logger.warning(f"✗ 尝试 {attempt+1} 失败，返回码={process.returncode}")
                last_error = process.returncode
                last_stderr = stderr
                
                # 保存错误日志
                if os.path.exists(result_dir):
                    error_file = os.path.join(result_dir, "error.log")
                    with open(error_file, 'w') as f:
                        f.write(f"命令: {' '.join(cmd)}\n")
                        f.write(f"配置: {config['description']}\n")
                        f.write(f"返回码: {process.returncode}\n")
                        f.write(f"运行时间: {run_time:.2f}秒\n\n")
                        f.write("标准输出:\n")
                        f.write(stdout)
                        f.write("\n\n标准错误:\n")
                        f.write(stderr)
                
                # 如果是内存不足，继续尝试下一个配置
                if "OutOfMemoryError" in stderr or "out of memory" in stderr.lower():
                    logger.info("内存不足，尝试下一个配置...")
                    continue
                else:
                    # 其他错误，直接返回
                    break
                    
        except subprocess.TimeoutExpired:
            logger.error(f"命令执行超时")
            last_error = -1
            break
        except Exception as e:
            logger.error(f"执行出错: {e}")
            last_error = -2
            break
    
    # 所有尝试都失败
    logger.error(f"✗ SNP={n_snps:,}: 所有{len(run_configs[:max_retries])}次尝试都失败")
    if last_stderr:
        logger.error("最后一次错误输出:")
        for line in last_stderr.strip().split('\n')[-5:]:
            if line.strip():
                logger.error(f"  {line}")
    
    return False, 0.0, {}

# 保持其他函数不变
def simulate_run_time(n_snps: int) -> Tuple[bool, float, Dict]:
    """模拟运行时间（用于测试）"""
    import random
    import math
    
    a = 0.001
    b = 0.8
    base_time = a * (n_snps ** b)
    variation = random.uniform(0.9, 1.1)
    run_time = base_time * variation
    
    resource_summary = {
        'max_cpu_percent': random.uniform(30, 90),
        'avg_cpu_percent': random.uniform(20, 70),
        'max_memory_mb': 100 + n_snps / 1000,
        'avg_memory_mb': 80 + n_snps / 1200,
        'total_io_read_mb': n_snps / 500,
        'total_io_write_mb': n_snps / 1000,
        'monitoring_duration': run_time
    }
    
    logger.info(f"模拟 SNP={n_snps:,}: 运行时间={run_time:.2f}秒")
    return True, run_time, resource_summary

def run_test_for_snps(n_snps: int, salai_script: str, model_path: str, 
                     data_dir: str, results_dir: str, batch_size: int,
                     simulation: bool = False, force_cpu_for_large: bool = True) -> Dict:
    """
    为指定SNP数量运行测试
    """
    logger.info(f"开始测试 SNP={n_snps:,}")
    
    if simulation:
        success, run_time, resources = simulate_run_time(n_snps)
    else:
        # 对于大SNP数据集，强制使用CPU模式
        use_cpu = force_cpu_for_large and n_snps >= 100000
        
        if use_cpu:
            logger.info(f"SNP数量 {n_snps:,} 较大，启用CPU模式")
        
        success, run_time, resources = run_salai_command(
            salai_script, model_path, data_dir,
            n_snps, batch_size, results_dir,
            use_cpu=use_cpu, max_retries=3
        )
    
    result = {
        'snp_count': n_snps,
        'success': success,
        'run_time': run_time,
        'resources': resources,
        'timestamp': datetime.now().isoformat(),
        'used_cpu': use_cpu if 'use_cpu' in locals() else False
    }
    
    if success:
        logger.info(f"✓ 测试完成 SNP={n_snps:,}: 运行时间={run_time:.2f}秒")
    else:
        logger.error(f"✗ 测试失败 SNP={n_snps:,}")
    
    return result

def save_results(results: List[Dict], output_file: str):
    """保存测试结果到CSV文件"""
    try:
        with open(output_file, 'w', newline='') as f:
            fieldnames = [
                'SNP_Count', 'Success', 'Run_Time_s', 
                'Test_Date', 'Platform'
            ]
            
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for result in results:
                row = {
                    'SNP_Count': result['snp_count'],
                    'Success': 'Yes' if result.get('success', False) else 'No',
                    'Run_Time_s': result.get('run_time', 0.0),
                    'Test_Date': result.get('timestamp', datetime.now().strftime("%Y-%m-%d")),
                    'Platform': 'GPU' if shutil.which('nvidia-smi') else 'CPU'
                }
                writer.writerow(row)
        
        logger.info(f"结果已保存到: {output_file}")
        
    except Exception as e:
        logger.error(f"保存结果失败: {e}")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='运行SALAI-Net测试')
    parser.add_argument('--salai-script', '-s', required=True,
                       help='SALAI.py脚本路径')
    parser.add_argument('--model-path', '-m', required=True,
                       help='模型检查点路径')
    parser.add_argument('--gradients', '-g', nargs='+', type=int, required=True,
                       help='SNP梯度列表')
    parser.add_argument('--data-dir', '-d', default='data/processed',
                       help='测试数据目录')
    parser.add_argument('--results-dir', '-r', default='data/results',
                       help='结果输出目录')
    parser.add_argument('--batch-size', '-b', type=int, default=32,
                       help='批处理大小')
    parser.add_argument('--max-wait', '-w', type=int, default=3600,
                       help='最大等待时间（秒）')
    parser.add_argument('--simulation', action='store_true',
                       help='模拟模式（不实际运行）')
    parser.add_argument('--quick-mode', action='store_true',
                       help='快速模式（减少日志输出）')
    parser.add_argument('--force-cpu', action='store_true',
                       help='强制使用CPU模式')
    parser.add_argument('--cpu-threshold', type=int, default=100000,
                       help='超过此SNP数量时使用CPU（默认: 100000）')
    
    args = parser.parse_args()
    
    # 创建结果目录
    os.makedirs(args.results_dir, exist_ok=True)
    
    # 运行测试
    all_results = []
    total_tests = len(args.gradients)
    
    logger.info(f"开始测试，共{total_tests}个SNP梯度")
    logger.info(f"模式: {'模拟' if args.simulation else '实际运行'}")
    logger.info(f"批处理大小: {args.batch_size}")
    
    start_time = time.time()
    
    # 顺序执行测试
    for i, n_snps in enumerate(sorted(args.gradients), 1):
        logger.info(f"进度: {i}/{total_tests} ({n_snps:,} SNPs)")
        
        result = run_test_for_snps(
            n_snps, args.salai_script, args.model_path,
            args.data_dir, args.results_dir, args.batch_size,
            args.simulation
        )
        
        all_results.append(result)
        
        # 检查是否超时
        elapsed = time.time() - start_time
        if elapsed > args.max_wait:
            logger.warning(f"已达到最大等待时间({args.max_wait}秒)，停止测试")
            break
        
        # 短暂的间隔
        if i < total_tests and not args.simulation:
            time.sleep(2)
    
    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    mode = "simulation" if args.simulation else ("quick" if args.quick_mode else "full")
    output_file = os.path.join(args.results_dir, f"results_{mode}_{timestamp}.csv")
    
    save_results(all_results, output_file)
    
    # 输出总结
    total_time = time.time() - start_time
    successful_tests = sum(1 for r in all_results if r.get('success', False))
    
    logger.info("=" * 50)
    logger.info(f"测试完成!")
    logger.info(f"总测试时间: {total_time:.2f}秒")
    logger.info(f"成功测试: {successful_tests}/{len(all_results)}")
    if successful_tests > 0:
        avg_time = sum(r.get('run_time', 0) for r in all_results if r.get('success', False)) / successful_tests
        logger.info(f"平均运行时间: {avg_time:.2f}秒")
    logger.info(f"结果文件: {output_file}")
    logger.info("=" * 50)
    
    return 0 if successful_tests == len(all_results) else 1

if __name__ == "__main__":
    sys.exit(main())
