#!/bin/bash

# ============================================
# SALAI-Net SNP测试配置文件
# ============================================

# 路径配置
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PARENT_DIR="$(dirname "$PROJECT_ROOT")"
SALAI_SCRIPT="$PARENT_DIR/src/SALAI.py"
MODEL_PATH="/best_model.pth"

# 原始数据文件（相对路径）
REFERENCE_FILE="data/original/ref.vcf.gz"
QUERY_FILE="data/original/sample.vcf.gz"
MAP_FILE="data/original/ref-panel.txt"

# 测试梯度配置
FAST_GRADIENTS=(1000 5000 10000 50000 100000 200000 300000 400000 500000 600000 700000 796678)
FULL_GRADIENTS=(1000 5000 10000 25000 50000 75000 100000 150000 200000 250000 300000 400000 500000 600000 700000 796678)

# 测试参数
BATCH_SIZE=32
MAX_WAIT_TIME=3600  # 最大等待时间（秒）

# 系统监控配置
MONITOR_INTERVAL=5  # 监控间隔（秒）

# 输出配置
OUTPUT_PREFIX="salai_test"
DATE_FORMAT="%Y%m%d_%H%M%S"
LOG_LEVEL="INFO"  # DEBUG, INFO, WARNING, ERROR

# 颜色代码
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
