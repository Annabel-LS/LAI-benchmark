#!/bin/bash

# 设置环境变量强制使用CPU
export CUDA_VISIBLE_DEVICES=''

# 当前目录
CURRENT_DIR="your_project"
cd "${CURRENT_DIR}"

MODEL_PATH="best_model.pth"
REF_VCF="ref.vcf.gz"
REF_MAP="ref-panel.txt"
OUTPUT_BASE="output_final"

# 样本列表
SAMPLE_FILES=(
    "40_ancestry.vcf.gz"
    "60_ancestry.vcf.gz"
    "80_ancestry.vcf.gz"
    "100_ancestry.vcf.gz"
)

echo "=== 使用CPU运行SALAI-Net ==="
echo "当前目录: $(pwd)"
echo "开始时间: $(date)"
echo ""

# 1. 检查文件
echo "1. 检查输入文件..."
for SAMPLE in "${SAMPLE_FILES[@]}"; do
    if [ -f "${SAMPLE}" ]; then
        echo "   ✓ ${SAMPLE} 存在 (大小: $(ls -lh "${SAMPLE}" | awk '{print $5}'))"
    else
        echo "   ✗ ${SAMPLE} 不存在"
    fi
done

if [ -f "${REF_VCF}" ]; then
    echo "   ✓ 参考VCF文件存在 (大小: $(ls -lh "${REF_VCF}" | awk '{print $5}'))"
else
    echo "   ✗ 参考VCF文件不存在"
    exit 1
fi

if [ -f "${REF_MAP}" ]; then
    echo "   ✓ 映射文件存在"
    echo "   映射文件信息:"
    echo "     总行数: $(wc -l < "${REF_MAP}")"
    echo "     群体分布:"
    cut -f2 "${REF_MAP}" 2>/dev/null | sort | uniq -c
else
    echo "   ✗ 映射文件不存在"
    exit 1
fi
echo ""

# 2. 创建输出目录
echo "2. 创建输出目录..."
mkdir -p "${OUTPUT_BASE}"
echo "   输出目录: ${OUTPUT_BASE}"
echo ""

# 3. 处理每个样本
echo "3. 开始处理样本..."
TOTAL_START_TIME=$(date +%s)

for SAMPLE in "${SAMPLE_FILES[@]}"; do
    INPUT_VCF="${SAMPLE}"
    SAMPLE_NAME=$(basename "${SAMPLE}" .vcf.gz)
    OUTPUT_DIR="${OUTPUT_BASE}/${SAMPLE_NAME}"
    
    echo ""
    echo "   === 处理 ${SAMPLE} ==="
    SAMPLE_START_TIME=$(date +%s)
    echo "   开始时间: $(date '+%H:%M:%S')"
    
    if [ ! -f "${INPUT_VCF}" ]; then
        echo "   ✗ 输入文件不存在，跳过"
        continue
    fi
    
    echo "   输入文件: ${INPUT_VCF}"
    echo "   输出目录: ${OUTPUT_DIR}"
    echo ""
    
    # 运行SALAI-Net
    python3 /your_SALAI.py \
        --model-cp "${MODEL_PATH}" \
        -q "${INPUT_VCF}" \
        -r "${REF_VCF}" \
        -m "${REF_MAP}" \
        -o "${OUTPUT_DIR}"
    
    EXIT_CODE=$?
    
    SAMPLE_END_TIME=$(date +%s)
    SAMPLE_DURATION=$((SAMPLE_END_TIME - SAMPLE_START_TIME))
    
    echo ""
    if [ $EXIT_CODE -eq 0 ]; then
        echo "   ✓ ${SAMPLE} 处理成功"
        echo "   耗时: ${SAMPLE_DURATION} 秒"
        echo "   输出文件:"
        if [ -d "${OUTPUT_DIR}" ]; then
            find "${OUTPUT_DIR}" -maxdepth 1 -type f 2>/dev/null | head -10 | while read file; do
                echo "    - $(basename "$file") ($(ls -lh "$file" | awk '{print $5}'))"
            done || echo "   暂无输出文件"
        fi
    else
        echo "   ✗ ${SAMPLE} 处理失败 (退出代码: $EXIT_CODE)"
        echo "   耗时: ${SAMPLE_DURATION} 秒"
    fi
    
    echo "   结束时间: $(date '+%H:%M:%S')"
    echo ""
    
    # 短暂延迟
    sleep 1
done

TOTAL_END_TIME=$(date +%s)
TOTAL_DURATION=$((TOTAL_END_TIME - TOTAL_START_TIME))

echo "=== 处理完成 ==="
echo "完成时间: $(date)"
echo "总耗时: ${TOTAL_DURATION} 秒 (约 $((TOTAL_DURATION / 60)) 分钟)"
echo "输出目录: ${OUTPUT_BASE}"
echo ""
echo "结果汇总:"
ls -la "${OUTPUT_BASE}/"

