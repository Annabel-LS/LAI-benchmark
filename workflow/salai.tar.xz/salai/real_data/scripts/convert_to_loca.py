#!/usr/bin/env python3
import numpy as np
import pandas as pd
import argparse
import gzip

def open_maybe_gz(fname, mode='rt'):
    return gzip.open(fname, mode) if fname.endswith('.gz') else open(fname, mode)

def read_phased_columns(phased_file):
    """返回单倍型列名列表（每个样本两列）"""
    with open_maybe_gz(phased_file) as f:
        header = f.readline().strip().split('\t')
    # 前两列是 ID, POS，后面是每样本两个单倍型列
    hap_cols = header[2:]
    return hap_cols

def read_phased_snp_info(phased_file):
    """读取 ID 和 POS 列"""
    df = pd.read_csv(phased_file, sep='\t', usecols=[0,1], header=0)
    return df.iloc[:,0].values, df.iloc[:,1].values.astype(int)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pred", required=True, help="ancestry_prediction.npy file")
    parser.add_argument("--phased", required=True, help="Phased file (e.g., CHS_CEU_YRI_chr1.phased)")
    parser.add_argument("--output", required=True, help="Output .loca file")
    args = parser.parse_args()

    # 1. 加载预测数组
    pred = np.load(args.pred)
    print(f"Prediction shape: {pred.shape}")
    if pred.ndim == 3:
        labels = np.argmax(pred, axis=-1)  # (n_haps, n_snps)
    elif pred.ndim == 2:
        labels = pred
    else:
        raise ValueError(f"Unsupported dimension: {pred.ndim}")
    n_haps, n_snps = labels.shape

    # 2. 获取单倍型列名
    hap_cols = read_phased_columns(args.phased)
    if len(hap_cols) != n_haps:
        print(f"Warning: phased has {len(hap_cols)} hap columns, prediction has {n_haps} haps. Truncating/extending.")
        if len(hap_cols) > n_haps:
            hap_cols = hap_cols[:n_haps]
        else:
            # 补充通用名
            hap_cols.extend([f"extra_hap_{i}" for i in range(len(hap_cols), n_haps)])

    # 3. 获取 SNP 信息
    ids, pos = read_phased_snp_info(args.phased)
    if len(ids) < n_snps:
        print(f"Truncating predictions to {len(ids)} SNPs")
        labels = labels[:, :len(ids)]
        n_snps = len(ids)
    elif len(ids) > n_snps:
        ids = ids[:n_snps]
        pos = pos[:n_snps]

    # 4. 构建 DataFrame 并输出
    data = {'rsID': ids, 'POS': pos}
    for i, col in enumerate(hap_cols):
        data[col] = labels[i]
    df = pd.DataFrame(data)
    df.to_csv(args.output, sep='\t', index=False)
    print(f"Saved {args.output} with {n_snps} SNPs and {len(hap_cols)} haplotypes.")

if __name__ == "__main__":
    main()
