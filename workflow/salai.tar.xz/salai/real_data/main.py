#!/usr/bin/env python3
import os
import subprocess
import sys
import shutil
import logging
from datetime import datetime

# ========== 配置 ==========
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))   # real_data 目录
PROJECT_DIR = CURRENT_DIR                                  # 项目数据根目录（含 chr1/, chr2/...）
BATCH_SIZE = .
CONTROL_RANGES = "CHS:1-160 CEU:161-336 YRI:337-511"
EXPERIMENT_RANGES = "CHS:1-160 CEU:161-336"
CHROMOSOMES = list(range(1, 23))
SOURCE_DATA_DIR = "your_real_data"   # 外部源数据
MAIN_LOG = os.path.join(CURRENT_DIR, "main.log")

# SALAI-Net 根目录（real_data 的父目录）
BASE_DIR = os.path.dirname(CURRENT_DIR)

# 模型路径（注意双层 models）
MODEL_CP = os.path.join(BASE_DIR, "models", "models", "main_model", "models", "best_model.pth")

# 脚本路径
SALAI_SCRIPT = os.path.join(BASE_DIR, "src", "SALAI.py")
MAKE_REF_PANEL_SCRIPT = os.path.join(PROJECT_DIR, "scripts", "make_ref_panel.py")
CONVERT_SCRIPT = os.path.join(PROJECT_DIR, "scripts", "convert_to_loca.py")
# ==========================

# 检查必需脚本是否存在
for script in [SALAI_SCRIPT, MAKE_REF_PANEL_SCRIPT, CONVERT_SCRIPT]:
    if not os.path.exists(script):
        sys.stderr.write(f"错误: 缺少脚本 {script}\n")
        sys.exit(1)

# 设置主日志
def setup_main_logger():
    logger = logging.getLogger('main')
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(MAIN_LOG, mode='a', encoding='utf-8')
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

logger = setup_main_logger()

def run_cmd(cmd, description, log_file, dry_run=False):
    logger.info(f"执行: {description}")
    logger.info(f"命令: {cmd}")
    if dry_run:
        logger.info(f"[DRY RUN] 跳过实际执行")
        return True
    try:
        with open(log_file, 'w', encoding='utf-8') as log_f:
            proc = subprocess.Popen(cmd, shell=True, stdout=log_f, stderr=subprocess.STDOUT, text=True)
            proc.wait()
            if proc.returncode == 0:
                logger.info(f"{description} 成功完成 (日志: {log_file})")
                return True
            else:
                logger.error(f"{description} 失败，返回码 {proc.returncode} (日志: {log_file})")
                return False
    except Exception as e:
        logger.error(f"{description} 异常: {e}")
        return False

def select_chromosomes():
    logger.info("用户选择染色体")
    print("\n可用的染色体: 1-22")
    choice = input("请输入染色体编号（单个: 5, 多个用逗号: 1,3,5, 范围: 1-5, 或'all'）: ").strip()
    if choice.lower() == 'all':
        return CHROMOSOMES
    selected = []
    for part in choice.split(','):
        part = part.strip()
        if '-' in part:
            a, b = map(int, part.split('-'))
            selected.extend(range(a, b+1))
        else:
            if part:
                selected.append(int(part))
    selected = sorted(set(selected))
    selected = [c for c in selected if c in CHROMOSOMES]
    if not selected:
        logger.warning("未选择有效染色体，使用全部")
        return CHROMOSOMES
    logger.info(f"选择的染色体: {selected}")
    return selected

def select_group():
    logger.info("用户选择组别")
    print("\n组别选择:")
    print("1. 仅对照组 (control)")
    print("2. 仅实验组 (experiment)")
    print("3. 两者")
    g = input("请输入数字 (1/2/3): ").strip()
    if g == '1':
        groups = ['control']
    elif g == '2':
        groups = ['experiment']
    else:
        groups = ['control', 'experiment']
    logger.info(f"选择的组别: {groups}")
    return groups

def select_operation():
    logger.info("用户选择操作")
    print("\n操作选择:")
    print("1. 全流程 (复制 → 建面板 → 运行LAI → 转换)")
    print("2. 仅复制文件")
    print("3. 仅创建参考面板 (.map)")
    print("4. 仅运行 SALAI-Net (LAI)")
    print("5. 仅转换结果 (.loca)")
    print("6. 自定义步骤组合")
    op = input("请输入数字: ").strip()
    logger.info(f"选择的操作: {op}")
    return op

def custom_steps():
    steps = []
    print("\n请依次输入要执行的步骤（输入字母，完成后直接回车）:")
    print("  a. 复制文件")
    print("  b. 创建参考面板")
    print("  c. 运行 SALAI-Net")
    print("  d. 转换结果")
    while True:
        s = input("步骤 (a/b/c/d，直接回车结束): ").strip().lower()
        if not s:
            break
        if s in ['a','b','c','d']:
            steps.append(s)
        else:
            print("无效输入，请输入 a/b/c/d")
    logger.info(f"自定义步骤: {steps}")
    return steps

def get_paths(chr_num):
    chr_dir = os.path.join(PROJECT_DIR, f"chr{chr_num}")
    query_vcf = os.path.join(chr_dir, f"asw12_chr{chr_num}.vcf.gz")
    control_vcf = os.path.join(chr_dir, f"CHS_CEU_YRI_DE3_chr{chr_num}.vcf.gz")
    experiment_vcf = os.path.join(chr_dir, f"CHS_CEU_DE3_chr{chr_num}.vcf.gz")
    phased_file = os.path.join(chr_dir, f"asw12_chr{chr_num}.phased")
    log_dir = os.path.join(chr_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    return {
        'dir': chr_dir,
        'log_dir': log_dir,
        'query': query_vcf,
        'control_vcf': control_vcf,
        'experiment_vcf': experiment_vcf,
        'phased': phased_file,
        'control_map': os.path.join(chr_dir, "control.map"),
        'experiment_map': os.path.join(chr_dir, "experiment.map"),
        'control_out': os.path.join(chr_dir, "output_control"),
        'experiment_out': os.path.join(chr_dir, "output_experiment"),
        'control_pred': os.path.join(chr_dir, "output_control", "ancestry_prediction.npy"),
        'experiment_pred': os.path.join(chr_dir, "output_experiment", "ancestry_prediction.npy"),
        'control_loca': os.path.join(chr_dir, "output_control", "result.loca"),
        'experiment_loca': os.path.join(chr_dir, "output_experiment", "result.loca"),
    }

def copy_file_with_check(src, dst, description, dry_run=False, force_overwrite=False):
    if os.path.exists(dst):
        if force_overwrite:
            logger.info(f"覆盖已存在文件: {dst}")
        else:
            overwrite = input(f"文件 {dst} 已存在，是否覆盖？(y/N/skip_all): ").strip().lower()
            if overwrite == 'y':
                pass
            elif overwrite == 'skip_all':
                logger.info(f"用户选择跳过所有复制")
                return "skip_all"
            else:
                logger.info(f"跳过复制: {description}")
                return True
    logger.info(f"复制: {src} -> {dst}")
    if dry_run:
        return True
    try:
        shutil.copy2(src, dst)
        return True
    except Exception as e:
        logger.error(f"复制失败: {e}")
        return False

def step_copy_files(chr_num, paths, groups, dry_run=False):
    logger.info(f"开始复制文件: 染色体 {chr_num}")
    src_chr_dir = os.path.join(SOURCE_DATA_DIR, f"chr{chr_num}")
    if not os.path.isdir(src_chr_dir):
        logger.error(f"源染色体目录不存在: {src_chr_dir}")
        return False
    os.makedirs(paths['dir'], exist_ok=True)
    files_to_copy = [
        (paths['query'], f"your_asw_chr{chr_num}.vcf.gz"),
        (paths['control_vcf'], f"CHS_CEU_YRI_chr{chr_num}.vcf.gz"),
        (paths['experiment_vcf'], f"CHS_CEU_chr{chr_num}.vcf.gz"),
        (paths['phased'], f"your_asw_chr{chr_num}.phased"),
    ]
    force_overwrite = False
    for dst, src_filename in files_to_copy:
        src = os.path.join(src_chr_dir, src_filename)
        if not os.path.exists(src):
            logger.error(f"源文件不存在: {src}")
            return False
        if not force_overwrite and os.path.exists(dst):
            choice = input(f"文件 {dst} 已存在。覆盖？(y/N/skip_all): ").strip().lower()
            if choice == 'y':
                force_overwrite = True
            elif choice == 'skip_all':
                logger.info("用户选择跳过所有后续复制")
                return True
            else:
                continue
        result = copy_file_with_check(src, dst, src_filename, dry_run, force_overwrite)
        if result == "skip_all":
            return True
        if not result:
            return False
    logger.info(f"染色体 {chr_num} 复制完成")
    return True

def step_create_map(chr_num, paths, groups, dry_run=False):
    logger.info(f"创建参考面板: 染色体 {chr_num}")
    for g in groups:
        vcf = paths[f'{g}_vcf']
        map_file = paths[f'{g}_map']
        ranges = CONTROL_RANGES if g == 'control' else EXPERIMENT_RANGES
        if os.path.exists(map_file):
            logger.info(f"{g} map 已存在，跳过: {map_file}")
            continue
        log_file = os.path.join(paths['log_dir'], f"{g}_create_map_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        cmd = f"python {MAKE_REF_PANEL_SCRIPT} --vcf {vcf} --ranges \"{ranges}\" --output {map_file}"
        if not run_cmd(cmd, f"创建 {g} 参考面板", log_file, dry_run):
            return False
    return True

def step_run_salai(chr_num, paths, groups, dry_run=False):
    logger.info(f"运行 SALAI-Net: 染色体 {chr_num}")
    for g in groups:
        pred_file = paths[f'{g}_pred']
        out_dir = paths[f'{g}_out']
        
        # 如果预测文件已存在，跳过
        if os.path.exists(pred_file):
            logger.info(f"{g} 预测结果已存在，跳过: {pred_file}")
            continue
        
        # SALAI-Net 要求输出目录不存在，所以如果存在则删除（可能是之前失败残留）
        if os.path.exists(out_dir):
            logger.warning(f"输出目录已存在，将被删除: {out_dir}")
            if not dry_run:
                shutil.rmtree(out_dir)
                logger.info(f"已删除目录: {out_dir}")
        # 注意：不要在这里创建目录！让 SALAI.py 自己创建
        
        log_file = os.path.join(paths['log_dir'], f"{g}_salai_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        cmd = (f"python {SALAI_SCRIPT} --model-cp {MODEL_CP} "
               f"-q {paths['query']} -r {paths[f'{g}_vcf']} "
               f"-m {paths[f'{g}_map']} -o {out_dir} -b {BATCH_SIZE}")
        cmd = f"CUDA_VISIBLE_DEVICES='' {cmd}"
        if not run_cmd(cmd, f"运行 SALAI-Net ({g})", log_file, dry_run):
            return False
    return True

def step_convert(chr_num, paths, groups, dry_run=False):
    logger.info(f"转换结果: 染色体 {chr_num}")
    for g in groups:
        pred_file = paths[f'{g}_pred']
        loca_file = paths[f'{g}_loca']
        if os.path.exists(loca_file):
            logger.info(f"{g} loca 已存在，跳过: {loca_file}")
            continue
        if not os.path.exists(pred_file):
            logger.warning(f"{g} 预测文件不存在，跳过转换: {pred_file}")
            continue
        log_file = os.path.join(paths['log_dir'], f"{g}_convert_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        cmd = f"python {CONVERT_SCRIPT} --pred {pred_file} --phased {paths['phased']} --output {loca_file}"
        if not run_cmd(cmd, f"转换 {g} 结果到 .loca", log_file, dry_run):
            return False
    return True

def main():
    global SOURCE_DATA_DIR
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    logger.info("="*60)
    logger.info("SALAI-Net 交互式流程控制启动")
    logger.info("="*60)

    logger.info(f"当前源数据目录: {SOURCE_DATA_DIR} (应包含 chr1/, chr2/, ... 子目录)")
    change_src = input("是否修改源数据目录？(y/N): ").strip().lower()
    if change_src == 'y':
        new_src = input("请输入新的源数据目录路径: ").strip()
        if os.path.isdir(new_src):
            SOURCE_DATA_DIR = new_src
            logger.info(f"源数据目录已更新: {SOURCE_DATA_DIR}")
        else:
            logger.warning("目录无效，保持原有设置")

    chrs = select_chromosomes()
    groups = select_group()
    op = select_operation()

    if op == '1':
        steps = ['copy', 'map', 'run', 'convert']
    elif op == '2':
        steps = ['copy']
    elif op == '3':
        steps = ['map']
    elif op == '4':
        steps = ['run']
    elif op == '5':
        steps = ['convert']
    elif op == '6':
        steps_codes = custom_steps()
        step_map = {'a':'copy', 'b':'map', 'c':'run', 'd':'convert'}
        steps = [step_map[s] for s in steps_codes if s in step_map]
        if not steps:
            logger.warning("未选择任何步骤，退出")
            return
    else:
        logger.error("无效选择，退出")
        return

    dry = input("\n是否仅预览命令而不执行？(y/N): ").strip().lower() == 'y'
    if dry:
        logger.info("DRY RUN 模式：仅预览，不实际执行")

    for chr_num in chrs:
        logger.info(f"===== 开始处理染色体 {chr_num} =====")
        paths = get_paths(chr_num)

        if 'copy' not in steps:
            missing = []
            for key in ['query', 'control_vcf', 'experiment_vcf', 'phased']:
                if not os.path.exists(paths[key]):
                    missing.append(paths[key])
            if missing:
                logger.warning(f"缺少文件: {missing}")
                cont = input("是否继续？(y/N): ").strip().lower()
                if cont != 'y':
                    continue

        success = True
        for step in steps:
            if step == 'copy':
                success = step_copy_files(chr_num, paths, groups, dry)
            elif step == 'map':
                success = step_create_map(chr_num, paths, groups, dry)
            elif step == 'run':
                success = step_run_salai(chr_num, paths, groups, dry)
            elif step == 'convert':
                success = step_convert(chr_num, paths, groups, dry)
            if not success:
                logger.error(f"染色体 {chr_num} 处理失败，停止后续步骤")
                break
        if success:
            logger.info(f"染色体 {chr_num} 处理完成")
        else:
            logger.error(f"染色体 {chr_num} 处理失败")

    logger.info("所有任务结束")
    print("\n主程序日志已保存至:", MAIN_LOG)

if __name__ == "__main__":
    main()
