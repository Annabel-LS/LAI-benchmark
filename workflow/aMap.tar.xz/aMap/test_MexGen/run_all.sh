#!/bin/bash
# 文件名：fix_and_run_amap.sh

WORK_DIR="your_project_url"
cd "$WORK_DIR"

echo "========================================="
echo "修正路径问题并运行AMAP分析"
echo "========================================="

# 确认所有文件都在当前目录
echo "检查文件是否存在..."
ls -la *.phased

# 定义四代样本（根据您的实际文件名调整）
GENERATIONS=("40_ancestry" "60_ancestry" "80_ancestry" "100_ancestry")

for GEN in "${GENERATIONS[@]}"; do
    echo ""
    echo ">>> 处理 ${GEN} ..."
    
    # 检查文件是否存在
    GEN_FILE="${GEN}.phased"
    if [ ! -f "$GEN_FILE" ]; then
        echo "警告: 找不到文件 ${GEN_FILE}，跳过..."
        continue
    fi
    
    # 计算SNP数量
    TOTAL_LINES=$(wc -l < "$GEN_FILE")
    POSITION_COUNT=$((TOTAL_LINES - 1))
    echo "  SNP数量: ${POSITION_COUNT}"
    
    # 创建修正后的配置文件（使用相对路径）
    CONFIG_FILE="${GEN}_config_fixed.xml"
    cat > "$CONFIG_FILE" << EOF
<?xml version="1.0" ?>
<case>
    <positionCount>${POSITION_COUNT}</positionCount>
    <populations>
        <population id="${GEN}">
            <type>sample</type>
            <ordinal>0</ordinal>
            <fileName>${GEN_FILE}</fileName>
        </population>
        <population id="chs">
            <type>reference</type>
            <ordinal>2</ordinal>
            <fileName>${your_ref1}</fileName>
        </population>
        <population id="yri">
            <type>reference</type>
            <ordinal>1</ordinal>
            <fileName>${your_ref2}</fileName>
        </population>
    </populations>
    <outputDir>results_${GEN}</outputDir>
    <minWinSize>20</minWinSize>
    <winStep>10</winStep>
    <maxWinSize>200</maxWinSize>
</case>
EOF
    
    echo "  修正的配置文件已创建: ${CONFIG_FILE}"
    
    # 创建输出目录
    mkdir -p "results_${GEN}"
    
    # 运行AMAP（使用相对路径配置）
    echo "  正在运行AMAP分析..."
    java -Xmx8g -jar amap.jar "${CONFIG_FILE}"
    
    if [ $? -eq 0 ]; then
        echo "  ✓ ${GEN} AMAP分析完成"
    else
        echo "  ✗ ${GEN} AMAP分析失败"
    fi
done

echo ""
echo "========================================="
echo "所有分析已完成！"
echo "========================================="
