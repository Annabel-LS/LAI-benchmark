#!/usr/bin/env python3
"""
aMAP 速度测试脚本 (完整版)
功能：
- 从完整的 99 人混合文件中提取指定数量的样本（随机抽样）
- 为每个样本量生成 aMAP 配置文件并运行
- 记录运行时间并输出 CSV 结果
用法：
    python speed_test.py --full_file <文件> --amap_jar <jar路径> --samples 20 60 80 99 --output_dir <输出目录>
"""

import os
import sys
import time
import random
import subprocess
import argparse
import pandas as pd
import numpy as np
from pathlib import Path

class aMAPSpeedTester:
    def __init__(self, amap_jar, output_dir="speed_test_results"):
        self.amap_jar = amap_jar
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir = self.output_dir / "temp_configs"
        self.temp_dir.mkdir(exist_ok=True)
        self.sample_files_dir = self.output_dir / "sample_files"
        self.sample_files_dir.mkdir(exist_ok=True)
        self.results = []

    def get_sample_ids_from_full_file(self, full_file):
        """
        从完整文件的标题行提取所有样本ID（如 NA00000）
        """
        with open(full_file, 'r') as f:
            header = f.readline().strip()
        # 尝试常见分隔符
        if '\t' in header:
            sep = '\t'
        elif ',' in header:
            sep = ','
        else:
            sep = ' '
        cols = header.split(sep)
        # 固定列通常是 ID 和 POS
        fixed_cols = ['ID', 'POS']
        sample_cols = [c for c in cols if c not in fixed_cols]
        sample_ids = set()
        for c in sample_cols:
            # 处理格式如 NA00000_A 或 NA00000
            if '_' in c:
                sid = c.split('_')[0]
            else:
                # 假设最后一个字符是 A/B
                sid = c[:-1] if c[-1] in ['A','B'] else c
            sample_ids.add(sid)
        sample_ids = sorted(list(sample_ids))
        print(f"从 {full_file} 中识别到 {len(sample_ids)} 个样本")
        return sample_ids

    def extract_samples(self, full_file, sample_ids, output_file):
        """
        从完整文件中提取指定样本的单倍型列，输出为制表符分隔的文件
        """
        # 读取完整文件（自动检测分隔符）
        try:
            df = pd.read_csv(full_file, sep='\t', dtype=str)
            if df.shape[1] == 1:
                df = pd.read_csv(full_file, sep=',', dtype=str)
            if df.shape[1] == 1:
                df = pd.read_csv(full_file, sep=' ', dtype=str)
        except Exception as e:
            print(f"读取文件失败: {e}")
            return False

        # 确定列名
        all_cols = df.columns.tolist()
        fixed_cols = ['ID', 'POS']
        # 确保固定列存在
        for col in fixed_cols:
            if col not in all_cols:
                print(f"错误：文件中缺少 {col} 列")
                return False

        # 构建需要保留的列
        keep_cols = fixed_cols.copy()
        sample_cols = [c for c in all_cols if c not in fixed_cols]
        for sid in sample_ids:
            # 匹配以 sid_ 开头的列，或 sid 结尾的列
            matched = [c for c in sample_cols if c.startswith(f"{sid}_") or c.startswith(f"{sid}.") or c == f"{sid}A" or c == f"{sid}B"]
            keep_cols.extend(matched)

        if len(keep_cols) == len(fixed_cols):
            print(f"警告：未找到样本 {sample_ids} 对应的列")
            return False

        df_sub = df[keep_cols]
        df_sub.to_csv(output_file, sep='\t', index=False)
        print(f"已生成 {output_file}，包含 {len(keep_cols)-2} 个单倍型列")
        return True

    def create_config(self, sample_file, output_subdir, config_name):
        """
        生成 aMAP 配置文件
        """
        output_path = self.output_dir / output_subdir
        output_path.mkdir(parents=True, exist_ok=True)

        config_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<config>
    <positionCount>SNP count</positionCount>
    <populations>
        <!-- 测试样本 -->
        <population>
            <id>test_sample</id>
            <type>sample</type>
            <ordinal>0</ordinal>
            <fileName>{sample_file}</fileName>
        </population>
        <!-- 参考群体 YRI -->
        <population>
            <id>YRI</id>
            <type>reference</type>
            <ordinal>1</ordinal>
            <fileName>{your_ref1}</fileName>
        </population>
        <!-- 参考群体 CHS -->
        <population>
            <id>CHS</id>
            <type>reference</type>
            <ordinal>2</ordinal>
            <fileName>{your_ref2}</fileName>
        </population>
    </populations>
    <outputDir>{output_path}</outputDir>
    <minWinSize>20</minWinSize>
    <winStep>10</winStep>
    <maxWinSize>200</maxWinSize>
</config>
"""
        config_path = self.temp_dir / config_name
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(config_content)
        return config_path

    def run_amap(self, config_file):
        """
        运行 aMAP 并返回运行时间（秒）
        """
        cmd = f"java -jar {self.amap_jar} {config_file}"
        print(f"执行命令: {cmd}")
        start = time.perf_counter()
        try:
            # 重定向输出到日志文件
            log_file = self.output_dir / "run_logs" / f"{config_file.stem}.log"
            log_file.parent.mkdir(exist_ok=True)
            with open(log_file, 'w') as log:
                result = subprocess.run(cmd, shell=True, stdout=log, stderr=log, timeout=7200)
            end = time.perf_counter()
            elapsed = end - start
            if result.returncode != 0:
                print(f"警告：aMAP 返回非零退出码 {result.returncode}")
            return elapsed
        except subprocess.TimeoutExpired:
            print(f"错误：aMAP 运行超时（>7200秒）")
            return None
        except Exception as e:
            print(f"运行 aMAP 时出错: {e}")
            return None

    def run_tests(self, full_file, sample_counts):
        """
        对每个样本数量执行完整测试流程
        """
        # 1. 获取所有样本ID
        all_sample_ids = self.get_sample_ids_from_full_file(full_file)
        total_available = len(all_sample_ids)
        if total_available < max(sample_counts):
            print(f"错误：完整文件中只有 {total_available} 个样本，无法抽取 {max(sample_counts)} 个")
            sys.exit(1)

        # 2. 对每个样本数量进行测试
        for n in sample_counts:
            print(f"\n{'='*60}")
            print(f"测试样本数量: {n}")
            print(f"{'='*60}")

            # 准备样本文件
            if n == total_available:
                sample_file = full_file
                print(f"使用完整文件: {sample_file}")
            else:
                # 随机抽取 n 个样本
                selected_ids = random.sample(all_sample_ids, n)
                sample_file = self.sample_files_dir / f"samples_{n}.phased"
                if sample_file.exists():
                    print(f"使用已有文件: {sample_file}")
                else:
                    success = self.extract_samples(full_file, selected_ids, str(sample_file))
                    if not success:
                        print(f"无法生成 {n} 个样本的文件，跳过该测试")
                        continue

            # 生成配置文件
            config_file = self.create_config(str(sample_file), f"output_{n}samples", f"config_{n}.xml")

            # 运行 aMAP
            elapsed = self.run_amap(config_file)
            if elapsed is not None:
                self.results.append({
                    'num_samples': n,
                    'time_seconds': elapsed,
                    'time_minutes': elapsed / 60
                })
                print(f"运行时间: {elapsed:.2f} 秒 ({elapsed/60:.2f} 分钟)")
            else:
                print(f"样本数 {n} 的测试失败")

    def save_results(self):
        """保存结果到 CSV"""
        if not self.results:
            print("没有结果可保存")
            return
        df = pd.DataFrame(self.results)
        df = df.sort_values('num_samples')
        csv_path = self.output_dir / "speed_results.csv"
        df.to_csv(csv_path, index=False)
        print(f"\n结果已保存到 {csv_path}")

def main():
    parser = argparse.ArgumentParser(description='测试 aMAP 在不同样本量下的运行速度')
    parser.add_argument('--full_file', required=True, help='完整的 99 人混合文件路径（HapMap 格式）')
    parser.add_argument('--amap_jar', required=True, help='amap.jar 文件路径')
    parser.add_argument('--samples', type=int, nargs='+', default=[20, 60, 80, 99],
                        help='要测试的样本数量列表（空格分隔）')
    parser.add_argument('--output_dir', default='speed_test_results', help='输出目录')
    args = parser.parse_args()

    # 检查必要文件
    if not os.path.exists(args.full_file):
        print(f"错误：完整样本文件不存在: {args.full_file}")
        sys.exit(1)
    if not os.path.exists(args.amap_jar):
        print(f"错误：amap.jar 不存在: {args.amap_jar}")
        sys.exit(1)

    tester = aMAPSpeedTester(args.amap_jar, args.output_dir)
    tester.run_tests(args.full_file, args.samples)
    tester.save_results()

if __name__ == "__main__":
    main()
