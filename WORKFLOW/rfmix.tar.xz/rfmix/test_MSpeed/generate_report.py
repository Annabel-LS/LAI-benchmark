#!/usr/bin/env python3
# generate_report.py
import os
import sys
import pandas as pd
import matplotlib
matplotlib.use('Agg') # 为了在无图形界面的服务器上运行
import matplotlib.pyplot as plt

def plot_runtime_vs_snps(df, output_file, mode_name):
    """绘制运行时间与SNP数量的关系图"""
    # 按SNP数量排序
    df_sorted = df.sort_values('SNP_Count')
    x = df_sorted['SNP_Count']
    y = df_sorted['Time_Seconds']

    plt.figure(figsize=(12, 8))
    plt.plot(x, y, marker='o', linestyle='-', color='b', markersize=8)
    
    # 标题和标签
    plt.title(f'RFMIX Performance Test - {mode_name} Mode', fontsize=16, fontweight='bold')
    plt.xlabel('Number of SNPs', fontsize=12)
    plt.ylabel('Running Time (seconds)', fontsize=12)
    
    # 网格
    plt.grid(True, alpha=0.3)
    
    # X轴使用对数刻度，以便更好地展示数量级差异
    plt.xscale('log')
    
    # 手动设置X轴刻度标签，避免科学计数法
    # 获取当前刻度位置
    xticks = plt.xticks()[0]
    # 过滤掉小于1000和大于最大值的刻度
    xticks = [tick for tick in xticks if 100 <= tick <= max(x)*1.5]
    
    # 格式化标签为 K 或 M
    labels = []
    for tick in xticks:
        if tick >= 1_000_000:
            labels.append(f'{tick/1_000_000:.1f}M')
        elif tick >= 1_000:
            labels.append(f'{tick/1_000:.0f}K')
        else:
            labels.append(f'{int(tick)}')
    
    plt.xticks(xticks, labels)

    # 在每个点上方添加时间标注
    for i, (snp, time_sec) in enumerate(zip(x, y)):
        # 格式化时间
        if time_sec < 60:
            time_str = f"{time_sec:.1f}s"
        elif time_sec < 3600:
            time_str = f"{time_sec/60:.1f}m"
        else:
            time_str = f"{time_sec/3600:.1f}h"
        
        plt.annotate(time_str, 
                    (snp, time_sec), 
                    textcoords="offset points", 
                    xytext=(0,10), 
                    ha='center', 
                    fontsize=9,
                    bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7))

    # 添加性能摘要文本框
    stats_text = (
        f"Performance Summary:\n"
        f"Test Mode: {mode_name}\n"
        f"Data Points: {len(df_sorted)}\n"
        f"Total Time: {y.sum():.1f} s\n"
        f"Min Time: {y.min():.2f} s\n"
        f"Max Time: {y.max():.2f} s\n"
        f"Avg Time: {y.mean():.2f} s"
    )
    
    props = dict(boxstyle='round', facecolor='wheat', alpha=0.8)
    plt.gca().text(0.02, 0.98, stats_text, transform=plt.gca().transAxes, fontsize=10,
            verticalalignment='top', bbox=props, fontfamily='monospace')

    plt.tight_layout()
    plt.savefig(output_file, dpi=300)
    plt.close()
    
    print(f"图表已生成: {output_file}")

def main():
    # 定义结果目录和输出目录
    RESULTS_DIR = "rfmix_results" # 必须与 run_test.py 中的输出目录一致
    OUTPUT_DIR = "rfmix_results"
    
    # 检查命令行参数
    if len(sys.argv) != 2:
        print("用法: python generate_report.py [quick|full]")
        print("错误: 请指定测试模式")
        sys.exit(1)
    
    test_mode = sys.argv[1].lower()
    if test_mode not in ['quick', 'full']:
        print("错误: 模式必须是 'quick' 或 'full'")
        sys.exit(1)
    
    # 定义文件路径
    input_file = os.path.join(RESULTS_DIR, f"timing_{test_mode}.tsv")
    output_file = os.path.join(OUTPUT_DIR, f"rfmix_performance_{test_mode}.png")
    
    # 检查输入文件是否存在
    if not os.path.exists(input_file):
        print(f"错误: 找不到结果文件 '{input_file}'")
        print(f"请确保测试已经成功运行。")
        sys.exit(1)
    
    # 读取数据
    try:
        # 跳过注释行，读取tsv
        df = pd.read_csv(input_file, sep='\t', comment='#')
        # 只保留成功运行的记录 (Time_Seconds > 0)
        df_valid = df[df['Time_Seconds'] > 0]
        
        if len(df_valid) == 0:
            print(f"警告: 文件 '{input_file}' 中没有有效的成功记录。")
            sys.exit(1)
            
        print(f"成功加载 {len(df_valid)} 条有效记录。")
        plot_runtime_vs_snps(df_valid, output_file, test_mode.upper())
        
    except Exception as e:
        print(f"处理数据时出错: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
