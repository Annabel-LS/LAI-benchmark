#!/usr/bin/env python3
"""
独立绘图脚本：根据 timings.csv 生成运行时间 vs 样本数折线图
用法：python plot_speed_results.py <timings.csv> <output.png>
"""

import pandas as pd
import matplotlib.pyplot as plt
import sys
import os

def get_safe_font():
    """检测系统可用字体，返回一个安全的 sans-serif 字体名称"""
    from matplotlib.font_manager import FontManager
    fm = FontManager()
    available = [f.name for f in fm.ttflist]
    # 优先使用 DejaVu Sans（通常 Linux 下存在），其次使用 Arial 或通用 sans-serif
    for font in ['DejaVu Sans', 'Arial', 'Liberation Sans', 'sans-serif']:
        if font in available or font == 'sans-serif':
            return font
    return 'sans-serif'

def main():
    if len(sys.argv) != 3:
        print("用法: python plot_speed_results.py <timings.csv> <output.png>")
        sys.exit(1)
    
    csv_file = sys.argv[1]
    out_png = sys.argv[2]
    
    if not os.path.exists(csv_file):
        print(f"错误: 文件 {csv_file} 不存在")
        sys.exit(1)
    
    df = pd.read_csv(csv_file)
    # 确保 runtime 列为数值型
    df['runtime_seconds'] = pd.to_numeric(df['runtime_seconds'], errors='coerce')
    df = df.dropna(subset=['runtime_seconds'])
    
    # 按样本数排序
    df = df.sort_values('sample_size')
    
    font_name = get_safe_font()
    print(f"使用字体: {font_name}")
    
    plt.figure(figsize=(8, 6), dpi=600)
    plt.plot(df['sample_size'], df['runtime_seconds'], 
             marker='o', linestyle='-', linewidth=2, markersize=8, color='#1f77b4')
    
    # 添加数据标签，交替上下位置
    offsets = [15, -15, 15, -15]   # 正数表示向上偏移（点上方），负数向下
    
    for i, (x, y) in enumerate(zip(df['sample_size'], df['runtime_seconds'])):
        label = f"{y:.2f}s"
        offset = offsets[i] if i < len(offsets) else 10
        va = 'bottom' if offset > 0 else 'top'
        plt.annotate(label, 
                     xy=(x, y), 
                     xytext=(0, offset),
                     textcoords='offset points',
                     ha='center', 
                     va=va,
                     fontsize=9,
                     fontname=font_name)
    
    plt.xlabel('Number of Samples', fontsize=12, fontname=font_name)
    plt.ylabel('Runtime (seconds)', fontsize=12, fontname=font_name)
    plt.title('RFMix Runtime vs Sample Size', fontsize=14, fontname=font_name)
    plt.grid(True, linestyle='--', alpha=0.6)
    
    ax = plt.gca()
    for tick in ax.get_xticklabels():
        tick.set_fontname(font_name)
    for tick in ax.get_yticklabels():
        tick.set_fontname(font_name)
    
    plt.tight_layout()
    plt.savefig(out_png, dpi=600)
    print(f"图表已保存: {out_png}")

if __name__ == "__main__":
    main()
