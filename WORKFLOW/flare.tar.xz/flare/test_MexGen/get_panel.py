#!/usr/bin/env python3
"""
根据VCF文件创建参考面板
功能：
1. 从VCF文件中提取样本名
2. 去掉样本名后缀（最后一个下划线及其后面的部分）
3. 根据前缀分配参考面板名称：
   - HG开头 -> panel_A
   - NA开头 -> panel_B
   - 其他开头 -> other
"""

import sys
import gzip
import subprocess
import os

def extract_samples_from_vcf(vcf_file):
    """从VCF文件中提取样本名"""
    samples = []
    
    # 检查文件是否gzip压缩
    if vcf_file.endswith('.gz'):
        open_func = gzip.open
        mode = 'rt'
    else:
        open_func = open
        mode = 'r'
    
    try:
        with open_func(vcf_file, mode) as f:
            for line in f:
                if line.startswith('#CHROM'):
                    # 这一行包含样本名
                    parts = line.strip().split('\t')
                    # 样本从第9列开始
                    samples = parts[9:]
                    break
        return samples
    except Exception as e:
        print(f"错误: 无法读取VCF文件: {e}")
        return []

def extract_samples_using_bcftools(vcf_file):
    """使用bcftools提取样本名（更可靠）"""
    try:
        # 运行bcftools query命令获取样本名
        result = subprocess.run(['bcftools', 'query', '-l', vcf_file],
                               capture_output=True, text=True, check=True)
        samples = result.stdout.strip().split('\n')
        return [s for s in samples if s]  # 移除空行
    except subprocess.CalledProcessError as e:
        print(f"错误: bcftools命令执行失败: {e}")
        print(f"stderr: {e.stderr}")
        return []
    except FileNotFoundError:
        print("错误: bcftools未安装。请先安装bcftools。")
        print("安装方法: conda install bcftools 或 sudo apt-get install bcftools")
        return []

def remove_suffix(sample_name):
    """去掉样本名的后缀（最后一个下划线及其后面的部分）"""
    # 找到最后一个下划线的位置
    last_underscore = sample_name.rfind('_')
    if last_underscore != -1:
        # 去掉最后一个下划线及其后面的部分
        return sample_name[:last_underscore]
    else:
        # 没有下划线，直接返回原样
        return sample_name

def assign_panel_name(sample_without_suffix):
    """根据样本名前缀分配参考面板名称"""
    if sample_without_suffix.startswith('HG'):
        return 'panel_A'
    elif sample_without_suffix.startswith('NA'):
        return 'panel_B'
    else:
        return 'other'

def create_ref_panel(vcf_file, output_file):
    """创建参考面板文件"""
    
    print(f"正在处理VCF文件: {vcf_file}")
    
    # 方法1: 使用bcftools提取样本名（推荐）
    samples = extract_samples_using_bcftools(vcf_file)
    
    # 如果bcftools失败，尝试方法2: 直接读取VCF文件
    if not samples:
        print("尝试直接读取VCF文件...")
        samples = extract_samples_from_vcf(vcf_file)
    
    if not samples:
        print("错误: 无法从VCF文件中提取样本名")
        return False
    
    print(f"从VCF文件中提取到 {len(samples)} 个样本")
    
    # 处理样本并写入输出文件
    total_samples = 0
    hg_count = 0
    na_count = 0
    other_count = 0
    
    with open(output_file, 'w') as out_f:
        for original_sample in samples:
            total_samples += 1
            
            # 去掉后缀
            sample_no_suffix = remove_suffix(original_sample)
            
            # 分配面板名称
            panel_name = assign_panel_name(sample_no_suffix)
            
            # 更新统计
            if panel_name == 'panel_A':
                hg_count += 1
            elif panel_name == 'panel_B':
                na_count += 1
            else:
                other_count += 1
            
            # 写入文件
            out_f.write(f"{sample_no_suffix}\t{panel_name}\n")
            
            # 显示进度
            if total_samples % 100 == 0:
                print(f"已处理 {total_samples} 个样本...")
    
    # 显示统计信息
    print("\n=== 处理完成 ===")
    print(f"总样本数: {total_samples}")
    print(f"HG开头 (panel_A): {hg_count}")
    print(f"NA开头 (panel_B): {na_count}")
    print(f"其他前缀 (other): {other_count}")
    print(f"\n输出文件: {output_file}")
    
    # 显示输出文件的前几行
    print("\n输出文件示例（前10行）:")
    try:
        with open(output_file, 'r') as f:
            lines = [next(f) for _ in range(min(10, total_samples))]
            for line in lines:
                print(line.strip())
    except:
        pass
    
    return True

def main():
    """主函数"""
    
    # 检查命令行参数
    if len(sys.argv) != 3:
        print("使用方法: python create_ref_panel.py input.vcf.gz output_ref_panel.txt")
        print("示例: python create_ref_panel.py my_data.vcf.gz ref_panel.txt")
        sys.exit(1)
    
    input_vcf = sys.argv[1]
    output_file = sys.argv[2]
    
    # 检查输入文件是否存在
    if not os.path.exists(input_vcf):
        print(f"错误: 输入文件不存在: {input_vcf}")
        sys.exit(1)
    
    # 创建参考面板
    success = create_ref_panel(input_vcf, output_file)
    
    if not success:
        sys.exit(1)

if __name__ == "__main__":
    main()
