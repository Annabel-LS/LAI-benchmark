#!/bin/bash
set -e

PROJECT_DIR="your_project"
FLARE_JAR="$PROJECT_DIR/flare.jar"
INPUT_DIR="$PROJECT_DIR/input"
RESULTS_DIR="$PROJECT_DIR/result"
LOGS_DIR="$PROJECT_DIR/logs"

mkdir -p "$INPUT_DIR" "$RESULTS_DIR" "$LOGS_DIR"

FLARE_MEMORY="16g"
FLARE_THREADS=4

REF_VCF="$PROJECT_DIR/refenrece/ref.vcf.gz"
REF_PANEL="$PROJECT_DIR/refenrece/ref-panel.txt"
GENETIC_MAP="$PROJECT_DIR/refenrece/plink.chr1.GRCh38.map"

# 检查文件
for f in "$REF_VCF" "$REF_PANEL" "$GENETIC_MAP"; do
  [ -f "$f" ] || { echo "Missing: $f"; exit 1; }
done

SAMPLE_FILES=("$INPUT_DIR"/*.vcf.gz)
[ ${#SAMPLE_FILES[@]} -gt 0 ] || { echo "No samples"; exit 1; }

SUMMARY="$RESULTS_DIR/summary.txt"
echo -e "Sample\tStatus\tTime(s)" > "$SUMMARY"

for sample in "${SAMPLE_FILES[@]}"; do
  name=$(basename "$sample" .vcf.gz)
  out="$RESULTS_DIR/${name}_out"
  log="$LOGS_DIR/${name}.log"
  
  echo "Running: $name"
  start=$(date +%s)
  
  # ⚠️ 所有参数写在一行！避免 \ 换行问题
  java -Xmx$FLARE_MEMORY -jar "$FLARE_JAR" \
    ref="$REF_VCF" \
    ref-panel="$REF_PANEL" \
    gt="$sample" \
    map="$GENETIC_MAP" \
    out="$out" \
    nthreads="$FLARE_THREADS" \
    array=false \
    min-maf=0 \
    min-mac=0 \
    2>&1 | tee "$log"
  
  status=$([ ${PIPESTATUS[0]} -eq 0 ] && echo "OK" || echo "FAIL")
  time=$(( $(date +%s) - start ))
  echo -e "$name\t$status\t$time" >> "$SUMMARY"
  sleep 1
done

echo "Done. Summary:"
cat "$SUMMARY"
