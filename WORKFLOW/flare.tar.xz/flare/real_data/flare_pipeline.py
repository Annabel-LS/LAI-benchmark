#!/usr/bin/env python3
"""
flare_pipeline.py - 批量运行 FLARE 祖源推断及结果转换
"""

import os
import sys
import subprocess
import shutil
import time
from datetime import datetime

# ==================== 配置区域 ====================
PROJECT_DIR = "your_project"
RAW_DATA_DIR = "your_real_data"
GENETIC_MAP = "your_genetic_map"          # 位于 PROJECT_DIR 下
FLARE_JAR = "flare.jar"                  # 位于 PROJECT_DIR 下
CONVERT_SCRIPT = "FlareResult_to_loca.py"  # 转换脚本路径（绝对路径或相对路径）
MAPPING_STRING = "your_reflect"     # 转换时的祖源数字映射

THREADS = 46
EM = True
PROBS = False
MIN_MAC = 0
MIN_MAF = 0
SEED = 12345
JAVA_MEM = "32g"

# 样本索引分配（1起始）
CTL_CHS_RANGE = (1, 160)
CTL_CEU_RANGE = (161, 336)
CTL_YRI_RANGE = (337, 511)
EXP_CHS_RANGE = (1, 160)
EXP_CEU_RANGE = (161, 336)

CHROMOSOMES = [str(i) for i in range(1, 23)]

# ==================== 辅助函数 ====================
def setup_directories():
    os.makedirs(PROJECT_DIR, exist_ok=True)
    logs_dir = os.path.join(PROJECT_DIR, "logs")
    os.makedirs(logs_dir, exist_ok=True)
    return logs_dir

def log_message(log_file, msg, also_print=True):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    full_msg = f"[{timestamp}] {msg}"
    with open(log_file, "a") as f:
        f.write(full_msg + "\n")
    if also_print:
        print(full_msg)

def run_command(cmd, log_file, description):
    log_message(log_file, f"执行命令: {' '.join(cmd)}")
    start = time.time()
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        elapsed = time.time() - start
        log_message(log_file, f"命令完成，退出码: {proc.returncode}, 耗时: {elapsed:.2f}秒")
        if proc.stdout:
            log_message(log_file, f"STDOUT:\n{proc.stdout.strip()}")
        if proc.stderr:
            log_message(log_file, f"STDERR:\n{proc.stderr.strip()}")
        if proc.returncode == 0:
            log_message(log_file, f"{description} 成功")
            return True, proc.stdout, proc.stderr
        else:
            log_message(log_file, f"{description} 失败，退出码 {proc.returncode}")
            return False, proc.stdout, proc.stderr
    except Exception as e:
        log_message(log_file, f"执行异常: {str(e)}")
        return False, "", str(e)

def check_file_exists(filepath, description, log_file):
    if not os.path.isfile(filepath):
        log_message(log_file, f"错误: {description} 不存在: {filepath}")
        return False
    if os.path.getsize(filepath) == 0:
        log_message(log_file, f"错误: {description} 为空: {filepath}")
        return False
    return True

# ==================== 功能1：复制 VCF.gz ====================
def func_copy_vcf(chrom_list, log_dir):
    log_file = os.path.join(log_dir, f"func1_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    success_chroms = []
    fail_chroms = []
    for chrom in chrom_list:
        chrom_dir = os.path.join(PROJECT_DIR, f"chr{chrom}")
        control_dir = os.path.join(chrom_dir, "control")
        exp_dir = os.path.join(chrom_dir, "experiment")
        os.makedirs(control_dir, exist_ok=True)
        os.makedirs(exp_dir, exist_ok=True)

        raw_chrom_dir = os.path.join(RAW_DATA_DIR, f"chr{chrom}")
        if not os.path.isdir(raw_chrom_dir):
            log_message(log_file, f"警告: 原始数据目录不存在 {raw_chrom_dir}，跳过染色体 {chrom}", also_print=True)
            fail_chroms.append(chrom)
            continue

        # 定义源文件路径
        study_src = os.path.join(raw_chrom_dir, f"your_asw_chr{chrom}.vcf.gz")
        control_ref_src = os.path.join(raw_chrom_dir, f"CHS_CEU_YRI_chr{chrom}.vcf.gz")
        exp_ref_src = os.path.join(raw_chrom_dir, f"CHS_CEU_chr{chrom}.vcf.gz")

        # 目标路径
        study_dst_control = os.path.join(control_dir, f"your_asw_chr{chrom}.vcf.gz")
        study_dst_exp = os.path.join(exp_dir, f"your_asw_chr{chrom}.vcf.gz")
        control_ref_dst = os.path.join(control_dir, f"CHS_CEU_YRI_chr{chrom}.vcf.gz")
        exp_ref_dst = os.path.join(exp_dir, f"CHS_CEU_chr{chrom}.vcf.gz")

        chrom_ok = True

        # 复制研究样本到 control 和 experiment
        for src, dst in [(study_src, study_dst_control), (study_src, study_dst_exp)]:
            if not os.path.isfile(src):
                log_message(log_file, f"错误: 研究样本源文件不存在 {src}", also_print=True)
                chrom_ok = False
                continue
            try:
                shutil.copy2(src, dst)
                log_message(log_file, f"复制成功: {src} -> {dst}")
            except Exception as e:
                log_message(log_file, f"复制失败: {src} -> {dst}, 错误: {str(e)}", also_print=True)
                chrom_ok = False

        # 复制对照组参考文件到 control
        if not os.path.isfile(control_ref_src):
            log_message(log_file, f"错误: 对照组参考文件不存在 {control_ref_src}", also_print=True)
            chrom_ok = False
        else:
            try:
                shutil.copy2(control_ref_src, control_ref_dst)
                log_message(log_file, f"复制成功: {control_ref_src} -> {control_ref_dst}")
            except Exception as e:
                log_message(log_file, f"复制失败: {control_ref_src} -> {control_ref_dst}, 错误: {str(e)}", also_print=True)
                chrom_ok = False

        # 复制实验组参考文件到 experiment
        if not os.path.isfile(exp_ref_src):
            log_message(log_file, f"错误: 实验组参考文件不存在 {exp_ref_src}", also_print=True)
            chrom_ok = False
        else:
            try:
                shutil.copy2(exp_ref_src, exp_ref_dst)
                log_message(log_file, f"复制成功: {exp_ref_src} -> {exp_ref_dst}")
            except Exception as e:
                log_message(log_file, f"复制失败: {exp_ref_src} -> {exp_ref_dst}, 错误: {str(e)}", also_print=True)
                chrom_ok = False

        if chrom_ok:
            success_chroms.append(chrom)
        else:
            fail_chroms.append(chrom)
    return success_chroms, fail_chroms

# ==================== 功能2：创建 ref-panel ====================
def create_refpanel(vcf_path, sample_ranges, output_path, log_file):
    cmd = ["bcftools", "query", "-l", vcf_path]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        log_message(log_file, f"bcftools 提取样本名失败: {proc.stderr}")
        return False
    samples = [s.strip() for s in proc.stdout.splitlines() if s.strip()]
    total = len(samples)
    max_idx = total
    for pop, (start, end) in sample_ranges.items():
        if end > max_idx:
            log_message(log_file, f"错误: 群体 {pop} 的结束索引 {end} 超过样本总数 {max_idx}")
            return False
    assigned = {}
    for pop, (start, end) in sample_ranges.items():
        for idx in range(start-1, end):
            if idx >= total:
                break
            samp = samples[idx]
            if samp in assigned:
                log_message(log_file, f"警告: 样本 {samp} 被重复分配，原群体 {assigned[samp]}，新群体 {pop}，将覆盖")
            assigned[samp] = pop
    unassigned = [s for s in samples if s not in assigned]
    if unassigned:
        log_message(log_file, f"警告: {len(unassigned)} 个样本未分配群体，将跳过")
    with open(output_path, "w") as f:
        for samp in samples:
            if samp in assigned:
                f.write(f"{samp}\t{assigned[samp]}\n")
    log_message(log_file, f"生成 ref-panel 文件: {output_path}，共 {len(assigned)} 行")
    return True

def func_create_refpanel(chrom_list, group, log_dir):
    if group not in ['control', 'experiment', 'both']:
        print("错误: group 必须是 control, experiment 或 both")
        return [], []
    log_file = os.path.join(log_dir, f"func2_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    success_list = []
    fail_list = []
    for chrom in chrom_list:
        for g in (['control', 'experiment'] if group == 'both' else [group]):
            chrom_dir = os.path.join(PROJECT_DIR, f"chr{chrom}", g)
            if not os.path.isdir(chrom_dir):
                log_message(log_file, f"目录不存在: {chrom_dir}，跳过", also_print=True)
                fail_list.append((chrom, g))
                continue
            if g == 'control':
                vcf_name = f"CHS_CEU_YRI_chr{chrom}.vcf.gz"
                ranges = {"CHS": CTL_CHS_RANGE, "CEU": CTL_CEU_RANGE, "YRI": CTL_YRI_RANGE}
            else:
                vcf_name = f"CHS_CEU_chr{chrom}.vcf.gz"
                ranges = {"CHS": EXP_CHS_RANGE, "CEU": EXP_CEU_RANGE}
            vcf_path = os.path.join(chrom_dir, vcf_name)
            if not os.path.isfile(vcf_path):
                log_message(log_file, f"参考VCF不存在: {vcf_path}，跳过", also_print=True)
                fail_list.append((chrom, g))
                continue
            out_path = os.path.join(chrom_dir, f"refpanel_{g}.txt")
            ok = create_refpanel(vcf_path, ranges, out_path, log_file)
            if ok:
                success_list.append((chrom, g))
            else:
                fail_list.append((chrom, g))
    return success_list, fail_list

# ==================== 功能3：运行 FLARE ====================
def run_flare_for_group(chrom, group, log_file):
    chrom_dir = os.path.join(PROJECT_DIR, f"chr{chrom}", group)
    if not os.path.isdir(chrom_dir):
        log_message(log_file, f"目录不存在: {chrom_dir}")
        return False
    if group == 'control':
        ref_vcf = f"CHS_CEU_YRI_chr{chrom}.vcf.gz"
        ref_panel = "refpanel_control.txt"
        out_prefix = "flare_control"
    else:
        ref_vcf = f"CHS_CEU_chr{chrom}.vcf.gz"
        ref_panel = "refpanel_experiment.txt"
        out_prefix = "flare_experiment"
    gt_vcf = f"your_asw_chr{chrom}.vcf.gz"
    map_subdir = "plink.GRCh38.map/no_chr_in_chrom_field"
    map_filename = f"plink.chr{chrom}.GRCh38.map"
    map_path = os.path.join(PROJECT_DIR, map_subdir, map_filename)
    flare_jar = os.path.join(PROJECT_DIR, FLARE_JAR)

    for fname in [ref_vcf, ref_panel, gt_vcf]:
        fpath = os.path.join(chrom_dir, fname)
        if not os.path.isfile(fpath):
            log_message(log_file, f"缺少必需文件: {fpath}")
            return False
    if not os.path.isfile(map_path):
        log_message(log_file, f"缺少遗传图谱: {map_path}")
        return False
    if not os.path.isfile(flare_jar):
        log_message(log_file, f"缺少 flare.jar: {flare_jar}")
        return False

    cmd = [
        "java", f"-Xmx{JAVA_MEM}", "-jar", flare_jar,
        f"ref={ref_vcf}",
        f"ref-panel={ref_panel}",
        f"gt={gt_vcf}",
        f"map={map_path}",
        f"out={out_prefix}",
        f"nthreads={THREADS}",
        f"em={str(EM).lower()}",
        f"probs={str(PROBS).lower()}",
        f"min-mac={MIN_MAC}",
        f"min-maf={MIN_MAF}",
        f"seed={SEED}"
    ]
    original_cwd = os.getcwd()
    os.chdir(chrom_dir)
    success, _, _ = run_command(cmd, log_file, f"FLARE 运行 {group} chr{chrom}")
    os.chdir(original_cwd)
    expected_out = [f"{out_prefix}.anc.vcf.gz", f"{out_prefix}.global.anc.gz", f"{out_prefix}.model", f"{out_prefix}.log"]
    all_exist = all(os.path.isfile(os.path.join(chrom_dir, f)) for f in expected_out)
    if success and all_exist:
        return True
    else:
        if not all_exist:
            log_message(log_file, f"输出文件缺失: {expected_out}")
        return False

def func_run_flare(chrom_list, group, log_dir):
    if group not in ['control', 'experiment', 'both']:
        print("错误: group 必须是 control, experiment 或 both")
        return [], []
    log_file = os.path.join(log_dir, f"func3_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    success_list = []
    fail_list = []
    for chrom in chrom_list:
        for g in (['control', 'experiment'] if group == 'both' else [group]):
            log_message(log_file, f"开始运行 FLARE: {g} chr{chrom}")
            ok = run_flare_for_group(chrom, g, log_file)
            if ok:
                success_list.append((chrom, g))
                log_message(log_file, f"FLARE 运行成功")
            else:
                fail_list.append((chrom, g))
                log_message(log_file, f"FLARE 运行失败")
    return success_list, fail_list

# ==================== 功能4：转换结果 ====================
def convert_anc_vcf(anc_vcf_path, output_loca_path, mapping_str, log_file):
    if not os.path.isfile(CONVERT_SCRIPT):
        log_message(log_file, f"转换脚本不存在: {CONVERT_SCRIPT}")
        return False
    cmd = ["python3", CONVERT_SCRIPT, "-i", anc_vcf_path, "-o", output_loca_path, "-m", mapping_str]
    success, _, _ = run_command(cmd, log_file, f"转换结果 {anc_vcf_path}")
    return success

def func_convert_results(chrom_list, group, log_dir, mapping_str=MAPPING_STRING):
    if group not in ['control', 'experiment', 'both']:
        print("错误: group 必须是 control, experiment 或 both")
        return [], []
    log_file = os.path.join(log_dir, f"func4_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    success_list = []
    fail_list = []
    for chrom in chrom_list:
        for g in (['control', 'experiment'] if group == 'both' else [group]):
            chrom_dir = os.path.join(PROJECT_DIR, f"chr{chrom}", g)
            if not os.path.isdir(chrom_dir):
                log_message(log_file, f"目录不存在: {chrom_dir}，跳过", also_print=True)
                fail_list.append((chrom, g))
                continue
            if g == 'control':
                anc_vcf = "flare_control.anc.vcf.gz"
                loca_out = "flare_control.loca"
            else:
                anc_vcf = "flare_experiment.anc.vcf.gz"
                loca_out = "flare_experiment.loca"
            anc_path = os.path.join(chrom_dir, anc_vcf)
            if not os.path.isfile(anc_path):
                log_message(log_file, f"找不到 .anc.vcf.gz 文件: {anc_path}", also_print=True)
                fail_list.append((chrom, g))
                continue
            out_path = os.path.join(chrom_dir, loca_out)
            ok = convert_anc_vcf(anc_path, out_path, mapping_str, log_file)
            if ok:
                success_list.append((chrom, g))
            else:
                fail_list.append((chrom, g))
    return success_list, fail_list

# ==================== 全流程 ====================
def run_full_pipeline(log_dir):
    print("\n=== 开始全流程处理 ===")
    # 功能1
    print("执行功能1: 复制VCF文件...")
    success1, fail1 = func_copy_vcf(CHROMOSOMES, log_dir)
    if fail1:
        print(f"功能1 部分失败，失败的染色体: {fail1}")
    # 功能2
    print("执行功能2: 创建 ref-panel...")
    success2, fail2 = func_create_refpanel(CHROMOSOMES, 'both', log_dir)
    # 功能3
    print("执行功能3: 运行 FLARE...")
    success3, fail3 = func_run_flare(CHROMOSOMES, 'both', log_dir)
    # 功能4
    print("执行功能4: 转换结果...")
    success4, fail4 = func_convert_results(CHROMOSOMES, 'both', log_dir)
    # 汇总
    print("\n=== 全流程完成 ===")
    print(f"功能1 复制: 成功 {len(success1)} 个染色体, 失败 {len(fail1)}")
    print(f"功能2 ref-panel: 成功 {len(success2)} 个, 失败 {len(fail2)}")
    print(f"功能3 FLARE: 成功 {len(success3)} 个, 失败 {len(fail3)}")
    print(f"功能4 转换: 成功 {len(success4)} 个, 失败 {len(fail4)}")
    summary_log = os.path.join(log_dir, "full_pipeline_summary.log")
    with open(summary_log, "w") as f:
        f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n")
        f.write(f"功能1 成功: {success1}\n失败: {fail1}\n")
        f.write(f"功能2 成功: {success2}\n失败: {fail2}\n")
        f.write(f"功能3 成功: {success3}\n失败: {fail3}\n")
        f.write(f"功能4 成功: {success4}\n失败: {fail4}\n")

# ==================== 主菜单 ====================
def parse_chromosomes(s):
    s = s.strip().lower()
    if s == 'all':
        return CHROMOSOMES[:]
    if '-' in s:
        parts = s.split('-')
        if len(parts) == 2:
            try:
                start = int(parts[0])
                end = int(parts[1])
                return [str(i) for i in range(start, end+1)]
            except:
                return []
    else:
        try:
            return [s]
        except:
            return []
    return []

def main():
    logs_dir = setup_directories()
    print(f"日志目录: {logs_dir}")
    print(f"项目目录: {PROJECT_DIR}")
    print(f"原始数据目录: {RAW_DATA_DIR}")
    while True:
        print("\n" + "="*50)
        print("FLARE 批量处理工具")
        print("1. 复制 VCF 文件（功能1）")
        print("2. 创建参考面板文件（功能2）")
        print("3. 运行 FLARE 祖源推断（功能3）")
        print("4. 转换结果文件（功能4）")
        print("5. 全流程自动执行（所有染色体，先 control 后 experiment）")
        print("6. 退出")
        choice = input("请选择操作 [1-6]: ").strip()
        if choice == '1':
            chrom_input = input("请输入染色体号（例如 5 或 1-22 或 all）: ").strip()
            chrom_list = parse_chromosomes(chrom_input)
            if not chrom_list:
                print("染色体输入无效")
                continue
            success, fail = func_copy_vcf(chrom_list, logs_dir)
            print(f"复制完成。成功: {success}, 失败: {fail}")
        elif choice == '2':
            chrom_input = input("请输入染色体号（例如 5 或 1-22 或 all）: ").strip()
            chrom_list = parse_chromosomes(chrom_input)
            if not chrom_list:
                print("染色体输入无效")
                continue
            group = input("请选择组别 (control/experiment/both): ").strip().lower()
            if group not in ['control', 'experiment', 'both']:
                print("组别无效")
                continue
            success, fail = func_create_refpanel(chrom_list, group, logs_dir)
            print(f"ref-panel 创建完成。成功: {success}, 失败: {fail}")
        elif choice == '3':
            chrom_input = input("请输入染色体号（例如 5 或 1-22 或 all）: ").strip()
            chrom_list = parse_chromosomes(chrom_input)
            if not chrom_list:
                print("染色体输入无效")
                continue
            group = input("请选择组别 (control/experiment/both): ").strip().lower()
            if group not in ['control', 'experiment', 'both']:
                print("组别无效")
                continue
            success, fail = func_run_flare(chrom_list, group, logs_dir)
            print(f"FLARE 运行完成。成功: {success}, 失败: {fail}")
        elif choice == '4':
            chrom_input = input("请输入染色体号（例如 5 或 1-22 或 all）: ").strip()
            chrom_list = parse_chromosomes(chrom_input)
            if not chrom_list:
                print("染色体输入无效")
                continue
            group = input("请选择组别 (control/experiment/both): ").strip().lower()
            if group not in ['control', 'experiment', 'both']:
                print("组别无效")
                continue
            mapping = input(f"请输入转换映射字符串（默认 {MAPPING_STRING}）: ").strip()
            if not mapping:
                mapping = MAPPING_STRING
            success, fail = func_convert_results(chrom_list, group, logs_dir, mapping)
            print(f"结果转换完成。成功: {success}, 失败: {fail}")
        elif choice == '5':
            run_full_pipeline(logs_dir)
        elif choice == '6':
            print("退出程序")
            break
        else:
            print("无效选项，请重新输入")

if __name__ == "__main__":
    if shutil.which("bcftools") is None:
        print("错误: bcftools 未在 PATH 中找到，请安装或配置环境变量。")
        sys.exit(1)
    if shutil.which("java") is None:
        print("错误: java 未在 PATH 中找到，请安装 Java 1.8+。")
        sys.exit(1)
    if not os.path.isfile(os.path.join(PROJECT_DIR, FLARE_JAR)):
        print(f"错误: {FLARE_JAR} 不存在于 {PROJECT_DIR}")
        sys.exit(1)
    if not os.path.isfile(os.path.join(PROJECT_DIR, GENETIC_MAP)):
        print(f"错误: 遗传图谱文件 {GENETIC_MAP} 不存在于 {PROJECT_DIR}")
        sys.exit(1)
    if not os.path.isfile(CONVERT_SCRIPT) and not shutil.which(CONVERT_SCRIPT):
        print(f"警告: 转换脚本 {CONVERT_SCRIPT} 未找到，功能4将不可用。")
    main()
