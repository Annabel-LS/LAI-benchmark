#!/usr/bin/env python3
"""
FlareResult_to_loca.py - 将flare生成的结果转换为画图所需的祖源格式

该脚本用于.anc.vcf.gz格式转为loca格式文件，支持以下参数：
  -i <sample.anc.vcf.gz> \
  -o sample.loca \
  -m "AFR:1,EUR:2,EAS:3"
使用方法：
python3 FlareResult_to_loca.py \
  -i chr1_Flare.anc.vcf.gz \
  -o chr.loca \
  -m "AFR:1,EUR:2,EAS:3"

使用方法：
python3 FlareResult_to_loca.py \
  -i 40_ancestry_out.anc.vcf.gz \
  -o chr.loca \
  -m "CHS:2,YRI:1"
"""

import gzip
import sys
import argparse

def process_vcf_line_multisample(line, ancestry_map):
    parts = line.strip().split("\t")
    format_fields = parts[8].split(":")
    try:
        an1_idx = format_fields.index("AN1")
        an2_idx = format_fields.index("AN2")
    except ValueError:
        return None
    pos = parts[1]
    results = []
    for sample_col in parts[9:]:
        fields = sample_col.split(":")
        try:
            an1 = int(fields[an1_idx])
            an2 = int(fields[an2_idx])
        except (ValueError, IndexError):
            an1 = an2 = 0
        an1_out = ancestry_map.get(an1, 0)
        an2_out = ancestry_map.get(an2, 0)
        results.append((an1_out, an2_out))
    return {"rsID": ".", "POS": pos, "samples": results}

def generate_ancestry_file(args):
    mapping_str = args.m.replace(':', '=')
    user_mapping = {}
    for pair in mapping_str.split(","):
        key, value = pair.split("=")
        user_mapping[key] = int(value)

    ancestry_name_to_index = {}
    sample_names = []
    with gzip.open(args.input, "rt") as infile, open(args.output, "w") as outfile:
        for line in infile:
            line = line.strip()
            if not line or line.startswith("##"):
                if line.startswith("##ANCESTRY"):
                    content = line.strip().replace("##ANCESTRY=<", "").rstrip(">")
                    pairs = content.split(",")
                    for pair in pairs:
                        key, value = pair.split("=")
                        ancestry_name_to_index[key] = int(value)
                continue
            if line.startswith("#CHROM"):
                final_mapping = {}
                for name, orig_idx in ancestry_name_to_index.items():
                    final_mapping[orig_idx] = user_mapping.get(name, "o")

                header = line.split("\t")
                sample_names = header[9:]
                cols = ["rsID", "POS"]
                for s in sample_names:
                    cols += [f"{s}_A", f"{s}_B"]
                outfile.write("\t".join(cols) + "\n")
                continue

            if not ancestry_name_to_index:
                continue
            result = process_vcf_line_multisample(line, final_mapping)
            if result is None:
                continue
            out_parts = [result["rsID"], result["POS"]]
            for a, b in result["samples"]:
                out_parts += [str(a), str(b)]
            outfile.write("\t".join(out_parts) + "\n")

def main():
    parser = argparse.ArgumentParser(description="Convert VCF with AN1/AN2 to ancestry matrix with custom population mapping.")
    parser.add_argument("-i", "--input", required=True, help="Input VCF.gz file")
    parser.add_argument("-o", "--output", required=True, help="Output txt file")
    parser.add_argument("-m", required=True, help="Population name to value mapping (e.g., 'panela=6,panelb=7' or 'panela:6,panelb:7')")
    args = parser.parse_args()

    try:
        generate_ancestry_file(args)
        print(f"Output file generated: {args.output}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
