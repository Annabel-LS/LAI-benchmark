#!/bin/bash
# flare运行时间与SNP数量关系测试 - 配置文件

# ============================================================================
# 1. 输入文件配置（请根据实际情况修改）
# ============================================================================

# 完整的参考VCF文件
FULL_REF_VCF="ref.vcf.gz"
# 参考面板文件（样本ID与群体对应关系）
REF_PANEL_FILE="Ref_panel.txt"

# 研究VCF文件（待分析的混合样本,将从此文件截取不同SNP数量的子集）
STUDY_VCF="sample.vcf.gz"

# 遗传图谱文件（PLINK格式）
GENETIC_MAP_FILE="genetic_map.map"

# flare程序路径
FLARE_JAR="flare.jar"

# ============================================================================
# 2. 测试梯度配置
# ============================================================================

# 完整测试的SNP数量梯度（16个点）
COMPLETE_SNPS=(1000 5000 10000 25000 50000 75000 100000 150000 200000 250000 300000 400000 500000 600000 700000 796678)

# 快速测试的SNP数量梯度（12个点）
QUICK_SNPS=(1000 5000 10000 50000 100000 200000 300000 400000 500000 600000 700000 796678)

# ============================================================================
# 3. flare运行参数配置
# ============================================================================

# Java虚拟机参数
JAVA_MEM="32g"          # 内存大小
N_THREADS=#           # 线程数（设置为CPU核心数）
JAVA_OPTS="-Xmx${JAVA_MEM} -Xms${JAVA_MEM}"

# flare参数（固定值，确保测试一致性）
FLARE_EM="false"       # 禁用EM算法，避免参数估计影响时间
FLARE_SEED="12345"     # 固定随机种子确保结果可重复
FLARE_PROBS="false"    # 不输出后验概率以减少输出文件大小

# ============================================================================
# 4. 项目路径配置
# ============================================================================

# 基础路径
BASE_DIR="your_project"
DATA_DIR="${BASE_DIR}/data"
RESULTS_DIR="${BASE_DIR}/results"
LOGS_DIR="${BASE_DIR}/logs"
TEMP_DIR="${BASE_DIR}/temp"
PLOTS_DIR="${BASE_DIR}/plots"
SCRIPTS_DIR="${BASE_DIR}"

# 输出文件
RESULTS_FILE="${RESULTS_DIR}/test_results.csv"
PLOT_FILE="${PLOTS_DIR}/runtime_vs_snps.png"
REPORT_FILE="${RESULTS_DIR}/test_report.md"
SUMMARY_FILE="${RESULTS_DIR}/test_summary.txt"

# ============================================================================
# 5. 系统配置
# ============================================================================

# 时间命令（不同系统可能不同）
TIME_CMD="/usr/bin/time"
TIMEFORMAT="real %e, user %U, sys %S, mem %M KB"

# 日志级别
LOG_LEVEL="INFO"  # DEBUG, INFO, WARNING, ERROR

# ============================================================================
# 6. 依赖检查配置
# ============================================================================

# 必需的命令
REQUIRED_COMMANDS=("java" "python3" "bcftools" "bgzip" "tabix" "awk" "grep" "head" "tail" "wc")

# Python库要求
REQUIRED_PYTHON_LIBS=("matplotlib" "pandas" "numpy")

# ============================================================================
# 7. 验证配置文件
# ============================================================================

validate_config() {
    echo "正在验证配置文件..."
    
    # 检查必需文件
    local missing_files=()
    
    if [[ ! -f "$FULL_REF_VCF" ]]; then
        missing_files+=("FULL_REF_VCF: $FULL_REF_VCF")
    fi
    
    if [[ ! -f "$REF_PANEL_FILE" ]]; then
        missing_files+=("REF_PANEL_FILE: $REF_PANEL_FILE")
    fi
    
    if [[ ! -f "$GENETIC_MAP_FILE" ]]; then
        missing_files+=("GENETIC_MAP_FILE: $GENETIC_MAP_FILE")
    fi
    
    if [[ ! -f "$FLARE_JAR" ]]; then
        missing_files+=("FLARE_JAR: $FLARE_JAR")
    fi
    
    if [[ ${#missing_files[@]} -gt 0 ]]; then
        echo "错误：以下文件不存在："
        for file in "${missing_files[@]}"; do
            echo "  $file"
        done
        return 1
    fi
    
    # 获取完整VCF的SNP数量
    if command -v bcftools &> /dev/null; then
        TOTAL_SNPS=$(bcftools view -H "$FULL_REF_VCF" | wc -l 2>/dev/null || echo "0")
        echo "完整VCF中的总SNP数量: $TOTAL_SNPS"
        
        # 检查测试点是否超过总SNP数
        for snp in "${COMPLETE_SNPS[@]}"; do
            if [[ $snp -gt $TOTAL_SNPS ]] && [[ $TOTAL_SNPS -gt 0 ]]; then
                echo "警告：测试点 $snp 超过总SNP数 $TOTAL_SNPS"
            fi
        done
    fi
    
    echo "配置文件验证完成"
    return 0
}

# 打印配置摘要
print_config_summary() {
    echo "========================================="
    echo "         flare测试配置摘要"
    echo "========================================="
    echo "基础目录: $BASE_DIR"
    echo "完整测试点: ${#COMPLETE_SNPS[@]} 个"
    echo "快速测试点: ${#QUICK_SNPS[@]} 个"
    echo "Java内存: $JAVA_MEM"
    echo "线程数: $N_THREADS"
    echo "参考VCF: $(basename "$FULL_REF_VCF")"
    echo "参考面板: $(basename "$REF_PANEL_FILE")"
    echo "遗传图谱: $(basename "$GENETIC_MAP_FILE")"
    echo "flare程序: $(basename "$FLARE_JAR")"
    echo "========================================="
}

echo "配置文件 config.sh 创建完成！"
