#!/bin/bash
# ============================================================================
# flare运行时间与SNP数量关系测试系统 - 主控制脚本
# ============================================================================

# 设置错误处理
set -euo pipefail

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 检查配置文件
CONFIG_FILE="${SCRIPT_DIR}/config.sh"
echo "========================================"
echo "脚本目录: $SCRIPT_DIR"
echo "配置文件: $CONFIG_FILE"
echo "当前目录: $(pwd)"
echo "========================================"

if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "❌ 错误：找不到配置文件！"
    echo "请确保 config.sh 文件与 master.sh 在同一目录中"
    echo ""
    echo "当前目录的文件列表:"
    ls -la
    exit 1
fi

echo "✅ 找到配置文件"
echo "加载配置文件..."

# 加载配置文件
if ! source "$CONFIG_FILE"; then
    echo "❌ 错误：加载配置文件失败！"
    echo "请检查 config.sh 文件是否有语法错误"
    exit 1
fi

echo "✅ 配置文件加载成功"
echo ""

# ============================================================================
# 颜色定义
# ============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# ============================================================================
# 日志函数
# ============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_section() {
    echo -e "\n${PURPLE}${BOLD}=========================================${NC}"
    echo -e "${PURPLE}${BOLD}    $1${NC}"
    echo -e "${PURPLE}${BOLD}=========================================${NC}\n"
}

# ============================================================================
# 配置验证函数
# ============================================================================

verify_configuration() {
    log_section "验证配置文件"
    
    # 检查关键配置变量
    echo "正在验证配置变量..."
    
    local missing_vars=()
    
    # 必需变量列表
    local required_vars=(
        "FULL_REF_VCF"
        "REF_PANEL_FILE" 
        "GENETIC_MAP_FILE"
        "FLARE_JAR"
        "COMPLETE_SNPS"
        "QUICK_SNPS"
        "JAVA_MEM"
        "N_THREADS"
    )
    
    for var in "${required_vars[@]}"; do
        if [[ -z "${!var+x}" ]]; then
            missing_vars+=("$var")
        fi
    done
    
    if [[ ${#missing_vars[@]} -gt 0 ]]; then
        log_error "以下配置变量未设置:"
        for var in "${missing_vars[@]}"; do
            echo "  - $var"
        done
        return 1
    fi
    
    echo "✅ 所有配置变量已设置"
    
    # 检查文件是否存在
    echo ""
    echo "正在验证文件路径..."
    
    local missing_files=()
    
    if [[ ! -f "$FULL_REF_VCF" ]]; then
        missing_files+=("参考VCF: $FULL_REF_VCF")
    fi
    
    if [[ ! -f "$REF_PANEL_FILE" ]]; then
        missing_files+=("参考面板: $REF_PANEL_FILE")
    fi
    
    if [[ ! -f "$GENETIC_MAP_FILE" ]]; then
        missing_files+=("遗传图谱: $GENETIC_MAP_FILE")
    fi
    
    if [[ ! -f "$FLARE_JAR" ]]; then
        missing_files+=("flare程序: $FLARE_JAR")
    fi
    
    if [[ ${#missing_files[@]} -gt 0 ]]; then
        log_error "以下文件不存在:"
        for file in "${missing_files[@]}"; do
            echo "  - $file"
        done
        return 1
    fi
    
    echo "✅ 所有文件都存在"
    echo ""
    
    # 显示配置摘要
    echo "配置摘要:"
    echo "------------------------------------------"
    echo "完整测试点: ${#COMPLETE_SNPS[@]} 个"
    echo "快速测试点: ${#QUICK_SNPS[@]} 个"
    echo "Java内存: $JAVA_MEM"
    echo "线程数: $N_THREADS"
    echo "参考VCF: $(basename "$FULL_REF_VCF")"
    echo "参考面板: $(basename "$REF_PANEL_FILE")"
    echo "遗传图谱: $(basename "$GENETIC_MAP_FILE")"
    echo "flare程序: $(basename "$FLARE_JAR")"
    echo "------------------------------------------"
    
    log_success "配置文件验证完成"
    return 0
}

# ============================================================================
# 依赖检查函数
# ============================================================================

check_dependencies() {
    log_section "检查系统依赖"
    
    local missing_tools=()
    
    # 检查Java
    if ! command -v java &> /dev/null; then
        missing_tools+=("Java (需要1.8+)")
    else
        java_version=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2)
        echo "✅ Java版本: $java_version"
    fi
    
    # 检查Python
    if ! command -v python3 &> /dev/null; then
        missing_tools+=("Python3")
    else
        python_version=$(python3 --version 2>&1)
        echo "✅ Python版本: $python_version"
    fi
    
    # 检查bcftools
    if ! command -v bcftools &> /dev/null; then
        missing_tools+=("bcftools")
    else
        bcftools_version=$(bcftools --version 2>&1 | head -n1 | awk '{print $2}')
        echo "✅ bcftools版本: $bcftools_version"
    fi
    
    # 检查bgzip
    if ! command -v bgzip &> /dev/null; then
        missing_tools+=("bgzip")
    else
        echo "✅ bgzip: 已安装"
    fi
    
    # 检查tabix
    if ! command -v tabix &> /dev/null; then
        missing_tools+=("tabix")
    else
        echo "✅ tabix: 已安装"
    fi
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_error "以下工具未安装:"
        for tool in "${missing_tools[@]}"; do
            echo "  - $tool"
        done
        return 1
    fi
    
    log_success "所有依赖检查通过"
    return 0
}

# ============================================================================
# 测试功能函数
# ============================================================================

full_test() {
    log_section "开始完整测试"
    
    log_info "测试梯度: ${COMPLETE_SNPS[*]}"
    
    # 准备数据
    log_info "准备测试数据..."
    if python3 extract_snps.py --mode full; then
        log_success "数据准备完成"
    else
        log_error "数据准备失败"
        return 1
    fi
    
    # 运行测试
    log_info "运行flare测试..."
    if ./run_flare_test.sh --mode full; then
        log_success "flare测试完成"
    else
        log_error "flare测试失败"
        return 1
    fi
    
    # 生成报告
    log_info "生成测试报告..."
    if python3 generate_report.py --mode full; then
        log_success "报告生成完成"
    else
        log_error "报告生成失败"
        return 1
    fi
    
    log_success "完整测试完成"
    print_summary
}

quick_test() {
    log_section "开始快速测试"
    
    log_info "测试梯度: ${QUICK_SNPS[*]}"
    
    # 准备数据
    log_info "准备测试数据..."
    if python3 extract_snps.py --mode quick; then
        log_success "数据准备完成"
    else
        log_error "数据准备失败"
        return 1
    fi
    
    # 运行测试
    log_info "运行flare测试..."
    if ./run_flare_test.sh --mode quick; then
        log_success "flare测试完成"
    else
        log_error "flare测试失败"
        return 1
    fi
    
    # 生成报告
    log_info "生成测试报告..."
    if python3 generate_report.py --mode quick; then
        log_success "报告生成完成"
    else
        log_error "报告生成失败"
        return 1
    fi
    
    log_success "快速测试完成"
    print_summary
}

simulation_test() {
    log_section "开始模拟测试"
    
    log_info "仅生成测试数据，不运行flare"
    
    if python3 extract_snps.py --mode simulation; then
        log_success "数据生成完成"
        
        # 显示生成的数据
        log_info "生成的数据样例:"
        for snp in 1000 5000 10000; do
            data_dir="${DATA_DIR}/snp_${snp}"
            if [[ -d "$data_dir" ]]; then
                echo "  SNP=${snp}:"
                if [[ -f "${data_dir}/ref_subset.vcf.gz" ]]; then
                    size=$(du -h "${data_dir}/ref_subset.vcf.gz" 2>/dev/null | cut -f1)
                    echo "    - VCF文件: ref_subset.vcf.gz ($size)"
                fi
                if [[ -f "${data_dir}/ref_panel.txt" ]]; then
                    echo "    - 参考面板: ref_panel.txt"
                fi
                if [[ -f "${data_dir}/genetic_map.txt" ]]; then
                    echo "    - 遗传图谱: genetic_map.txt"
                fi
            fi
        done
    else
        log_error "数据生成失败"
        return 1
    fi
    
    log_success "模拟测试完成"
}

generate_report_only() {
    log_section "生成数据报告"
    
    if [[ ! -f "$RESULTS_FILE" ]]; then
        log_error "未找到测试结果文件: $RESULTS_FILE"
        log_info "请先运行完整测试或快速测试"
        return 1
    fi
    
    if python3 generate_report.py --mode report-only; then
        log_success "报告生成完成"
        
        if [[ -f "$REPORT_FILE" ]]; then
            echo ""
            echo "报告摘要:"
            echo "=========================================="
            grep -E "^(测试模式|总测试点|总耗时|最小时间|最大时间)" "$REPORT_FILE" 2>/dev/null || head -10 "$REPORT_FILE"
            echo "=========================================="
        fi
    else
        log_error "报告生成失败"
        return 1
    fi
}

cleanup_data() {
    log_section "删除测试数据"
    
    log_warning "即将删除所有测试数据"
    echo "这将删除以下目录:"
    echo "  $DATA_DIR/*"
    echo "  $RESULTS_DIR/*"
    echo "  $LOGS_DIR/*"
    echo "  $TEMP_DIR/*"
    echo "  $PLOTS_DIR/*"
    echo ""
    echo "但会保留脚本文件"
    echo ""
    
    read -p "确定要删除吗？(y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if ./cleanup.sh; then
            log_success "测试数据已清理"
        else
            log_error "清理失败"
            return 1
        fi
    else
        log_info "取消清理操作"
    fi
}

print_summary() {
    log_section "测试完成摘要"
    
    if [[ -f "$RESULTS_FILE" ]]; then
        echo "测试结果统计:"
        echo "------------------------------------------"
        awk -F, 'NR>1 {
            count++
            sum+=$3
            if($3 > max || NR==2) max=$3
            if($3 < min || NR==2) min=$3
        } END {
            if(count > 0) {
                printf("测试点数: %d\n", count)
                printf("总运行时间: %.2f 秒\n", sum)
                printf("平均时间: %.2f 秒\n", sum/count)
                printf("最短时间: %.2f 秒\n", min)
                printf("最长时间: %.2f 秒\n", max)
            }
        }' "$RESULTS_FILE"
        echo "------------------------------------------"
    fi
    
    echo "输出文件:"
    echo "  - 测试结果: $RESULTS_FILE"
    echo "  - 测试报告: $REPORT_FILE"
    echo "  - 图表文件: $PLOT_FILE"
}

# ============================================================================
# 主菜单函数
# ============================================================================

show_menu() {
    clear
    echo -e "${BLUE}${BOLD}"
    echo "╔══════════════════════════════════════════╗"
    echo "║    flare运行时间与SNP数量关系测试系统    ║"
    echo "╚══════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo -e "${WHITE}请选择操作:${NC}"
    echo ""
    echo -e "  ${GREEN}1)${NC} 完整测试 ${YELLOW}(${#COMPLETE_SNPS[@]}个测试点)${NC}"
    echo "      梯度: ${COMPLETE_SNPS[*]}"
    echo ""
    echo -e "  ${GREEN}2)${NC} 快速测试 ${YELLOW}(${#QUICK_SNPS[@]}个测试点)${NC}"
    echo "      梯度: ${QUICK_SNPS[*]}"
    echo ""
    echo -e "  ${GREEN}3)${NC} 模拟测试 ${CYAN}(仅生成数据，不运行flare)${NC}"
    echo ""
    echo -e "  ${GREEN}4)${NC} 只生成数据报告"
    echo ""
    echo -e "  ${RED}5)${NC} 删除测试数据"
    echo ""
    echo -e "  ${GREEN}0)${NC} 退出"
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════${NC}"
    echo ""
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    echo -e "${PURPLE}${BOLD}"
    echo "========================================="
    echo "    flare运行时间测试系统"
    echo "========================================="
    echo -e "${NC}"
    
    # 验证配置
    if ! verify_configuration; then
        log_error "配置文件验证失败"
        exit 1
    fi
    
    # 检查依赖
    if ! check_dependencies; then
        log_error "依赖检查失败"
        exit 1
    fi
    
    # 主菜单循环
    while true; do
        show_menu
        
        read -p "请输入选择 (0-5): " choice
        
        case $choice in
            1)
                echo ""
                log_info "开始完整测试..."
                full_test
                ;;
            2)
                echo ""
                log_info "开始快速测试..."
                quick_test
                ;;
            3)
                echo ""
                log_info "开始模拟测试..."
                simulation_test
                ;;
            4)
                echo ""
                log_info "生成数据报告..."
                generate_report_only
                ;;
            5)
                echo ""
                cleanup_data
                ;;
            0)
                echo ""
                log_info "退出程序"
                exit 0
                ;;
            *)
                echo ""
                log_error "无效选择，请输入0-5之间的数字"
                ;;
        esac
        
        echo ""
        read -p "按Enter键继续..."
    done
}

# 运行主函数
main "$@"
