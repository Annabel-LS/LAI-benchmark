#!/bin/bash
# 清理测试数据脚本

# 加载配置
source config.sh

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}[警告]${NC} 即将清理测试数据"
echo "这将删除以下目录的内容:"
echo "  $DATA_DIR"
echo "  $RESULTS_DIR"
echo "  $LOGS_DIR"
echo "  $TEMP_DIR"
echo "  $PLOTS_DIR"
echo ""
echo "保留以下文件:"
echo "  *.sh 脚本文件"
echo "  *.py 脚本文件"
echo "  config.sh 配置文件"
echo "  README.md 说明文件"
echo ""

read -p "确认要清理吗？(y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "取消清理操作"
    exit 0
fi

echo "开始清理..."

# 清理数据目录
if [[ -d "$DATA_DIR" ]]; then
    echo "清理数据目录: $DATA_DIR"
    rm -rf "${DATA_DIR:?}"/*
    echo -e "${GREEN}✓ 数据目录已清理${NC}"
else
    echo -e "${YELLOW}! 数据目录不存在${NC}"
fi

# 清理结果目录（保留配置文件）
if [[ -d "$RESULTS_DIR" ]]; then
    echo "清理结果目录: $RESULTS_DIR"
    # 只删除文件，不删除目录本身
    find "$RESULTS_DIR" -maxdepth 1 -type f -name "*" ! -name ".*" -delete
    echo -e "${GREEN}✓ 结果目录已清理${NC}"
else
    echo -e "${YELLOW}! 结果目录不存在${NC}"
fi

# 清理日志目录
if [[ -d "$LOGS_DIR" ]]; then
    echo "清理日志目录: $LOGS_DIR"
    rm -rf "${LOGS_DIR:?}"/*
    echo -e "${GREEN}✓ 日志目录已清理${NC}"
else
    echo -e "${YELLOW}! 日志目录不存在${NC}"
fi

# 清理临时目录
if [[ -d "$TEMP_DIR" ]]; then
    echo "清理临时目录: $TEMP_DIR"
    rm -rf "${TEMP_DIR:?}"/*
    echo -e "${GREEN}✓ 临时目录已清理${NC}"
else
    echo -e "${YELLOW}! 临时目录不存在${NC}"
fi

# 清理图表目录
if [[ -d "$PLOTS_DIR" ]]; then
    echo "清理图表目录: $PLOTS_DIR"
    rm -rf "${PLOTS_DIR:?}"/*
    echo -e "${GREEN}✓ 图表目录已清理${NC}"
else
    echo -e "${YELLOW}! 图表目录不存在${NC}"
fi

echo ""
echo -e "${GREEN}清理完成！${NC}"
echo "所有测试数据已被删除，脚本和配置文件保留。"

echo "清理脚本 cleanup.sh 创建完成！"
