#!/usr/bin/env python3
"""
测试报告生成脚本
生成运行时间与SNP数量的关系图和详细报告
"""

import os
import sys
import argparse
import pandas as pd
import numpy as np
from datetime import datetime
import subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='生成测试报告')
    parser.add_argument('--mode', choices=['full', 'quick', 'report-only'], 
                       default='full', help='报告模式')
    return parser.parse_args()

def load_config():
    """使用shell加载配置文件并获取环境变量"""
    config = {}
    
    # 使用shell来加载配置文件并导出变量
    env_vars_cmd = '''
    source config.sh > /dev/null 2>&1
    echo "PROJECT_DIR=$PROJECT_DIR"
    echo "DATA_DIR=$DATA_DIR"
    echo "RESULTS_DIR=$RESULTS_DIR"
    echo "LOGS_DIR=$LOGS_DIR"
    echo "TEMP_DIR=$TEMP_DIR"
    echo "PLOTS_DIR=$PLOTS_DIR"
    echo "RESULTS_FILE=$RESULTS_FILE"
    echo "PLOT_FILE=$PLOT_FILE"
    echo "REPORT_FILE=$REPORT_FILE"
    '''
    
    try:
        result = subprocess.run(env_vars_cmd, shell=True, capture_output=True, text=True, executable='/bin/bash')
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if '=' in line:
                    key, value = line.split('=', 1)
                    config[key] = value
        else:
            print(f"错误：无法加载配置文件: {result.stderr}")
            return None
    except Exception as e:
        print(f"错误：加载配置时出错: {e}")
        return None
    
    return config

def load_results(results_file):
    """加载测试结果"""
    if not os.path.exists(results_file):
        print(f"错误：结果文件不存在: {results_file}")
        return None
    
    try:
        df = pd.read_csv(results_file)
        print(f"成功加载结果文件，共 {len(df)} 条记录")
        
        # 转换数据类型
        df['snp_count'] = pd.to_numeric(df['snp_count'], errors='coerce')
        df['runtime_seconds'] = pd.to_numeric(df['runtime_seconds'], errors='coerce')
        
        # 过滤成功记录
        success_df = df[df['status'] == 'success'].copy()
        print(f"成功记录: {len(success_df)} 条")
        
        if len(success_df) == 0:
            print("警告：没有成功的测试记录")
            return None
        
        return success_df
    except Exception as e:
        print(f"加载结果文件时出错: {e}")
        return None

def generate_summary_statistics(df, mode):
    """生成统计摘要"""
    if df is None or len(df) == 0:
        return None
    
    stats = {
        '测试模式': mode,
        '总测试点': len(df),
        '总耗时': float(df['runtime_seconds'].sum()),
        '平均时间': float(df['runtime_seconds'].mean()),
        '最小时间': float(df['runtime_seconds'].min()),
        '最大时间': float(df['runtime_seconds'].max()),
        '时间标准差': float(df['runtime_seconds'].std()),
        '最小SNP数': int(df['snp_count'].min()),
        '最大SNP数': int(df['snp_count'].max()),
    }
    
    # 计算每千SNP的平均时间
    if df['snp_count'].sum() > 0:
        stats['每千SNP平均时间'] = float((df['runtime_seconds'] / df['snp_count'] * 1000).mean())
    else:
        stats['每千SNP平均时间'] = 0.0
    
    return stats

# 修改 generate_report.py 中的 plot_runtime_vs_snps 函数

def plot_runtime_vs_snps(df, stats, output_file, mode):
    """绘制运行时间与SNP数量的关系图"""
    
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica', 'sans-serif']
    plt.rcParams['axes.unicode_minus'] = False
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(14, 9))
    
    # 绘制折线图（带标记点）
    sorted_df = df.sort_values('snp_count')
    ax.plot(sorted_df['snp_count'], sorted_df['runtime_seconds'], 
           color='steelblue', linewidth=3, alpha=0.8, marker='o', 
           markersize=8, markerfacecolor='white', markeredgewidth=2, 
           markeredgecolor='steelblue')
    
    # 设置坐标轴
    ax.set_xlabel('Number of SNPs', fontsize=14, fontweight='bold')
    ax.set_ylabel('Running Time (seconds)', fontsize=14, fontweight='bold')
    
    # 设置标题
    title = f'flare Runtime vs SNP Count'
    ax.set_title(title, fontsize=16, fontweight='bold', pad=20)
    
    # 使用对数坐标轴（X轴）
    ax.set_xscale('log')
    
    # 设置网格
    ax.grid(True, alpha=0.3, linestyle='--', which='both')
    
    # 设置X轴刻度标签
    x_ticks = sorted_df['snp_count'].values
    
  # 生成刻度标签：自动格式化大数字
    x_tick_labels = []
    for tick in x_ticks:
        if tick >= 1000000:
            label = f'{tick/1000000:.1f}M'
        elif tick >= 1000:
            label = f'{tick/1000:.0f}K'
        else:
            label = f'{tick}'
        x_tick_labels.append(label)
        
        # 设置刻度位置和标签
    ax.set_xticks(x_ticks)
    ax.set_xticklabels(x_tick_labels, rotation=45, ha='right', fontsize=11)
    
    # 为每个点标注所用时间
    for idx, row in sorted_df.iterrows():
        snp_count = row['snp_count']
        runtime = row['runtime_seconds']
        
        # 只在点上或点下标注时间，避免重叠
        offset = 0.02 * max(sorted_df['runtime_seconds'])  # 2%的偏移量
        va = 'bottom' if idx % 2 == 0 else 'top'  # 交替标注位置
        y_offset = offset if va == 'bottom' else -offset
        
        # 格式化时间显示
        if runtime < 60:
            time_text = f'{runtime:.1f}s'
        elif runtime < 3600:
            time_text = f'{runtime/60:.1f}m'
        else:
            time_text = f'{runtime/3600:.1f}h'
        
        ax.annotate(time_text, 
                   xy=(snp_count, runtime),
                   xytext=(0, y_offset),
                   textcoords='offset points',
                   ha='center', va=va,
                   fontsize=9, fontweight='bold',
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.7),
                   arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0', color='gray', alpha=0.5))
    
    # 添加性能框
    if stats:
        # 计算统计信息
        total_points = stats['总测试点']
        total_time = stats['总耗时']
        min_time = stats['最小时间']
        max_time = stats['最大时间']
        avg_time = stats['平均时间']
        time_per_1k = stats['每千SNP平均时间']
        
        # 找到最小和最大时间对应的SNP数量
        min_row = df.loc[df['runtime_seconds'].idxmin()]
        max_row = df.loc[df['runtime_seconds'].idxmax()]
        
        # 性能框文本（英文）
        stats_text = (
            f"Performance Summary:\n"
            f"Test Mode: {mode.upper()}\n"
            f"Test Points: {total_points}\n"
            f"Total Time: {total_time:.1f} s\n"
            f"Min Time: {min_time:.2f} s (SNP={int(min_row['snp_count'])})\n"
            f"Max Time: {max_time:.2f} s (SNP={int(max_row['snp_count'])})\n"
            f"Avg Time: {avg_time:.2f} s\n"
            f"Time/1k SNPs: {time_per_1k:.3f} s"
        )
        
        # 添加文本框（左上角）
        props = dict(boxstyle='round', facecolor='lightblue', alpha=0.8, edgecolor='navy', linewidth=2)
        ax.text(0.02, 0.98, stats_text, transform=ax.transAxes, fontsize=10,
                verticalalignment='top', bbox=props, fontfamily='monospace',
                fontweight='bold')
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图形
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Chart saved: {output_file}")
    return True

def generate_markdown_report(df, stats, config, output_file, plot_file, mode):
    """生成Markdown格式的报告"""
    
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("# flare运行时间与SNP数量关系测试报告\n\n")
            
            f.write("## 测试基本信息\n\n")
            f.write(f"- **报告生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"- **测试模式**: {mode}\n")
            f.write(f"- **测试点数**: {stats['总测试点']}\n")
            f.write(f"- **测试范围**: {stats['最小SNP数']:,} - {stats['最大SNP数']:,} SNPs\n\n")
            
            f.write("## 性能统计\n\n")
            f.write("| 指标 | 值 |\n")
            f.write("|------|-----|\n")
            f.write(f"| 总运行时间 | {stats['总耗时']:.2f} 秒 |\n")
            f.write(f"| 平均运行时间 | {stats['平均时间']:.2f} 秒 |\n")
            f.write(f"| 最短运行时间 | {stats['最小时间']:.2f} 秒 |\n")
            f.write(f"| 最长运行时间 | {stats['最大时间']:.2f} 秒 |\n")
            f.write(f"| 时间标准差 | {stats['时间标准差']:.2f} 秒 |\n")
            f.write(f"| 每千SNP平均时间 | {stats['每千SNP平均时间']:.3f} 秒 |\n\n")
            
            f.write("## 详细测试数据\n\n")
            f.write("| 测试ID | SNP数量 | 运行时间(秒) | 状态 |\n")
            f.write("|--------|---------|--------------|------|\n")
            
            sorted_df = df.sort_values('snp_count')
            for _, row in sorted_df.iterrows():
                f.write(f"| {row['test_id']} | {row['snp_count']:,} | {row['runtime_seconds']:.2f} | {row['status']} |\n")
            f.write("\n")
            
            if os.path.exists(plot_file):
                plot_filename = os.path.basename(plot_file)
                f.write(f"## 运行时间与SNP数量关系图\n\n")
                f.write(f"![运行时间与SNP数量关系图]({plot_filename})\n\n")
        
        print(f"报告已生成: {output_file}")
        return True
    except Exception as e:
        print(f"生成报告时出错: {e}")
        return False

def main():
    """主函数"""
    
    args = parse_args()
    
    # 加载配置
    config = load_config()
    if config is None:
        print("错误：无法加载配置")
        return 1
    
    # 获取路径
    results_file = config.get('RESULTS_FILE', '')
    plot_file = config.get('PLOT_FILE', '')
    report_file = config.get('REPORT_FILE', '')
    
    if not results_file:
        print("错误：未找到结果文件路径")
        return 1
    
    # 创建目录
    os.makedirs(os.path.dirname(plot_file), exist_ok=True)
    os.makedirs(os.path.dirname(report_file), exist_ok=True)
    
    # 加载结果
    df = load_results(results_file)
    if df is None:
        print("错误：无法加载测试结果")
        return 1
    
    # 生成统计信息
    stats = generate_summary_statistics(df, args.mode)
    if stats is None:
        print("错误：无法生成统计信息")
        return 1
    
    # 生成图表
    print("正在生成图表...")
    if not plot_runtime_vs_snps(df, stats, plot_file, args.mode):
        print("警告：图表生成失败")
    
    # 生成报告
    print("正在生成报告...")
    if not generate_markdown_report(df, stats, config, report_file, plot_file, args.mode):
        print("警告：报告生成失败")
    
    print("\n" + "="*50)
    print("报告生成完成!")
    print(f"图表文件: {plot_file}")
    print(f"报告文件: {report_file}")
    print("="*50)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())

