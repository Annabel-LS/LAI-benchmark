#!/bin/bash
# 项目设置验证脚本

echo "正在验证 flare 运行时间测试项目设置..."
echo "========================================"

# 检查目录结构
echo "1. 检查目录结构..."
for dir in logs data results temp plots; do
    if [[ -d "$dir" ]]; then
        echo "  ✓ $dir 目录存在"
    else
        echo "  ✗ $dir 目录不存在，正在创建..."
        mkdir -p "$dir"
    fi
done

echo ""
echo "2. 检查脚本文件..."
for script in master.sh config.sh extract_snps.py run_flare_test.sh generate_report.py cleanup.sh; do
    if [[ -f "$script" ]]; then
        echo "  ✓ $script 存在"
        if [[ -x "$script" && "$script" != *.py ]]; then
            echo "    (可执行权限已设置)"
        elif [[ "$script" == *.py ]]; then
            chmod +x "$script" 2>/dev/null && echo "    (已设置Python脚本可执行权限)"
        fi
    else
        echo "  ✗ $script 不存在"
    fi
done

echo ""
echo "3. 检查配置文件..."
if [[ -f "config.sh" ]]; then
    echo "  ✓ config.sh 存在"
    # 检查配置项
    source config.sh 2>/dev/null
    
    echo "  配置摘要:"
    echo "    - 完整测试点: ${#COMPLETE_SNPS[@]} 个"
    echo "    - 快速测试点: ${#QUICK_SNPS[@]} 个"
    
    # 检查文件是否存在
    echo "    - 参考VCF: $FULL_REF_VCF"
    if [[ -f "$FULL_REF_VCF" ]]; then
        echo "      ✓ 文件存在"
    else
        echo "      ✗ 文件不存在"
    fi
    
    echo "    - 参考面板: $REF_PANEL_FILE"
    if [[ -f "$REF_PANEL_FILE" ]]; then
        echo "      ✓ 文件存在"
    else
        echo "      ✗ 文件不存在"
    fi
    
    echo "    - 遗传图谱: $GENETIC_MAP_FILE"
    if [[ -f "$GENETIC_MAP_FILE" ]]; then
        echo "      ✓ 文件存在"
    else
        echo "      ✗ 文件不存在"
    fi
    
    echo "    - flare程序: $FLARE_JAR"
    if [[ -f "$FLARE_JAR" ]]; then
        echo "      ✓ 文件存在"
    else
        echo "      ✗ 文件不存在"
    fi
else
    echo "  ✗ config.sh 不存在"
fi

echo ""
echo "4. 检查依赖..."
echo "  检查必需命令:"
for cmd in java python3 bcftools bgzip tabix; do
    if command -v "$cmd" &> /dev/null; then
        version=$($cmd --version 2>&1 | head -n1)
        echo "    ✓ $cmd: $version"
    else
        echo "    ✗ $cmd: 未找到"
    fi
done

echo ""
echo "5. 检查Python库..."
if command -v python3 &> /dev/null; then
    for lib in matplotlib pandas numpy; do
        if python3 -c "import $lib" 2>/dev/null; then
            echo "    ✓ $lib: 已安装"
        else
            echo "    ✗ $lib: 未安装"
        fi
    done
else
    echo "    ✗ Python3 未找到"
fi

echo ""
echo "========================================"
echo "验证完成!"
echo ""
echo "下一步:"
echo "1. 如果配置文件有问题，请编辑 config.sh 设置正确的文件路径"
echo "2. 运行 ./master.sh 开始测试"
echo "3. 选择测试模式 (1-完整测试, 2-快速测试, 3-模拟测试)"
echo ""
echo "注意: 首次运行建议先选择 '3. 模拟测试' 验证数据准备过程"

echo "验证脚本 validate_setup.sh 创建完成！"
