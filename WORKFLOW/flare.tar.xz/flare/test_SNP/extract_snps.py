#!/usr/bin/env python3
"""
修复版的 SNP 截取脚本
"""

import os
import sys
import argparse
import subprocess
import time
from datetime import datetime
import shutil

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='从研究VCF截取不同数量的SNP')
    parser.add_argument('--mode', choices=['full', 'quick', 'simulation'], 
                       default='full', help='测试模式')
    return parser.parse_args()

def load_config():
    """加载配置文件 - 简化版"""
    config = {}
    
    # 硬编码关键配置，避免复杂的解析
    config['REF_VCF'] = "ref.vcf.gz"
    config['STUDY_VCF'] = "sample.vcf.gz"
    config['REF_PANEL_FILE'] = "Ref_panel.txt"
    config['GENETIC_MAP_FILE'] = "genetic_map.map"
    
    # 测试梯度
    config['COMPLETE_SNPS'] = [1000, 5000, 10000, 25000, 50000, 75000, 100000, 
                               150000, 200000, 250000, 300000, 400000, 500000, 
                               600000, 700000, 796678]
    config['QUICK_SNPS'] = [1000, 5000, 10000, 50000, 100000, 200000, 300000, 
                            400000, 500000, 600000, 700000, 796678]
    
    # 其他配置
    config['FLARE_EM'] = 'false'
    config['N_THREADS'] = '#'
    config['FLARE_SEED'] = '12345'
    config['FLARE_PROBS'] = 'false'
    
    return config

def get_total_snps(vcf_file):
    """获取VCF文件中的总SNP数量"""
    try:
        if not os.path.exists(vcf_file):
            return None
        
        cmd = f"bcftools view -H '{vcf_file}' 2>/dev/null | wc -l"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return int(result.stdout.strip())
        else:
            print(f"警告：无法读取VCF文件: {result.stderr}")
            return None
    except Exception as e:
        print(f"错误：获取SNP数量失败: {e}")
        return None

def extract_snp_subset(input_vcf, output_vcf, num_snps):
    """从VCF文件中截取指定数量的SNP"""
    
    print(f"截取前 {num_snps} 个SNP...")
    
    if not os.path.exists(input_vcf):
        print(f"错误：输入文件不存在: {input_vcf}")
        return False
    
    try:
        # 创建临时目录
        temp_dir = "temp_extract"
        os.makedirs(temp_dir, exist_ok=True)
        
        # 提取头部
        header_file = os.path.join(temp_dir, f"header_{num_snps}.vcf")
        cmd = f"bcftools view -h '{input_vcf}' > '{header_file}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"提取头部失败: {result.stderr}")
            return False
        
        # 提取主体
        body_file = os.path.join(temp_dir, f"body_{num_snps}.vcf")
        cmd = f"bcftools view -H '{input_vcf}' | head -n {num_snps} > '{body_file}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"提取主体失败: {result.stderr}")
            return False
        
        # 合并
        merged_file = os.path.join(temp_dir, f"merged_{num_snps}.vcf")
        with open(merged_file, 'w') as outfile:
            with open(header_file, 'r') as infile:
                outfile.write(infile.read())
            with open(body_file, 'r') as infile:
                outfile.write(infile.read())
        
        # 压缩
        cmd = f"bgzip -c '{merged_file}' > '{output_vcf}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"压缩失败: {result.stderr}")
            return False
        
        # 创建索引
        cmd = f"tabix -p vcf '{output_vcf}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"创建索引失败（可能不影响使用）: {result.stderr}")
        
        # 清理临时文件
        for f in [header_file, body_file, merged_file]:
            if os.path.exists(f):
                os.remove(f)
        
        # 验证
        if os.path.exists(output_vcf):
            actual_snps = get_total_snps(output_vcf)
            if actual_snps is not None:
                print(f"成功截取 {actual_snps} 个SNP")
                return True
        
        return False
        
    except Exception as e:
        print(f"截取过程中出错: {e}")
        return False

def prepare_test_data(snp_counts, config, mode='full'):
    """
    准备测试数据 - 同时截取研究VCF和参考VCF
    """
    
    print(f"准备 {len(snp_counts)} 个测试点的数据...")
    print(f"模式: {mode}")
    
    # 获取配置
    ref_vcf = config.get('REF_VCF', '')
    study_vcf = config.get('STUDY_VCF', '')
    ref_panel_file = config.get('REF_PANEL_FILE', '')
    genetic_map_file = config.get('GENETIC_MAP_FILE', '')
    data_dir = 'data'  # 固定为data目录
    
    # 检查文件是否存在
    if not ref_vcf or not os.path.exists(ref_vcf):
        print(f"错误：参考VCF文件不存在: {ref_vcf}")
        return False
    
    if not study_vcf or not os.path.exists(study_vcf):
        print(f"错误：研究VCF文件不存在: {study_vcf}")
        return False
    
    if not ref_panel_file or not os.path.exists(ref_panel_file):
        print(f"错误：参考面板文件不存在: {ref_panel_file}")
        return False
    
    if not genetic_map_file or not os.path.exists(genetic_map_file):
        print(f"错误：遗传图谱文件不存在: {genetic_map_file}")
        return False
    
    # 获取研究VCF和参考VCF的总SNP数
    total_study_snps = get_total_snps(study_vcf)
    total_ref_snps = get_total_snps(ref_vcf)
    
    if total_study_snps is None:
        print("错误：无法读取研究VCF文件")
        return False
    if total_ref_snps is None:
        print("错误：无法读取参考VCF文件")
        return False
    
    print(f"研究VCF中的总SNP数: {total_study_snps}")
    print(f"参考VCF中的总SNP数: {total_ref_snps}")
    
    # 创建数据目录
    os.makedirs(data_dir, exist_ok=True)
    
    # 检查每个测试点
    for snp_count in snp_counts:
        if total_study_snps > 0 and snp_count > total_study_snps:
            print(f"警告：测试点 {snp_count} 超过研究VCF总SNP数 {total_study_snps}，跳过")
            continue
        if total_ref_snps > 0 and snp_count > total_ref_snps:
            print(f"警告：测试点 {snp_count} 超过参考VCF总SNP数 {total_ref_snps}，跳过")
            continue
        
        # 创建测试目录
        test_dir = os.path.join(data_dir, f"snp_{snp_count}")
        os.makedirs(test_dir, exist_ok=True)
        
        print(f"\n准备 SNP={snp_count} 的数据...")
        
        # 1. 截取研究VCF文件
        study_output_vcf = os.path.join(test_dir, "study_subset.vcf.gz")
        if os.path.exists(study_output_vcf):
            print(f"  已存在研究VCF文件，跳过截取")
        else:
            if extract_snp_subset(study_vcf, study_output_vcf, snp_count):
                print(f"  ✓ 截取研究VCF完成")
            else:
                print(f"  ✗ 截取研究VCF失败")
                continue
        
        # 2. 截取参考VCF文件
        ref_output_vcf = os.path.join(test_dir, "ref_subset.vcf.gz")
        if os.path.exists(ref_output_vcf):
            print(f"  已存在参考VCF文件，跳过截取")
        else:
            if extract_snp_subset(ref_vcf, ref_output_vcf, snp_count):
                print(f"  ✓ 截取参考VCF完成")
            else:
                print(f"  ✗ 截取参考VCF失败")
                continue
        
        # 3. 复制参考面板文件（不变）
        panel_dest = os.path.join(test_dir, "ref_panel.txt")
        if os.path.exists(panel_dest):
            print(f"  已存在参考面板文件")
        else:
            try:
                shutil.copy2(ref_panel_file, panel_dest)
                print(f"  ✓ 复制参考面板完成")
            except Exception as e:
                print(f"  ✗ 复制参考面板失败: {e}")
                continue
        
        # 4. 复制遗传图谱文件（不变）
        map_dest = os.path.join(test_dir, "genetic_map.txt")
        if os.path.exists(map_dest):
            print(f"  已存在遗传图谱文件")
        else:
            try:
                shutil.copy2(genetic_map_file, map_dest)
                print(f"  ✓ 复制遗传图谱完成")
            except Exception as e:
                print(f"  ✗ 复制遗传图谱失败: {e}")
                continue
        
        # 5. 创建flare参数文件，指向截取后的参考VCF
        params_file = os.path.join(test_dir, "flare_params.txt")
        with open(params_file, 'w') as f:
            f.write(f"# flare测试参数 - SNP={snp_count}\n")
            f.write(f"# 生成时间: {datetime.now()}\n")
            f.write(f"ref=ref_subset.vcf.gz\n")      # 截取后的参考VCF
            f.write(f"ref-panel=ref_panel.txt\n")     # 参考面板
            f.write(f"gt=study_subset.vcf.gz\n")      # 截取的研究VCF
            f.write(f"map=genetic_map.txt\n")         # 遗传图谱
            f.write(f"out=flare_result\n")            # 输出前缀
            f.write(f"min-maf=0\n")             # 不过滤
            f.write(f"min-mac=0\n")             # 不过滤
            f.write(f"em={config.get('FLARE_EM', 'false')}\n")
            f.write(f"nthreads={config.get('N_THREADS', '#')}\n")
            f.write(f"seed={config.get('FLARE_SEED', '12345')}\n")
            f.write(f"probs={config.get('FLARE_PROBS', 'false')}\n")
            f.write(f"array=false\n")
        
        print(f"  ✓ 创建参数文件完成")
        
        # 6. 验证数据
        print(f"  验证数据...")
        
        # 验证研究VCF
        if os.path.exists(study_output_vcf):
            study_snp_count = get_total_snps(study_output_vcf)
            print(f"    研究VCF SNP数: {study_snp_count}")
        
        # 验证参考VCF
        if os.path.exists(ref_output_vcf):
            ref_snp_count = get_total_snps(ref_output_vcf)
            print(f"    参考VCF SNP数: {ref_snp_count}")
    
    print(f"\n所有测试数据准备完成")
    return True
def main():
    """主函数"""
    
    # 解析参数
    args = parse_args()
    
    # 加载配置
    config = load_config()
    
    # 确定测试点
    if args.mode == 'full':
        # 使用完整测试梯度
        snp_counts = config.get('COMPLETE_SNPS', [])
        print(f"使用完整测试梯度: {snp_counts}")
    elif args.mode == 'quick':
        # 使用快速测试梯度
        snp_counts = config.get('QUICK_SNPS', [])
        print(f"使用快速测试梯度: {snp_counts}")
    elif args.mode == 'simulation':
        # 模拟测试只使用少量测试点
        snp_counts = [1000, 5000, 10000]
        print(f"使用模拟测试梯度: {snp_counts}")
    else:
        print(f"错误：未知模式: {args.mode}")
        return 1
    
    # 准备测试数据
    if not prepare_test_data(snp_counts, config, args.mode):
        print("错误：测试数据准备失败")
        return 1
    
    print(f"\n所有测试数据已准备就绪")
    print(f"数据目录: data/")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
