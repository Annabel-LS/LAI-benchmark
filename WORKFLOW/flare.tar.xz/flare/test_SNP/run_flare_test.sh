#!/bin/bash
# flare测试运行脚本

set -e

# 加载配置
source config.sh

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 解析参数
MODE="full"
while [[ $# -gt 0 ]]; do
    case $1 in
        --mode)
            MODE="$2"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done

# 根据模式确定测试点
if [[ "$MODE" == "full" ]]; then
    TEST_SNPS=("${COMPLETE_SNPS[@]}")
elif [[ "$MODE" == "quick" ]]; then
    TEST_SNPS=("${QUICK_SNPS[@]}")
else
    log_error "未知模式: $MODE"
    exit 1
fi

log_info "开始运行flare测试"
log_info "模式: $MODE"
log_info "测试点数量: ${#TEST_SNPS[@]}"

# 创建结果文件头
mkdir -p "$RESULTS_DIR"
echo "test_id,snp_count,runtime_seconds,memory_kb,status,start_time,end_time" > "$RESULTS_FILE"

# 总计时开始
TOTAL_START_TIME=$(date +%s)

# 遍历所有测试点
for SNP_COUNT in "${TEST_SNPS[@]}"; do
    TEST_ID="snp_${SNP_COUNT}"
    TEST_DIR="${DATA_DIR}/${TEST_ID}"
    
    log_info "========================================"
    log_info "测试点: $SNP_COUNT SNPs"
    log_info "测试目录: $TEST_DIR"
    
    # 修改测试目录检查部分
TEST_DIR="${DATA_DIR}/${TEST_ID}"
    
log_info "========================================"
log_info "测试点: $SNP_COUNT SNPs"
log_info "测试目录: $TEST_DIR"

# 检查测试目录是否存在
if [[ ! -d "$TEST_DIR" ]]; then
    log_warning "测试目录不存在: $TEST_DIR"
    log_info "当前工作目录: $(pwd)"
    log_info "DATA_DIR: $DATA_DIR"
    log_info "尝试查找目录..."
    
    # 尝试使用绝对路径
    if [[ "$DATA_DIR" != /* ]]; then
        # 如果是相对路径，转换为绝对路径
        ABS_DATA_DIR="$(cd "$(dirname "$DATA_DIR")" && pwd)/$(basename "$DATA_DIR")"
        TEST_DIR="${ABS_DATA_DIR}/${TEST_ID}"
        log_info "使用绝对路径: $TEST_DIR"
    fi
    
    if [[ ! -d "$TEST_DIR" ]]; then
        log_warning "测试目录确实不存在，跳过: $TEST_DIR"
        continue
    fi
fi
    
    # 检查必要文件
   
    REF_FILE="${TEST_DIR}/ref_subset.vcf.gz"
	STUDY_FILE="${TEST_DIR}/study_subset.vcf.gz"
    PANEL_FILE="${TEST_DIR}/ref_panel.txt"
    MAP_FILE="${TEST_DIR}/genetic_map.txt"
    PARAMS_FILE="${TEST_DIR}/flare_params.txt"
    
    # 然后修改文件检查循环：
   for FILE in "$REF_FILE" "$STUDY_FILE" "$PANEL_FILE" "$MAP_FILE"; do
    if [[ ! -f "$FILE" ]]; then
        log_warning "文件不存在，跳过: $FILE"
        continue 2
    fi
done
    
    # 创建输出目录
    OUTPUT_DIR="${TEST_DIR}/output"
    mkdir -p "$OUTPUT_DIR"
    
    # 准备日志文件
    LOG_FILE="${LOGS_DIR}/flare_${SNP_COUNT}.log"
    
    # 获取参数
    FLARE_PARAMS=""
    if [[ -f "$PARAMS_FILE" ]]; then
        FLARE_PARAMS=$(grep -v '^#' "$PARAMS_FILE" | tr '\n' ' ')
    else
       FLARE_PARAMS="ref=ref_subset.vcf.gz ref-panel=ref_panel.txt gt=study_subset.vcf.gz map=genetic_map.txt out=flare_result em=false min-maf=0 min-mac=0 nthreads=$N_THREADS seed=$FLARE_SEED probs=false array=false"
    fi
    
    # 进入测试目录
    cd "$TEST_DIR"
    
    # 记录开始时间
    START_TIME=$(date +"%Y-%m-%d %H:%M:%S")
   START_SECONDS=$(date +%s.%N)
    
    log_info "开始运行flare..."
    log_info "参数: $FLARE_PARAMS"
    
    # 运行flare并计时
    set +e
    { time java $JAVA_OPTS -jar "$FLARE_JAR" $FLARE_PARAMS >> "$LOG_FILE" 2>&1; } 2> "${OUTPUT_DIR}/time_output.txt"
    FLARE_EXIT_CODE=$?
    set -e
    
    # 记录结束时间
    END_TIME=$(date +"%Y-%m-%d %H:%M:%S")
    END_SECONDS=$(date +%s.%N)
    
    # 计算运行时间
    RUNTIME=$(echo "$END_SECONDS - $START_SECONDS" | bc 2>/dev/null || echo "0")
    
    # 获取内存使用情况
    MEMORY_KB="0"
    if [[ -f "${OUTPUT_DIR}/time_output.txt" ]]; then
        MEMORY_KB=$(grep "Maximum resident set size" "${OUTPUT_DIR}/time_output.txt" | awk '{print $6}' 2>/dev/null || echo "0")
    fi
    
    # 检查运行状态
    if [[ $FLARE_EXIT_CODE -eq 0 ]]; then
        STATUS="success"
        log_success "flare运行成功 - 时间: ${RUNTIME}秒"
    else
        STATUS="failed"
        log_error "flare运行失败 (退出码: $FLARE_EXIT_CODE)"
    fi
    
    # 记录结果
    echo "${TEST_ID},${SNP_COUNT},${RUNTIME},${MEMORY_KB},${STATUS},${START_TIME},${END_TIME}" >> "$RESULTS_FILE"
    
    # 返回项目根目录
    cd - > /dev/null
    
    # 短暂暂停
    sleep 1
    
    log_info "测试点 $SNP_COUNT 完成"
done

# 总计时结束
TOTAL_END_TIME=$(date +%s)
TOTAL_RUNTIME=$((TOTAL_END_TIME - TOTAL_START_TIME))

log_info "========================================"
log_success "所有测试点运行完成"
log_info "总运行时间: ${TOTAL_RUNTIME}秒"
log_info "结果文件: $RESULTS_FILE"

# 生成简单统计
echo ""
echo "测试结果统计:"
echo "========================================"
if [[ -f "$RESULTS_FILE" ]]; then
    awk -F, 'NR>1 {
        count++; 
        sum+=$3; 
        if($3>max || NR==2) max=$3; 
        if(NR==2 || $3<min) min=$3;
        if($4=="success") success++
    } 
    END {
        if(count>0) {
            printf("测试点数: %d\n", count);
            printf("成功数: %d\n", success);
            printf("失败数: %d\n", count-success);
            printf("总时间: %.2f 秒\n", sum);
            printf("平均时间: %.2f 秒\n", sum/count);
            printf("最短时间: %.2f 秒\n", min);
            printf("最长时间: %.2f 秒\n", max);
        } else {
            printf("没有测试结果数据\n");
        }
    }' "$RESULTS_FILE"
else
    echo "结果文件不存在"
fi

echo "========================================"

