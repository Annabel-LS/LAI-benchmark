#!/bin/bash
# 运行一次 flare 分析并记录时间
# 用法：run_flare.sh <n_snps> <ref_subset> <gt_subset> <ref_panel> <map> <out_prefix> <nthreads> <mem_gb>

set -euo pipefail

if [ $# -ne 8 ]; then
    echo "Usage: $0 <n_snps> <ref_subset> <gt_subset> <ref_panel> <map> <out_prefix> <nthreads> <mem_gb>"
    exit 1
fi

N=$1
REF_SUBSET=$2
GT_SUBSET=$3
REF_PANEL=$4
MAP=$5
OUT_PREFIX=$6
NTHREADS=$7
MEM_GB=$8

FLARE_JAR="flare.jar"
LOG_FILE="${OUT_PREFIX}.flare.log"

mkdir -p "$(dirname "$OUT_PREFIX")"

echo "[RUN] Starting flare for $N SNPs (threads=$NTHREADS, mem=${MEM_GB}g) at $(date)"

START=$(date +%s)
java -Xmx${MEM_GB}g -jar "$FLARE_JAR" \
    ref="$REF_SUBSET" \
    ref-panel="$REF_PANEL" \
    gt="$GT_SUBSET" \
    map="$MAP" \
    out="$OUT_PREFIX" \
    nthreads="$NTHREADS" \
    em=false \
    min-maf=0 \
    min-mac=0 \
    seed=12345 \
    array=false \
    probs=false > "$LOG_FILE" 2>&1
END=$(date +%s)

TIME=$((END - START))
echo "$N $TIME"
echo "[RUN] Completed $N SNPs in $TIME seconds."
