#!/bin/bash
# 提取指定数量的 SNP 子集（参考和研究 VCF 同时截取，保证位点一致）
# 用法：extract_snps.sh <n_snps> <ref_vcf> <gt_vcf> <ref_panel> <map> <out_dir>
# 输出：<out_dir>/snp_<n>/ref.vcf.gz, <out_dir>/snp_<n>/study.vcf.gz,
#       <out_dir>/snp_<n>/ref_panel.txt, <out_dir>/snp_<n>/genetic_map.txt,
#       <out_dir>/snp_<n>/flare_params.txt

set -euo pipefail

# 检查依赖
command -v bcftools >/dev/null 2>&1 || { echo "bcftools required but not installed." >&2; exit 1; }
command -v bgzip >/dev/null 2>&1 || { echo "bgzip required but not installed." >&2; exit 1; }
command -v tabix >/dev/null 2>&1 || { echo "tabix required but not installed." >&2; exit 1; }

# 参数
if [ $# -ne 6 ]; then
    echo "Usage: $0 <n_snps> <ref_vcf> <gt_vcf> <ref_panel> <map> <out_dir>"
    exit 1
fi

N=$1
REF_VCF=$2
GT_VCF=$3
REF_PANEL=$4
MAP=$5
OUT_DIR=$6

# 创建该 SNP 数量的专用子目录
TEST_DIR="$OUT_DIR/snp_${N}"
mkdir -p "$TEST_DIR"

REF_OUT="$TEST_DIR/ref.vcf.gz"
GT_OUT="$TEST_DIR/study.vcf.gz"
PANEL_OUT="$TEST_DIR/ref_panel.txt"
MAP_OUT="$TEST_DIR/genetic_map.txt"
PARAMS_OUT="$TEST_DIR/flare_params.txt"

# 如果文件已存在，跳过提取（允许重复使用）
if [ -f "$REF_OUT" ] && [ -f "$GT_OUT" ]; then
    echo "[SKIP] SNP subset for $N already exists."
    exit 0
fi

echo "[EXTRACT] Processing $N SNPs for ref and study VCFs..."

# 1. 提取头部
TEMP_DIR=$(mktemp -d -t flare_extract_XXXXXX)
trap "rm -rf $TEMP_DIR" EXIT

# 提取参考 VCF 头部
bcftools view -h "$REF_VCF" > "$TEMP_DIR/ref_header.vcf"
# 提取研究 VCF 头部
bcftools view -h "$GT_VCF" > "$TEMP_DIR/gt_header.vcf"

# 2. 截取主体（前 N 行）
bcftools view -H "$REF_VCF" | head -n "$N" > "$TEMP_DIR/ref_body.vcf"
bcftools view -H "$GT_VCF" | head -n "$N" > "$TEMP_DIR/gt_body.vcf"

# 检查实际截取的行数
ref_lines=$(wc -l < "$TEMP_DIR/ref_body.vcf")
gt_lines=$(wc -l < "$TEMP_DIR/gt_body.vcf")
if [ "$ref_lines" -lt "$N" ] || [ "$gt_lines" -lt "$N" ]; then
    echo "[ERROR] Requested $N SNPs but got only $ref_lines (ref) and $gt_lines (gt)."
    exit 1
fi

# 3. 合并头部和主体
cat "$TEMP_DIR/ref_header.vcf" "$TEMP_DIR/ref_body.vcf" | bgzip -c > "$REF_OUT"
cat "$TEMP_DIR/gt_header.vcf" "$TEMP_DIR/gt_body.vcf" | bgzip -c > "$GT_OUT"

# 4. 创建索引
tabix -p vcf "$REF_OUT"
tabix -p vcf "$GT_OUT"

# 5. 复制参考面板和遗传图谱（若尚未存在）
if [ ! -f "$PANEL_OUT" ]; then
    cp "$REF_PANEL" "$PANEL_OUT"
fi
if [ ! -f "$MAP_OUT" ]; then
    cp "$MAP" "$MAP_OUT"
fi

# 6. 生成 flare 参数文件（可选，主控脚本也可直接使用这些文件路径）
cat > "$PARAMS_OUT" << EOF
# flare parameters for SNP=$N
ref=$REF_OUT
ref-panel=$PANEL_OUT
gt=$GT_OUT
map=$MAP_OUT
out=flare_result
min-maf=0
min-mac=0
em=false
nthreads=#
seed=12345
probs=false
array=false
EOF

echo "[EXTRACT] Successfully created $REF_OUT and $GT_OUT"
