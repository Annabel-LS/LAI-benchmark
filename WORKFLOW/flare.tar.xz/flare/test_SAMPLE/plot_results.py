#!/usr/bin/env python3
import pandas as pd
import matplotlib.pyplot as plt
import sys
import os

def get_safe_font():
    """检测系统可用字体，返回一个安全的 sans-serif 字体名称"""
    from matplotlib.font_manager import FontManager
    fm = FontManager()
    available = [f.name for f in fm.ttflist]
    # 优先使用 DejaVu Sans（通常 Linux 下存在），其次使用 Arial 或通用 sans-serif
    for font in ['DejaVu Sans', 'Arial', 'Liberation Sans', 'sans-serif']:
        if font in available or font == 'sans-serif':
            return font
    return 'sans-serif'

def main():
    if len(sys.argv) != 3:
        print("用法: python plot_results.py <timings.csv> <output.png>")
        sys.exit(1)
    
    csv_file = sys.argv[1]
    out_png = sys.argv[2]
    
    if not os.path.exists(csv_file):
        print(f"错误: 文件 {csv_file} 不存在")
        sys.exit(1)
    
    df = pd.read_csv(csv_file)
    # 过滤失败的行（runtime == "NA"）
    df = df[df['runtime_seconds'] != "NA"].copy()
    df['runtime_seconds'] = df['runtime_seconds'].astype(float)
    
    # 按样本数排序（确保顺序为 20,60,80,99）
    df = df.sort_values('sample_size')
    
    # 获取字体
    font_name = get_safe_font()
    print(f"使用字体: {font_name}")
    
    # 绘图
    plt.figure(figsize=(8, 6), dpi=600)
    plt.plot(df['sample_size'], df['runtime_seconds'], 
             marker='o', linestyle='-', linewidth=2, markersize=8, color='#1f77b4')
    
    # 添加数据标签，交替上下位置
    # 样本数顺序：20,60,80,99  → 位置索引 0,1,2,3
    offsets = [15, -15, 15, -15]   # 正数表示向上偏移（点上方），负数向下
    ha_align = ['center', 'center', 'center', 'center']
    
    for i, (x, y) in enumerate(zip(df['sample_size'], df['runtime_seconds'])):
        # 格式化标签：保留2位小数，加 "s"
        label = f"{y:.2f}s"
        offset = offsets[i] if i < len(offsets) else 10
        va = 'bottom' if offset > 0 else 'top'
        plt.annotate(label, 
                     xy=(x, y), 
                     xytext=(0, offset),
                     textcoords='offset points',
                     ha='center', 
                     va=va,
                     fontsize=9,
                     fontname=font_name)
    
    # 坐标轴标签和标题
    plt.xlabel('Number of Samples', fontsize=12, fontname=font_name)
    plt.ylabel('Runtime (seconds)', fontsize=12, fontname=font_name)
    plt.title('FLARE Runtime vs Sample Size', fontsize=14, fontname=font_name)
    plt.grid(True, linestyle='--', alpha=0.6)
    
    # 设置坐标轴刻度字体
    ax = plt.gca()
    for tick in ax.get_xticklabels():
        tick.set_fontname(font_name)
    for tick in ax.get_yticklabels():
        tick.set_fontname(font_name)
    
    plt.tight_layout()
    plt.savefig(out_png, dpi=600)
    print(f"图表已保存: {out_png}")

if __name__ == "__main__":
    main()
