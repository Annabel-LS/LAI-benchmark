#!/bin/bash
# run_test.sh – 样本数梯度测试交互脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数（所有输出到 stderr，避免被命令替换捕获）
log_info() { echo -e "${BLUE}[INFO]${NC} $1" >&2; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $1" >&2; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1" >&2; }

# ==================== 用户修改部分 ====================
FULL_VCF="your_sample.vcf.gz"
REF_VCF="ref.vcf.gz"
REF_PANEL="Ref_panel.txt"
GENETIC_MAP="genetic_map.map"
FLARE_JAR="flare.jar"
# ====================================================

# 固定测试参数
SAMPLE_SIZES=(20 60 80 99)
THREADS=#
FLARE_MEM="16g"
SEED=12345

# 工作目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESULTS_DIR="${SCRIPT_DIR}/results"
TEMP_DIR="${SCRIPT_DIR}/temp"
LISTS_DIR="${SCRIPT_DIR}/sample_lists"

mkdir -p "$RESULTS_DIR" "$TEMP_DIR" "$LISTS_DIR"

# 检查必需文件
check_files() {
    local missing=0
    for f in "$FULL_VCF" "$REF_VCF" "$REF_PANEL" "$GENETIC_MAP" "$FLARE_JAR"; do
        if [ ! -f "$f" ]; then
            log_error "文件不存在: $f"
            missing=1
        fi
    done
    if [ $missing -eq 1 ]; then
        exit 1
    fi
}

# 生成随机样本列表
generate_sample_list() {
    local size=$1
    local out_list="${LISTS_DIR}/samples_${size}.txt"
    if [ -f "$out_list" ] && [ "$(wc -l < "$out_list")" -eq "$size" ]; then
        log_info "样本列表已存在: $out_list"
        return
    fi
    log_info "从 $FULL_VCF 中随机抽取 $size 个样本..."
    bcftools query -l "$FULL_VCF" > "${TEMP_DIR}/all_samples.txt"
    total=$(wc -l < "${TEMP_DIR}/all_samples.txt")
    if [ "$total" -lt "$size" ]; then
        log_error "VCF 中只有 $total 个样本，无法抽取 $size 个"
        exit 1
    fi
    shuf -n "$size" "${TEMP_DIR}/all_samples.txt" > "$out_list"
    log_success "生成样本列表: $out_list"
}

# 生成子集 VCF
create_subset_vcf() {
    local size=$1
    local sample_list="${LISTS_DIR}/samples_${size}.txt"
    local out_vcf="${TEMP_DIR}/subset_${size}.vcf.gz"
    if [ -f "$out_vcf" ]; then
        log_info "子集 VCF 已存在: $out_vcf"
        echo "$out_vcf"
        return
    fi
    log_info "生成子集 VCF (样本数=$size)..."
    bcftools view -S "$sample_list" -Oz -o "$out_vcf" "$FULL_VCF"
    bcftools index -t "$out_vcf"
    log_success "生成子集 VCF: $out_vcf"
    echo "$out_vcf"
}

# 运行一次 FLARE 并记录时间（关键修改：java 输出全部重定向到文件，不经过 tee）
run_flare() {
    local size=$1
    local subset_vcf=$2
    local out_prefix="${TEMP_DIR}/flare_out_${size}"
    local log_file="${RESULTS_DIR}/flare_${size}.log"
    
    log_info "运行 FLARE: 样本数=$size"
    
    # 清空旧日志
    > "$log_file"
    local start_time=$(date +%s.%N)
    
    # 注意：所有输出（包括错误）都重定向到日志文件，不输出到 stdout
    java -Xmx"$FLARE_MEM" -jar "$FLARE_JAR" \
        ref="$REF_VCF" \
        ref-panel="$REF_PANEL" \
        gt="$subset_vcf" \
        map="$GENETIC_MAP" \
        out="$out_prefix" \
        nthreads="$THREADS" \
        em=false \
        min-maf=0 \
        min-mac=0 \
        array=false \
        seed="$SEED" \
        probs=false \
        >> "$log_file" 2>&1
    
    local end_time=$(date +%s.%N)
    local runtime=$(echo "$end_time - $start_time" | bc)
    
    if [ -f "${out_prefix}.anc.vcf.gz" ]; then
        log_success "FLARE 完成，耗时 ${runtime} 秒"
        echo "$runtime"   # 只有这一行输出到 stdout
    else
        log_error "FLARE 运行失败，查看日志: $log_file"
        echo "FAILED"
    fi
}

# 执行所有测试
run_all_tests() {
    local result_csv="${RESULTS_DIR}/timings.csv"
    echo "sample_size,runtime_seconds" > "$result_csv"
    
    for size in "${SAMPLE_SIZES[@]}"; do
        log_info "========================================="
        log_info "测试样本数: $size"
        generate_sample_list "$size"
        subset_vcf=$(create_subset_vcf "$size")
        runtime=$(run_flare "$size" "$subset_vcf")
        if [ "$runtime" != "FAILED" ]; then
            echo "$size,$runtime" >> "$result_csv"
        else
            echo "$size,NA" >> "$result_csv"
            log_error "样本数 $size 测试失败，跳过"
        fi
        sleep 2
    done
    
    log_success "所有测试完成，结果保存在: $result_csv"
}

# 生成数据报告（调用 Python 绘图）
generate_report() {
    local result_csv="${RESULTS_DIR}/timings.csv"
    if [ ! -f "$result_csv" ]; then
        log_error "结果文件不存在，请先运行测试 (选项1)"
        return
    fi
    local plot_file="${RESULTS_DIR}/runtime_vs_samples.png"
    if command -v python3 &>/dev/null; then
        python3 "$SCRIPT_DIR/plot_results.py" "$result_csv" "$plot_file"
        if [ $? -eq 0 ]; then
            log_success "报告已生成: $plot_file"
        else
            log_error "Python 脚本执行失败"
        fi
    else
        log_error "未找到 python3，无法生成图表"
    fi
}

# 删除测试数据
clean_data() {
    log_warning "即将删除以下目录中的所有测试数据:"
    echo "  - $TEMP_DIR"
    echo "  - $LISTS_DIR"
    echo "  - $RESULTS_DIR (保留 .csv 和 .png 文件？将询问)"
    read -p "确认删除所有临时文件？(y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$TEMP_DIR"/*
        rm -rf "$LISTS_DIR"/*
        find "$RESULTS_DIR" -type f -name "*.log" -delete
        find "$RESULTS_DIR" -type f -name "flare_out_*" -delete
        log_success "测试数据已清理"
    else
        log_info "取消清理"
    fi
}

# 交互菜单
menu() {
    echo ""
    echo "========================================="
    echo "   FLARE 样本数梯度测试工具"
    echo "========================================="
    echo "1) 开始测试 (样本数: ${SAMPLE_SIZES[*]})"
    echo "2) 生成数据报告 (折线图)"
    echo "3) 删除测试数据"
    echo "4) 退出"
    echo "========================================="
    read -p "请选择 [1-4]: " choice
    case $choice in
        1)
            check_files
            run_all_tests
            ;;
        2)
            generate_report
            ;;
        3)
            clean_data
            ;;
        4)
            exit 0
            ;;
        *)
            log_warning "无效选项"
            ;;
    esac
}

# 主循环
while true; do
    menu
done
