#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Loter 自动化分析流水线
功能：
1. 复制原始 .phased 文件并转换为 .npy（自动转置为 Loter 所需形状）
2. 运行 Loter 局部祖先推断（对照组3参考，实验组2参考）
3. 将结果 .npy 转换为 .loca 格式
支持断点续跑，交互式选择染色体范围
"""

import os
import sys
import json
import shutil
import logging
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

# 导入 Loter 模块
try:
    import loter.locanc.local_ancestry as lc
except ImportError:
    print("错误: 未安装 Loter 或导入失败。请先运行 'pip install loter'")
    sys.exit(1)

# ======================
# 用户配置区（请根据实际情况修改）
# ======================
# 原始数据根目录：内部应有 chr1/, chr2/, ... 文件夹，每个文件夹下包含所需 .phased 文件
RAW_DATA_BASE = "your_real_data"

# 工作目录（项目根目录，所有输出将存放在这里）
WORK_BASE = "your_project"

# Loter 运行参数
NUM_THREADS = #

# 是否启用形状自动转置（如果转换后的 .npy 是 (snps, haps) 而 Loter 需要 (haps, snps)）
AUTO_TRANSPOSE = True   # 默认开启

# 参考群体的顺序（对照组和实验组）
CONTROL_REFS = ["CHS", "CEU", "YRI"]   # 文件名中的标识
EXPERIMENT_REFS = ["CHS", "CEU"]           # 实验组只用两个
ADMIXED_FILE = "sample"                       # 混合样本文件名前缀

# ======================
# 日志初始化
# ======================
LOG_DIR = os.path.join(WORK_BASE, "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "pipeline.log")

# 清除已有的 handlers（避免重复）
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8', mode='a'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("LoterPipeline")
logger.info("========== 流水线启动 ==========")
logger.info(f"工作目录: {WORK_BASE}")
logger.info(f"日志文件: {LOG_FILE}")
logger.info(f"原始数据目录: {RAW_DATA_BASE}")

STATUS_FILE = os.path.join(WORK_BASE, "status.json")

# 染色体列表（1-22）
CHROMOSOMES = [str(i) for i in range(1, 23)]


# ======================
# 辅助函数
# ======================
def load_status():
    """加载状态文件，如果不存在则创建"""
    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, 'r') as f:
            return json.load(f)
    else:
        status = {}
        for chrom in CHROMOSOMES:
            status[chrom] = {
                "data_prep": False,
                "loter_control": False,
                "loter_experiment": False,
                "convert_control": False,
                "convert_experiment": False
            }
        save_status(status)
        return status

def save_status(status):
    with open(STATUS_FILE, 'w') as f:
        json.dump(status, f, indent=2)

def update_status(chrom, step, value):
    status = load_status()
    if chrom not in status:
        status[chrom] = {}
    status[chrom][step] = value
    save_status(status)

def convert_phased_to_npy(phased_path, npy_path):
    """
    将单个 .phased 文件转换为 .npy 矩阵。
    输出矩阵形状: (n_snps, n_haplotypes)  （行为SNP，列为单倍型）
    编码: A=0, T=1, C=2, G=3, 缺失=-1
    """
    logger.info(f"转换文件: {phased_path} -> {npy_path}")
    try:
        with open(phased_path, 'r') as f:
            # 读取表头（第一行，可能包含样本ID）
            header = f.readline().strip().split('\t')
            # 前两列通常是 ID 和 POS，后面是基因型列
            num_columns = len(header) - 2
            data_lines = []
            snp_count = 0
            for line in f:
                if line.strip():
                    parts = line.strip().split('\t')
                    # 跳过 ID 和 POS
                    genotypes = parts[2:]
                    if len(genotypes) != num_columns:
                        # 补齐或截断
                        if len(genotypes) < num_columns:
                            genotypes.extend(['N'] * (num_columns - len(genotypes)))
                        else:
                            genotypes = genotypes[:num_columns]
                    # 编码
                    encoded = []
                    for base in genotypes:
                        base_u = base.upper()
                        if base_u == 'A':
                            encoded.append(0)
                        elif base_u == 'T':
                            encoded.append(1)
                        elif base_u == 'C':
                            encoded.append(2)
                        elif base_u == 'G':
                            encoded.append(3)
                        else:
                            encoded.append(-1)
                    data_lines.append(encoded)
                    snp_count += 1
        if snp_count == 0:
            raise ValueError(f"文件 {phased_path} 无有效数据行")
        data_array = np.array(data_lines, dtype=np.int8)  # (n_snps, n_haps)
        np.save(npy_path, data_array)
        logger.info(f"转换成功: 形状 {data_array.shape}, 大小 {os.path.getsize(npy_path)/1024/1024:.2f} MB")
        return True
    except Exception as e:
        logger.error(f"转换失败 {phased_path}: {e}")
        return False

def ensure_loter_shape(npy_path):
    """
    检查 .npy 文件的形状，如果 AUTO_TRANSPOSE=True 且形状为 (snps, haps)，
    则转置为 (haps, snps) 并覆盖原文件。
    Loter 期望输入矩阵形状为 (n_haplotypes, n_snps)
    """
    if not AUTO_TRANSPOSE:
        return
    arr = np.load(npy_path)
    if arr.ndim != 2:
        logger.warning(f"文件 {npy_path} 不是二维数组，跳过转置")
        return
    # 启发式判断：如果第一维 > 第二维 * 2，则视为 (snps, haps) 需要转置
    if arr.shape[0] > arr.shape[1] * 2:
        logger.info(f"形状 {arr.shape} 疑似 (snps, haps)，转置为 (haps, snps)")
        arr_t = arr.T
        np.save(npy_path, arr_t)
        logger.info(f"转置完成，新形状 {arr_t.shape}")
    else:
        logger.debug(f"形状 {arr.shape} 符合预期，无需转置")

def copy_and_convert(chrom, work_base, force=False):
    """功能1：复制原始 .phased 文件并转换为 .npy"""
    chrom_dir = os.path.join(work_base, f"chr{chrom}")
    control_dir = os.path.join(chrom_dir, "control")
    experiment_dir = os.path.join(chrom_dir, "experiment")
    os.makedirs(control_dir, exist_ok=True)
    os.makedirs(experiment_dir, exist_ok=True)

    raw_chrom_dir = os.path.join(RAW_DATA_BASE, f"chr{chrom}")
    if not os.path.isdir(raw_chrom_dir):
        logger.error(f"原始数据目录不存在: {raw_chrom_dir}")
        return False

    # 定义需要处理的文件列表 (目标目录, 文件名前缀, 是否必须存在)
    files_to_copy = [
        (control_dir, ADMIXED_FILE, True),
        (experiment_dir, ADMIXED_FILE, True),
        (control_dir, "CHS", True),
        (experiment_dir, "CHS", True),
        (control_dir, "CEU", True),
        (experiment_dir, "CEU", True),
        (control_dir, "YRI", True),   # YRI 仅对照组
    ]
    success = True
    for target_dir, prefix, required in files_to_copy:
        if target_dir == experiment_dir and prefix == "YRI":
            continue   # 实验组跳过 YRI
        src_file = os.path.join(raw_chrom_dir, f"{prefix}_chr{chrom}.phased")
        dst_file = os.path.join(target_dir, f"{prefix}_chr{chrom}.phased")
        npy_file = os.path.join(target_dir, f"{prefix}_chr{chrom}.npy")
        if force or not os.path.exists(npy_file):
            if not os.path.exists(src_file):
                if required:
                    logger.error(f"缺失必需文件: {src_file}")
                    success = False
                    continue
                else:
                    logger.warning(f"跳过可选文件: {src_file}")
                    continue
            # 复制 .phased
            shutil.copy2(src_file, dst_file)
            logger.info(f"复制 {src_file} -> {dst_file}")
            # 转换为 .npy
            if convert_phased_to_npy(dst_file, npy_file):
                ensure_loter_shape(npy_file)
            else:
                success = False
        else:
            logger.info(f"文件已存在且未强制覆盖，跳过: {npy_file}")
    return success

def run_loter_for_group(chrom, work_base, group, force=False):
    """
    运行 Loter
    group: 'control' 或 'experiment'
    返回 True/False
    """
    chrom_dir = os.path.join(work_base, f"chr{chrom}")
    group_dir = os.path.join(chrom_dir, group)
    result_npy = os.path.join(group_dir, "loter_result.npy")
    
    if not force and os.path.exists(result_npy):
        logger.info(f"结果文件已存在且未强制覆盖，跳过 Loter 运行: {result_npy}")
        step_key = f"loter_{group}"
        update_status(chrom, step_key, True)
        return True
    
    admixed_path = os.path.join(group_dir, f"{ADMIXED_FILE}_chr{chrom}.npy")
    if not os.path.exists(admixed_path):
        logger.error(f"混合样本文件不存在: {admixed_path}")
        return False
    
    h_adm = np.load(admixed_path)
    l_H = []
    if group == "control":
        ref_prefixes = ["CHS_DE3", "CEU_DE3", "YRI_DE3"]
    else:
        ref_prefixes = ["CHS_DE3", "CEU_DE3"]
    
    for pref in ref_prefixes:
        ref_path = os.path.join(group_dir, f"{pref}_chr{chrom}.npy")
        if not os.path.exists(ref_path):
            logger.error(f"参考文件缺失: {ref_path}")
            return False
        l_H.append(np.load(ref_path))
    
    logger.info(f"运行 Loter {group}，染色体 {chrom}，参考数量 {len(l_H)}，混合样本形状 {h_adm.shape}")
    try:
        result = lc.loter_smooth(
            l_H=l_H,
            h_adm=h_adm,
            num_threads=NUM_THREADS
        )
        np.save(result_npy, result)
        logger.info(f"Loter 运行成功，结果保存至 {result_npy}，形状 {result.shape}")
        return True
    except Exception as e:
        logger.error(f"Loter 运行失败: {e}")
        return False

def convert_result_to_loca(chrom, work_base, group, force=False):
    """
    将 Loter 输出的 result.npy 转换为 .loca 格式
    group: 'control' 或 'experiment'
    """
    chrom_dir = os.path.join(work_base, f"chr{chrom}")
    group_dir = os.path.join(chrom_dir, group)
    result_npy = os.path.join(group_dir, "loter_result.npy")
    output_loca = os.path.join(group_dir, "loter_result.loca")
    original_phased = os.path.join(group_dir, f"{ADMIXED_FILE}_chr{chrom}.phased")
    
    if not os.path.exists(result_npy):
        logger.error(f"结果文件不存在，无法转换: {result_npy}")
        return False
    if not os.path.exists(original_phased):
        logger.error(f"原始 .phased 文件不存在，无法提取列名: {original_phased}")
        return False
    
    if not force and os.path.exists(output_loca):
        logger.info(f"转换文件已存在且未强制覆盖，跳过: {output_loca}")
        step_key = f"convert_{group}"
        update_status(chrom, step_key, True)
        return True
    
    # 加载 Loter 结果，形状应为 (n_haps, n_snps)
    res = np.load(result_npy)
    # 直接转置为 (n_snps, n_haps) 以便逐SNP写入
    res_t = res.T
    n_snps, n_hap = res_t.shape
    logger.info(f"转换结果: {n_snps} SNPs, {n_hap} haplotypes")
    
    # 读取原始 phased 文件获取 rsID, POS 和样本列名
    try:
        # 尝试有表头的方式
        df_header = pd.read_csv(original_phased, sep='\t', nrows=0)
        sample_hap_names = list(df_header.columns[2:])
        df_full = pd.read_csv(original_phased, sep='\t')
        ids = df_full.iloc[:, 0].astype(str).values
        pos = df_full.iloc[:, 1].astype(str).values
    except Exception:
        # 无表头的情况：手动构造列名
        logger.warning(f"文件 {original_phased} 无法读取表头，将使用默认列名")
        df_full = pd.read_csv(original_phased, sep='\t', header=None)
        ids = df_full.iloc[:, 0].astype(str).values
        pos = df_full.iloc[:, 1].astype(str).values
        n_total_cols = df_full.shape[1]
        n_haps_in_phased = n_total_cols - 2
        sample_hap_names = []
        for i in range(n_haps_in_phased):
            sample_id = i // 2 + 1
            suffix = 'A' if i % 2 == 0 else 'B'
            sample_hap_names.append(f"S{sample_id}_{suffix}")
    
    # 对齐 SNP 数量
    min_snps = min(n_snps, len(ids))
    if min_snps < n_snps:
        logger.warning(f"SNP 数量不一致: Loter结果 {n_snps}, 原始文件 {len(ids)}, 截断至 {min_snps}")
        res_t = res_t[:min_snps, :]
        ids = ids[:min_snps]
        pos = pos[:min_snps]
    
    # 对齐单倍型数量
    n_hap_orig = len(sample_hap_names)
    if n_hap_orig != n_hap:
        logger.warning(f"单倍型数量不一致: Loter结果 {n_hap}, 原始文件 {n_hap_orig}, 截断至 {min(n_hap, n_hap_orig)}")
        min_hap = min(n_hap, n_hap_orig)
        res_t = res_t[:, :min_hap]
        sample_hap_names = sample_hap_names[:min_hap]
    
    # 构建 DataFrame
    data = {'rsID': ids, 'POS': pos}
    for i, name in enumerate(sample_hap_names):
        data[name] = res_t[:, i]
    loca_df = pd.DataFrame(data)
    loca_df.to_csv(output_loca, sep='\t', index=False)
    logger.info(f".loca 文件已生成: {output_loca} ({loca_df.shape[0]} SNPs, {loca_df.shape[1]-2} haplotypes)")
    return True


# ======================
# 交互与主逻辑
# ======================
def select_chromosomes():
    """让用户选择染色体执行方式，返回染色体列表"""
    print("\n请选择染色体执行方式:")
    print("1. 单个染色体 (如 2)")
    print("2. 范围 (如 1-22)")
    print("3. 全部 (1-22)")
    print("4. 返回主菜单")
    choice = input("请输入数字: ").strip()
    if choice == '1':
        chrom_str = input("请输入染色体号 (1-22): ").strip()
        if chrom_str in CHROMOSOMES:
            return [chrom_str]
        else:
            print("无效染色体号")
            return []
    elif choice == '2':
        range_str = input("请输入范围 (如 1-22): ").strip()
        try:
            start, end = map(int, range_str.split('-'))
            return [str(i) for i in range(start, end+1) if str(i) in CHROMOSOMES]
        except:
            print("格式错误")
            return []
    elif choice == '3':
        return CHROMOSOMES
    else:
        return []

def run_step(step_func, step_name, force_prompt=False):
    """通用步骤执行器"""
    chrom_list = select_chromosomes()
    if not chrom_list:
        return
    force = False
    if force_prompt:
        resp = input("是否强制重新运行所有选定染色体？(y/n): ").strip().lower()
        force = (resp == 'y')
    for chrom in chrom_list:
        logger.info(f"开始执行 {step_name} 染色体 {chrom}")
        if step_func(chrom, WORK_BASE, force=force):
            if step_name == "数据准备":
                update_status(chrom, "data_prep", True)
            elif step_name == "Loter对照组":
                update_status(chrom, "loter_control", True)
            elif step_name == "Loter实验组":
                update_status(chrom, "loter_experiment", True)
            elif step_name == "结果转换对照组":
                update_status(chrom, "convert_control", True)
            elif step_name == "结果转换实验组":
                update_status(chrom, "convert_experiment", True)
        else:
            logger.error(f"{step_name} 染色体 {chrom} 失败")
    input("按回车键返回主菜单...")

def run_loter_both():
    """运行 Loter（对照组和实验组）"""
    chrom_list = select_chromosomes()
    if not chrom_list:
        return
    force = input("是否强制重新运行？(y/n): ").strip().lower() == 'y'
    for chrom in chrom_list:
        logger.info(f"运行 Loter 染色体 {chrom} - 对照组")
        if run_loter_for_group(chrom, WORK_BASE, "control", force=force):
            update_status(chrom, "loter_control", True)
        logger.info(f"运行 Loter 染色体 {chrom} - 实验组")
        if run_loter_for_group(chrom, WORK_BASE, "experiment", force=force):
            update_status(chrom, "loter_experiment", True)
    input("按回车键返回主菜单...")

def convert_both():
    """转换两组结果"""
    chrom_list = select_chromosomes()
    if not chrom_list:
        return
    force = input("是否强制重新转换？(y/n): ").strip().lower() == 'y'
    for chrom in chrom_list:
        logger.info(f"转换结果 染色体 {chrom} - 对照组")
        if convert_result_to_loca(chrom, WORK_BASE, "control", force=force):
            update_status(chrom, "convert_control", True)
        logger.info(f"转换结果 染色体 {chrom} - 实验组")
        if convert_result_to_loca(chrom, WORK_BASE, "experiment", force=force):
            update_status(chrom, "convert_experiment", True)
    input("按回车键返回主菜单...")

def main():
    # 确保工作目录存在
    os.makedirs(WORK_BASE, exist_ok=True)
    load_status()
    
    while True:
        print("\n" + "="*50)
        print(" Loter 自动化分析流水线")
        print("="*50)
        print(f"工作目录: {WORK_BASE}")
        print(f"线程数: {NUM_THREADS}")
        print("1. 数据准备 (复制+转换 .npy)")
        print("2. 运行 Loter (对照组 + 实验组)")
        print("3. 转换结果 .npy -> .loca")
        print("4. 退出")
        print("-"*50)
        choice = input("请选择: ").strip()
        if choice == '1':
            run_step(lambda c, wb, force: copy_and_convert(c, wb, force), "数据准备", force_prompt=True)
        elif choice == '2':
            run_loter_both()
        elif choice == '3':
            convert_both()
        elif choice == '4':
            logger.info("用户退出程序")
            break
        else:
            print("无效选项，请重新输入")

if __name__ == "__main__":
    main()
