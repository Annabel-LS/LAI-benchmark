import numpy as np
import pandas as pd

# ======================
# 配置
# ======================
RESULT_NPY = "sample.npy"   # Loter 结果 (40, 796678)
TRUE_FILE = "ancetry.phased"            #phased文件（含原始列名）
OUTPUT_LOCA = "result.loca"

# ======================
# 步骤 1: 加载 Loter 结果并转置为 (SNPs, haplotypes)
# ======================
res = np.load(RESULT_NPY)  # shape: (n_hap, n_snps) = (40, 796678)
res_t = res.T              # shape: (796678, 40)
n_snps, n_hap = res_t.shape
print(f"Loter 结果: {n_hap} 单倍型, {n_snps} SNPs")

# ======================
# 步骤 2: 读取真实文件（带列名）
# ======================
true_df = pd.read_csv(TRUE_FILE, sep='\t', header=None)

# 提取 rsID 和 POS
ids = true_df.iloc[:, 0].astype(str).values
pos = true_df.iloc[:, 1].astype(str).values

# 获取原始列名（如果没有 header，我们手动构造）
# 假设真实文件没有 header，但你知道前两列是 ID/POS，后面是样本单倍型
raw_columns = list(true_df.columns)
n_total_cols = len(raw_columns)

if n_total_cols < 2:
    raise ValueError("真实文件至少需要 2 列 (ID + POS)")

# 手动构造列名：前两列为 'rsID', 'POS'，其余按原始顺序命名
# 如果你的真实文件有 header，请用下面这行代替：
# true_df = pd.read_csv(TRUE_FILE, sep='\t')
# sample_hap_names = true_df.columns[2:].tolist()

# 否则，我们按 S1_A, S1_B, S2_A... 或保留原始索引名
# 但你说列名是 S1_A, S1_B 等 → 说明文件**有 header**！

# ✅ 更好的做法：**重新读取带 header 的真实文件**
try:
    true_df_with_header = pd.read_csv(TRUE_FILE, sep='\t')
    sample_hap_names = true_df_with_header.columns[2:].tolist()
    ids = true_df_with_header.iloc[:, 0].astype(str).values
    pos = true_df_with_header.iloc[:, 1].astype(str).values
    print(f"从真实文件读取到 {len(sample_hap_names)} 个单倍型列名")
except:
    # 如果没有 header，则按位置生成 S1_A, S1_B...
    n_sample_haps = n_total_cols - 2
    sample_hap_names = []
    for i in range(n_sample_haps):
        sample_id = i // 2 + 1
        suffix = 'A' if i % 2 == 0 else 'B'
        sample_hap_names.append(f"S{sample_id}_{suffix}")
    print("⚠️ 真实文件无 header，已生成默认列名: S1_A, S1_B, ...")

# ======================
# 步骤 3: 验证单倍型数量是否匹配
# ======================
if len(sample_hap_names) != n_hap:
    print(f"❌ 单倍型数量不匹配！")
    print(f"  真实文件: {len(sample_hap_names)} 列")
    print(f"  Loter 结果: {n_hap} 单倍型")
    
    # 尝试对齐（取最小值）
    min_hap = min(len(sample_hap_names), n_hap)
    sample_hap_names = sample_hap_names[:min_hap]
    res_t = res_t[:, :min_hap]
    print(f"→ 已截断至 {min_hap} 个单倍型")

# ======================
# 步骤 4: 构建 .loca DataFrame
# ======================
# 对齐 SNP 数量
n_snps_true = len(ids)
if n_snps_true != res_t.shape[0]:
    min_snps = min(n_snps_true, res_t.shape[0])
    ids = ids[:min_snps]
    pos = pos[:min_snps]
    res_t = res_t[:min_snps, :]
    print(f"→ SNP 数量对齐至 {min_snps}")

# 创建字典
data = {'rsID': ids, 'POS': pos}
for i, col_name in enumerate(sample_hap_names):
    data[col_name] = res_t[:, i]

loca_df = pd.DataFrame(data)

# ======================
# 步骤 5: 保存
# ======================
loca_df.to_csv(OUTPUT_LOCA, sep='\t', index=False)
print(f"\n✅ 成功生成 .loca 文件: {OUTPUT_LOCA}")
print(f"   列名示例: {list(loca_df.columns[:6])} ...")
