import numpy as np
import os
from pathlib import Path
import sys

def phased_to_npy_individual(input_files, output_dir='./'):
    """
    将每个.phased文件单独转换为.npy格式
    
    参数:
    input_files: .phased文件路径列表
    output_dir: 输出目录
    
    返回:
    stats_dict: 包含统计信息的字典
    """
    
    all_stats = {
        'files': [],
        'summary': {}
    }
    
    for file_idx, file_path in enumerate(input_files):
        print(f"正在处理文件 {file_idx+1}/{len(input_files)}: {os.path.basename(file_path)}")
        
        with open(file_path, 'r') as f:
            # 读取表头
            header = f.readline().strip().split('\t')
            
            # 计算列数：表头减去ID和POS两列
            num_columns = len(header) - 2
            
            # 计算样本数：列数除以2（每个样本两个单倍型）
            num_samples = num_columns // 2
            
            # 读取所有数据行
            data_lines = []
            snp_count = 0
            
            for line in f:
                if line.strip():
                    parts = line.strip().split('\t')
                    # 跳过ID和POS，只保留基因型数据
                    genotypes = parts[2:]
                    
                    # 检查数据长度是否与预期一致
                    if len(genotypes) != num_columns:
                        print(f"警告: 第{snp_count+1}行的列数({len(genotypes)})与表头列数({num_columns})不一致")
                        # 用缺失值填充
                        if len(genotypes) < num_columns:
                            genotypes.extend(['N'] * (num_columns - len(genotypes)))
                        else:
                            genotypes = genotypes[:num_columns]
                    
                    # 将ATCG转换为数字编码
                    encoded = []
                    for base in genotypes:
                        base_upper = base.upper()
                        if base_upper == 'A':
                            encoded.append(0)
                        elif base_upper == 'T':
                            encoded.append(1)
                        elif base_upper == 'C':
                            encoded.append(2)
                        elif base_upper == 'G':
                            encoded.append(3)
                        else:
                            # 处理可能的缺失值或其他字符
                            encoded.append(-1)
                    data_lines.append(encoded)
                    snp_count += 1
        
        if snp_count == 0:
            print(f"警告: 文件 {file_path} 没有数据行，跳过")
            continue
        
        # 转换为numpy数组
        data_array = np.array(data_lines, dtype=np.int8)
        
        # 生成输出文件名
        base_name = os.path.basename(file_path)
        npy_filename = os.path.splitext(base_name)[0] + '.npy'
        output_path = os.path.join(output_dir, npy_filename)
        
        # 保存为.npy文件
        np.save(output_path, data_array)
        
        # 记录文件统计信息
        file_stats = {
            'original_filename': base_name,
            'output_filename': npy_filename,
            'original_snps': snp_count,
            'original_columns': num_columns,
            'original_samples': num_samples,
            'output_snps': data_array.shape[0],
            'output_columns': data_array.shape[1],
            'output_shape': data_array.shape,
            'output_path': output_path,
            'file_size_mb': os.path.getsize(output_path)/1024/1024 if os.path.exists(output_path) else 0
        }
        all_stats['files'].append(file_stats)
        
        print(f"  ✓ 转换完成: {npy_filename}")
        print(f"    原始: {snp_count} 个SNP, {num_columns} 列 ({num_samples} 个样本)")
        print(f"    输出: {data_array.shape[0]} 个SNP, {data_array.shape[1]} 列")
        print(f"    文件大小: {file_stats['file_size_mb']:.2f} MB")
        print()
    
    # 创建统计摘要文件
    if all_stats['files']:
        summary_path = os.path.join(output_dir, 'individual_conversion_summary.txt')
        
        with open(summary_path, 'w') as f:
            f.write("PHASED文件分别转换统计摘要\n")
            f.write("=" * 60 + "\n\n")
            
            f.write("文件详细信息:\n")
            f.write("-" * 60 + "\n")
            
            for i, stats in enumerate(all_stats['files']):
                f.write(f"文件 {i+1}:\n")
                f.write(f"  原始文件名: {stats['original_filename']}\n")
                f.write(f"  输出文件名: {stats['output_filename']}\n")
                f.write(f"  原始SNP数: {stats['original_snps']}\n")
                f.write(f"  原始列数: {stats['original_columns']}\n")
                f.write(f"  原始样本数: {stats['original_samples']}\n")
                f.write(f"  输出SNP数: {stats['output_snps']}\n")
                f.write(f"  输出列数: {stats['output_columns']}\n")
                f.write(f"  输出形状: {stats['output_shape']}\n")
                f.write(f"  输出路径: {stats['output_path']}\n")
                f.write(f"  文件大小: {stats['file_size_mb']:.2f} MB\n")
                f.write("\n")
            
            # 汇总统计
            total_original_snps = sum(s['original_snps'] for s in all_stats['files'])
            total_output_snps = sum(s['output_snps'] for s in all_stats['files'])
            
            f.write("汇总统计:\n")
            f.write("-" * 60 + "\n")
            f.write(f"处理文件总数: {len(all_stats['files'])}\n")
            f.write(f"原始总SNP数: {total_original_snps}\n")
            f.write(f"输出总SNP数: {total_output_snps}\n")
            
            # 检查所有文件的列数是否一致
            column_counts = [s['original_columns'] for s in all_stats['files']]
            if len(set(column_counts)) == 1:
                f.write(f"列数(所有文件相同): {column_counts[0]} 列\n")
                f.write(f"样本数(所有文件相同): {column_counts[0]//2} 个样本\n")
            else:
                f.write(f"列数(各文件不同): {column_counts}\n")
            
            f.write(f"输出文件格式: .npy (NumPy二进制格式)\n")
            f.write(f"数据类型: int8\n")
            f.write(f"编码方式: A=0, T=1, C=2, G=3, 缺失=-1\n")
        
        print("\n" + "="*60)
        print("转换完成！")
        print(f"统计摘要已保存到: {summary_path}")
        print("\n转换结果汇总:")
        print("-"*60)
        
        for i, stats in enumerate(all_stats['files']):
            print(f"{i+1}. {stats['original_filename']} → {stats['output_filename']}")
            print(f"   原始: {stats['original_snps']} SNP, {stats['original_columns']} 列")
            print(f"   输出: {stats['output_snps']} SNP, {stats['output_columns']} 列")
        
        print("-"*60)
        print(f"总共处理: {len(all_stats['files'])} 个文件")
        print(f"原始总SNP: {total_original_snps}")
        print(f"输出总SNP: {total_output_snps}")
        print("="*60)
        
        return all_stats
    else:
        print("错误: 没有找到有效数据")
        return None

def main():
    # 方法1: 手动指定6个文件
    # phased_files = [
    #     '01_ancestry.phased',
    #     'CHS_de9.phased',
    #     'YRI_de9.phased'
    # ]
    
    # 方法2: 自动查找当前目录下所有.phased文件
    phased_files = list(Path('.').glob('*.phased'))
    
    if not phased_files:
        print("错误: 没有找到.phased文件")
        print("请确保文件在当前目录，且扩展名为.phased")
        print("支持的扩展名: .phased, .phased.gz, .phase, .vcf等")
        return
    
    # 如果只想处理恰好6个文件
    if len(phased_files) != 6:
        print(f"找到 {len(phased_files)} 个.phased文件")
        response = input(f"找到了{len(phased_files)}个。继续处理吗？(y/n): ")
        if response.lower() != 'y':
            return
    
    # 转换为字符串路径列表
    phased_files = [str(f) for f in phased_files]
    
    # 执行转换
    stats = phased_to_npy_individual(phased_files)
    
    if stats:
        # 验证一个.npy文件作为示例
        if stats['files']:
            example_file = stats['files'][0]['output_path']
            print(f"\n验证第一个文件: {os.path.basename(example_file)}")
            try:
                loaded_array = np.load(example_file)
                print(f"形状: {loaded_array.shape}")
                print(f"数据类型: {loaded_array.dtype}")
                print("前3行，前8列的数据:")
                print(loaded_array[:3, :8])
                
                # 显示编码映射
                print("\n编码说明:")
                print("0 → A")
                print("1 → T") 
                print("2 → C")
                print("3 → G")
                print("-1 → 缺失/未知")
            except Exception as e:
                print(f"验证时出错: {e}")

if __name__ == "__main__":
    main()
