#!/bin/bash
# Loter 样本数速度测试主程序

cd "$(dirname "$0")"

if ! command -v python3 &> /dev/null; then
    echo "错误：未找到 python3，请安装 Python 3 后再试。"
    exit 1
fi

GREEN='\033[0;32m'
NC='\033[0m'

show_menu() {
    echo -e "\n${GREEN}========================================${NC}"
    echo -e "${GREEN}    样本数速度测试工具${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo "1. 开始测试"
    echo "2. 生成数据报告"
    echo "3. 删除测试数据"
    echo "0. 退出"
    echo -n "请选择 [0-3]: "
}

while true; do
    show_menu
    read choice
    case $choice in
        1)
            echo "开始样本数测试..."
            python3 test_samples.py <<< "1"
            ;;
        2)
            echo "生成数据报告..."
            python3 test_samples.py <<< "2"
            ;;
        3)
            echo "删除测试数据..."
            python3 test_samples.py <<< "3"
            ;;
        0)
            echo "退出程序。"
            exit 0
            ;;
        *)
            echo "无效选项，请重新输入。"
            ;;
    esac
done
