#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

# ==================== 输入文件路径 ====================
# 参考群体单倍型文件（原始格式：SNP × 单倍型，脚本内会自动转置）
REF_FILES = [
    "CHS.npy",
    "YRI.npy",
]

# 混合个体单倍型文件（第9代，99个个体，理论上应为198个单倍型 × SNP）
# 注意：实际文件形状可能为 (40, 796678)，脚本内会自动检测并转置
ADM_FILE = "MEX.npy"

# ==================== 样本数量测试梯度 ====================
SAMPLE_GRADIENTS = [20, 60, 80, 99]

# ==================== 输出目录和文件 ====================
OUTPUT_DIR = "sample_speed_results"
TIME_LOG = os.path.join(OUTPUT_DIR, "times.txt")
REPORT_FILE = os.path.join(OUTPUT_DIR, "report.txt")
PLOT_FILE = os.path.join(OUTPUT_DIR, "sample_performance.png")

# ==================== Loter 运行参数 ====================
NUM_THREADS = #
USE_SMOOTH = True        # True: 使用 loter_smooth（带相位校正）; False: 仅 bagging
