#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontManager
import config

# 导入 Loter
try:
    import loter.locanc.local_ancestry as lc
except ImportError:
    print("错误：未找到 Loter 模块。请先安装 Loter（pip install loter）")
    sys.exit(1)

# ==================== 字体检测 ====================
def get_safe_font():
    """检测系统可用字体，返回一个安全的 sans-serif 字体名称"""
    fm = FontManager()
    available = [f.name for f in fm.ttflist]
    for font in ['DejaVu Sans', 'Arial', 'Liberation Sans', 'sans-serif']:
        if font in available or font == 'sans-serif':
            return font
    return 'sans-serif'

# ==================== 辅助函数 ====================
def load_data():
    """加载参考文件和混合文件，确保参考文件形状为 (n_haplotypes, n_snps)"""
    print("正在加载参考文件...")
    ref_arrays = []
    for f in config.REF_FILES:
        if not os.path.exists(f):
            print(f"错误：文件不存在 {f}")
            sys.exit(1)
        arr = np.load(f)
        # 假设参考文件已经是 (n_haplotypes, n_snps)，不做转置
        print(f"  {os.path.basename(f)}: 形状 {arr.shape}")
        ref_arrays.append(arr)

    print("正在加载混合文件...")
    if not os.path.exists(config.ADM_FILE):
        print(f"错误：文件不存在 {config.ADM_FILE}")
        sys.exit(1)
    adm_full = np.load(config.ADM_FILE)

    # 混合文件：如果行数远大于列数（即可能是 (n_snps, n_haplotypes)），则转置
    if adm_full.shape[0] > adm_full.shape[1]:
        print("检测到混合文件可能为 (n_snps, n_haplotypes)，执行转置...")
        adm_full = adm_full.T
        print(f"  转置后形状: {adm_full.shape}")
    else:
        print(f"  混合文件形状: {adm_full.shape}")

    # 确保单倍型数量为偶数
    if adm_full.shape[0] % 2 != 0:
        print(f"错误：混合文件单倍型数量 {adm_full.shape[0]} 不是偶数，无法对应个体。")
        sys.exit(1)

    return ref_arrays, adm_full

def extract_samples(adm_full, sample_indices):
    """
    从完整混合单倍型矩阵中提取指定样本的单倍型。
    adm_full: shape (n_haplotypes, n_snps)，其中 n_haplotypes = 2 * 总样本数
    sample_indices: 要保留的样本索引列表（0-based）
    返回新的混合单倍型矩阵，形状为 (2*len(sample_indices), n_snps)
    """
    new_haps = []
    for idx in sample_indices:
        new_haps.append(adm_full[2*idx, :])
        new_haps.append(adm_full[2*idx+1, :])
    return np.vstack(new_haps)

def run_loter(ref_arrays, adm_sub):
    """运行 Loter 并返回耗时（秒）"""
    start = time.perf_counter()
    if config.USE_SMOOTH:
        _ = lc.loter_smooth(l_H=ref_arrays, h_adm=adm_sub, num_threads=config.NUM_THREADS)
    else:
        _ = lc.loter_local_ancestry(l_H=ref_arrays, h_adm=adm_sub, num_threads=config.NUM_THREADS)
    elapsed = time.perf_counter() - start
    return elapsed

def record_time(n_samples, elapsed, csv_writer=None):
    """记录时间到文件（文本和CSV）"""
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    with open(config.TIME_LOG, "a") as f:
        f.write(f"{n_samples}\t{elapsed:.4f}\n")
    if csv_writer is not None:
        csv_writer.write(f"{n_samples},{elapsed:.4f}\n")

def run_sample_test():
    """执行样本数梯度测试"""
    print("\n" + "="*50)
    print("样本数速度测试")
    print("="*50)

    ref_arrays, adm_full = load_data()
    total_individuals = adm_full.shape[0] // 2
    print(f"完整混合数据包含 {total_individuals} 个个体。")

    gradients = [n for n in config.SAMPLE_GRADIENTS if n <= total_individuals]
    if not gradients:
        print(f"错误：所有样本数梯度均大于总个体数 {total_individuals}，无法测试。")
        return

    print(f"\n将测试以下样本数量: {gradients}")
    print("注意：每次随机抽取样本（无固定种子），结果可能略有波动。")
    print("开始测试...\n")

    # 确保输出目录存在
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    csv_path = os.path.join(config.OUTPUT_DIR, "sample_times.csv")
    with open(csv_path, 'w') as csvf:
        csvf.write("sample_size,runtime_seconds\n")
        for n_samples in gradients:
            print(f"正在测试样本数: {n_samples}")
            sample_indices = random.sample(range(total_individuals), n_samples)
            adm_sub = extract_samples(adm_full, sample_indices)
            elapsed = run_loter(ref_arrays, adm_sub)
            print(f"  耗时: {elapsed:.4f} 秒")
            record_time(n_samples, elapsed, csvf)

    print(f"\n测试完成！结果已保存到 {config.TIME_LOG} 和 {csv_path}")

# ==================== 报告生成 ====================
def plot_sample_performance(csv_file, output_png):
    """根据 CSV 文件绘制折线图"""
    if not os.path.exists(csv_file):
        print(f"错误：CSV 文件 {csv_file} 不存在")
        return False

    df = pd.read_csv(csv_file)
    df['runtime_seconds'] = pd.to_numeric(df['runtime_seconds'], errors='coerce')
    df = df.dropna(subset=['runtime_seconds'])
    df = df.sort_values('sample_size')

    font_name = get_safe_font()
    print(f"使用字体: {font_name}")

    plt.figure(figsize=(8, 6), dpi=600)
    plt.plot(df['sample_size'], df['runtime_seconds'],
             marker='o', linestyle='-', linewidth=2, markersize=8, color='#1f77b4')

    offsets = [15, -15, 15, -15, 15, -15, 15, -15]
    for i, (x, y) in enumerate(zip(df['sample_size'], df['runtime_seconds'])):
        label = f"{y:.2f}s"
        offset = offsets[i] if i < len(offsets) else 10
        va = 'bottom' if offset > 0 else 'top'
        plt.annotate(label, xy=(x, y), xytext=(0, offset),
                     textcoords='offset points', ha='center', va=va,
                     fontsize=9, fontname=font_name)

    plt.xlabel('Number of Samples', fontsize=12, fontname=font_name)
    plt.ylabel('Runtime (seconds)', fontsize=12, fontname=font_name)
    plt.title('Loter Runtime vs Sample Size', fontsize=14, fontname=font_name)
    plt.grid(True, linestyle='--', alpha=0.6)

    ax = plt.gca()
    for tick in ax.get_xticklabels():
        tick.set_fontname(font_name)
    for tick in ax.get_yticklabels():
        tick.set_fontname(font_name)

    plt.tight_layout()
    plt.savefig(output_png, dpi=600)
    plt.close()
    print(f"图表已保存: {output_png}")
    return True

def generate_report():
    """生成文本报告和折线图"""
    if not os.path.exists(config.TIME_LOG):
        print("错误：未找到时间记录文件，请先运行测试。")
        return

    data = []
    with open(config.TIME_LOG) as f:
        for line in f:
            if line.strip():
                parts = line.strip().split()
                if len(parts) == 2:
                    data.append((int(parts[0]), float(parts[1])))
    if not data:
        print("错误：时间文件为空。")
        return

    df = pd.DataFrame(data, columns=['sample_size', 'runtime_seconds'])
    df = df.sort_values('sample_size')

    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    with open(config.REPORT_FILE, 'w') as f:
        f.write("="*50 + "\n")
        f.write("SAMPLE SIZE PERFORMANCE REPORT\n")
        f.write("="*50 + "\n\n")
        f.write(f"Test date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Number of threads: {config.NUM_THREADS}\n")
        f.write(f"Method: {'smooth' if config.USE_SMOOTH else 'bagging'}\n\n")
        f.write("Sample Size\tTime (seconds)\n")
        for _, row in df.iterrows():
            f.write(f"{int(row['sample_size'])}\t\t{row['runtime_seconds']:.4f}\n")
        f.write("\n" + "="*50 + "\n")
    print(f"文本报告已生成: {config.REPORT_FILE}")

    csv_path = os.path.join(config.OUTPUT_DIR, "sample_times.csv")
    if os.path.exists(csv_path):
        plot_sample_performance(csv_path, config.PLOT_FILE)
    else:
        print("警告：未找到 CSV 文件，无法生成图表。")

def clean_data():
    """删除所有测试数据"""
    if os.path.exists(config.OUTPUT_DIR):
        import shutil
        shutil.rmtree(config.OUTPUT_DIR)
        print(f"已删除目录 {config.OUTPUT_DIR}")
    else:
        print("没有找到需要清理的数据。")

# ==================== 交互菜单 ====================
def main():
    while True:
        print("\n" + "="*40)
        print("样本数速度测试工具")
        print("="*40)
        print("1. 开始测试")
        print("2. 生成数据报告")
        print("3. 删除测试数据")
        print("4. 退出")
        choice = input("请选择 [1-4]: ").strip()
        if choice == "1":
            run_sample_test()
        elif choice == "2":
            generate_report()
        elif choice == "3":
            clean_data()
        elif choice == "4":
            print("退出程序。")
            break
        else:
            print("无效选项，请重新输入。")

if __name__ == "__main__":
    main()
