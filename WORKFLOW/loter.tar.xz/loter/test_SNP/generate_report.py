# generate_report.py
import os
import pandas as pd
from datetime import datetime
from plot_simple import plot_loter_performance  # 直接导入函数

from config import RESULTS_DIR, FIGURES_DIR

def generate_report():
    """
    生成测试报告
    """
    print("=" * 50)
    print("Generating Test Report")
    print("=" * 50)
    
    # 报告文件
    report_file = os.path.join(RESULTS_DIR, "test_report.txt")
    
    # 检查结果文件
    full_test_file = os.path.join(RESULTS_DIR, "full_test_results.csv")
    quick_test_file = os.path.join(RESULTS_DIR, "quick_test_results.csv")
    
    # 读取最新可用的测试数据
    if os.path.exists(full_test_file):
        data_file = full_test_file
        test_type = "Full Test"
    elif os.path.exists(quick_test_file):
        data_file = quick_test_file
        test_type = "Quick Test"
    else:
        print("No test results found!")
        return
    
    print(f"Test Type: {test_type}")
    print(f"Data File: {os.path.basename(data_file)}")
    
    # 读取数据
    df = pd.read_csv(data_file)
    
    # 开始生成报告
    with open(report_file, 'w') as f:
        f.write("=" * 60 + "\n")
        f.write("LOTER PERFORMANCE TEST REPORT\n")
        f.write("=" * 60 + "\n\n")
        
        f.write(f"Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"Test Type: {test_type}\n")
        f.write(f"Data File: {os.path.basename(data_file)}\n\n")
        
        # 基本信息
        f.write("TEST SUMMARY\n")
        f.write("-" * 40 + "\n")
        f.write(f"Total test runs: {len(df)}\n")
        f.write(f"Number of different SNP counts: {df['snp_count'].nunique()}\n")
        f.write(f"Methods tested: {', '.join(df['method'].unique())}\n\n")
        
        # 计算统计信息
        total_time = df['time_seconds'].sum()
        avg_time = df['time_seconds'].mean()
        max_snp = df['snp_count'].max()
        min_time = df['time_seconds'].min()
        max_time = df['time_seconds'].max()
        
        # 计算每千SNP的平均时间
        df['time_per_1000'] = df['time_seconds'] / (df['snp_count'] / 1000)
        avg_time_per_1000 = df['time_per_1000'].mean()
        
        # 性能统计
        f.write("PERFORMANCE STATISTICS\n")
        f.write("-" * 40 + "\n")
        f.write(f"Maximum SNPs tested: {max_snp:,}\n")
        f.write(f"Total testing time: {total_time:.2f} seconds ({total_time/3600:.2f} hours)\n")
        f.write(f"Minimum time: {min_time:.2f} seconds\n")
        f.write(f"Maximum time: {max_time:.2f} seconds\n")
        f.write(f"Average time: {avg_time:.2f} seconds\n")
        f.write(f"Average per 1k SNPs: {avg_time_per_1000:.4f} seconds\n\n")
        
        # 详细结果
        f.write("DETAILED RESULTS\n")
        f.write("-" * 40 + "\n")
        
        # 按方法分组显示结果
        for method in df['method'].unique():
            f.write(f"\nMethod: {method}\n")
            method_df = df[df['method'] == method].sort_values('snp_count')
            
            for _, row in method_df.iterrows():
                time_per_1000 = row['time_seconds'] / (row['snp_count'] / 1000)
                f.write(f"  {row['snp_count']:,} SNPs: {row['time_seconds']:.2f} seconds (per 1k: {time_per_1000:.4f}s)\n")
        
        # 找出最快和最慢的配置
        if len(df) > 0:
            fastest = df.loc[df['time_seconds'].idxmin()]
            slowest = df.loc[df['time_seconds'].idxmax()]
            
            f.write(f"\nFastest configuration:\n")
            f.write(f"  {fastest['snp_count']:,} SNPs: {fastest['time_seconds']:.2f} seconds\n")
            
            f.write(f"\nSlowest configuration:\n")
            f.write(f"  {slowest['snp_count']:,} SNPs: {slowest['time_seconds']:.2f} seconds\n")
            
            # 计算性能比例
            if slowest['time_seconds'] > 0:
                speed_ratio = slowest['time_seconds'] / fastest['time_seconds']
                f.write(f"\nSlowest/Fastest ratio: {speed_ratio:.2f}x\n")
        
        # 结束报告
        f.write("\n" + "=" * 60 + "\n")
        f.write("END OF REPORT\n")
        f.write("=" * 60 + "\n")
    
    print(f"Report generated: {report_file}")
    
    # 生成图表
    print("\nGenerating chart...")
    chart_file = plot_loter_performance(data_file)  # 直接调用函数
    print(f"Chart generated: {chart_file}")
    
    # 显示关键统计信息
    print("\nKey Performance Statistics:")
    print("-" * 40)
    print(f"  Maximum SNPs tested: {max_snp:,}")
    print(f"  Total testing time: {total_time:.2f} seconds ({total_time/3600:.2f} hours)")
    print(f"  Minimum time: {min_time:.2f} seconds")
    print(f"  Maximum time: {max_time:.2f} seconds")
    print(f"  Average per 1k SNPs: {avg_time_per_1000:.4f} seconds")
    
    print("\n" + "=" * 50)
    print("Report Generation Complete!")
    print("=" * 50)

if __name__ == "__main__":
    generate_report()
