# plot_simple.py
import pandas as pd
import matplotlib.pyplot as plt
import os
import numpy as np
from matplotlib.ticker import FuncFormatter

from config import FIGURES_DIR

def format_snp_tick(x, pos):
    """格式化SNP数量刻度标签"""
    if x >= 1_000_000:
        return f'{x/1_000_000:.1f}M'
    elif x >= 1_000:
        return f'{x/1_000:.0f}K'
    else:
        return f'{x:.0f}'

def plot_loter_performance(results_file):
    """
    绘制Loter运行时间与SNP数量关系图
    """
    # 读取数据
    df = pd.read_csv(results_file)
    
    # 确保数据按SNP数量排序
    df = df.sort_values('snp_count')
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # 设置背景色为白色
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    
    # 计算性能统计
    total_time = df['time_seconds'].sum()
    avg_time = df['time_seconds'].mean()
    max_snp = df['snp_count'].max()
    min_time = df['time_seconds'].min()
    max_time = df['time_seconds'].max()
    
    # 计算每千SNP的平均时间
    df['time_per_1000'] = df['time_seconds'] / (df['snp_count'] / 1000)
    avg_time_per_1000 = df['time_per_1000'].mean()
    
    # 绘制折线图 - 蓝色线条和节点
    line, = ax.plot(df['snp_count'], df['time_seconds'], 
                   marker='o', linewidth=3, markersize=10,
                   color='blue', markerfacecolor='white', 
                   markeredgecolor='blue', markeredgewidth=2)
    
    # 只在snp_count >= 50000的数据点添加标签
    for i, (idx, row) in enumerate(df.iterrows()):
        snp = row['snp_count']
        time_val = row['time_seconds']
        
        # 只标记≥50000的节点
        if snp >= 50000:
            # 根据位置调整标签偏移
            if snp in [50000, 75000, 150000, 250000, 350000, 450000]:
                y_offset = 20  # 向上偏移
            elif snp in [100000, 200000, 300000, 400000, 500000, 600000, 700000]:
                y_offset = -25  # 向下偏移
            elif snp == 796678:
                y_offset = -35  # 最大数据点更向下
            else:
                y_offset = 20  # 默认向上偏移
            
            # 添加节点标签
            ax.annotate(f"{time_val:.1f}s", 
                       xy=(snp, time_val),
                       xytext=(0, y_offset), textcoords='offset points',
                       ha='center', fontsize=10, fontweight='bold',
                       color='black',
                       bbox=dict(boxstyle="round,pad=0.3", 
                                facecolor="white", 
                                edgecolor="lightgray", 
                                alpha=0.9))
    
    # 设置图表属性
    ax.set_xlabel('Number of SNPs', fontsize=12, fontweight='bold', color='black')
    ax.set_ylabel('Running Time (seconds)', fontsize=12, fontweight='bold', color='black')
    ax.set_title('Loter Running Time vs SNP Count', 
                fontsize=16, fontweight='bold', pad=20, color='black')
    
    # 设置网格线为浅灰色
    ax.grid(True, linestyle='--', alpha=0.3, color='gray')
    
    # 设置X轴刻度 - 使用格式化函数避免重叠
    ax.xaxis.set_major_formatter(FuncFormatter(format_snp_tick))
    
    # 设置合理的X轴刻度位置
    # 找到数据中的关键点作为刻度
    key_snp_points = []
    
    # 确保包含最小值和最大值
    key_snp_points.append(df['snp_count'].min())
    
    # 添加一些关键数据点
    for snp in [50000, 100000, 200000, 300000, 400000, 500000, 600000, 700000, 796678]:
        if snp in df['snp_count'].values:
            key_snp_points.append(snp)
    
    # 确保刻度是排序的
    key_snp_points = sorted(set(key_snp_points))
    
    # 设置X轴刻度
    ax.set_xticks(key_snp_points)
    
    # 设置X轴范围，给标签留出空间
    x_min, x_max = df['snp_count'].min(), df['snp_count'].max()
    ax.set_xlim(max(0, x_min * 0.95), x_max * 1.02)
    
    # 设置Y轴刻度
    y_max = df['time_seconds'].max()
    y_ticks = np.linspace(0, y_max * 1.15, 10)
    ax.set_yticks(y_ticks)
    ax.set_yticklabels([f"{y:.0f}" for y in y_ticks], fontsize=10)
    
    # 添加性能框（左上角）
    perf_text = [
        "Performance Statistics",
        "-" * 25,
        f"Total SNPs: {max_snp:,}",
        f"Total Time: {total_time:.1f} s",
        f"Min Time: {min_time:.1f} s",
        f"Max Time: {max_time:.1f} s",
        f"Avg per 1k SNPs: {avg_time_per_1000:.4f} s"
    ]
    
    ax.text(0.05, 0.95, '\n'.join(perf_text),
            transform=ax.transAxes,
            fontsize=11,
            fontweight='bold',
            color='black',
            verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.95, 
                     edgecolor='blue', linewidth=2))
    
    # 调整布局，避免X轴标签重叠
    plt.tight_layout(rect=[0.05, 0.05, 0.95, 0.95])
    
    # 保存图表
    output_file = os.path.join(FIGURES_DIR, "loter_performance.png")
    plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"Chart saved to: {output_file}")
    
    return output_file

# 简化版本，只保留一个函数
if __name__ == "__main__":
    # 创建测试数据
    test_data = pd.DataFrame({
        'snp_count': [1000, 5000, 10000, 25000, 50000, 75000, 
                      100000, 150000, 200000, 250000, 300000, 
                      400000, 500000, 600000, 700000, 796678],
        'method': ['loter_smooth'] * 16,
        'time_seconds': [4.8, 23.5, 46.2, 115.8, 230.5, 345.2,
                         460.8, 690.5, 920.3, 1150.8, 1381.2,
                         1841.5, 2302.0, 2762.5, 3223.0, 8820.7]
    })
    
    # 确保results目录存在
    os.makedirs(FIGURES_DIR, exist_ok=True)
    test_file = os.path.join(FIGURES_DIR, "test_data.csv")
    test_data.to_csv(test_file, index=False)
    
    # 测试绘图
    plot_loter_performance(test_file)
