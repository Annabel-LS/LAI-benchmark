#!/bin/bash
# master.sh - 主菜单界面

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 清屏函数
clear_screen() {
    clear
}

# 显示标题
show_title() {
    clear_screen
    echo "╔══════════════════════════════════════════╗"
    echo "║          Loter Performance Test          ║"
    echo "╚══════════════════════════════════════════╝"
    echo ""
}

# 显示菜单
show_menu() {
    echo "Please select an option:"
    echo ""
    echo "  1. Full Test (16 SNP gradients)"
    echo "  2. Quick Test (12 SNP gradients)"
    echo "  3. Generate Report"
    echo "  4. Clean Test Data"
    echo "  5. Exit"
    echo ""
    echo -n "Enter your choice [1-5]: "
}

# 运行完整测试
run_full_test() {
    echo -e "${BLUE}Starting Full Test...${NC}"
    echo "Testing 16 SNP gradients (1000 to 796678)"
    echo ""
    python3 run_full_test.py
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Full Test completed successfully!${NC}"
    else
        echo -e "${RED}Full Test failed!${NC}"
    fi
    read -p "Press Enter to continue..."
}

# 运行快速测试
run_quick_test() {
    echo -e "${BLUE}Starting Quick Test...${NC}"
    echo "Testing 12 SNP gradients (1000 to 796678)"
    echo ""
    python3 run_quick_test.py
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Quick Test completed successfully!${NC}"
    else
        echo -e "${RED}Quick Test failed!${NC}"
    fi
    read -p "Press Enter to continue..."
}

# 生成报告
generate_report() {
    echo -e "${BLUE}Generating Report...${NC}"
    echo ""
    python3 generate_report.py
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Report generated successfully!${NC}"
        echo "Report saved in results/test_report.txt"
        echo "Chart saved in figures/simple_plot.png"
    else
        echo -e "${RED}Failed to generate report!${NC}"
    fi
    read -p "Press Enter to continue..."
}

# 清理数据
clean_data() {
    echo -e "${YELLOW}Cleaning Test Data...${NC}"
    echo ""
    python3 clean_data.py
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Data cleaned successfully!${NC}"
    else
        echo -e "${RED}Failed to clean data!${NC}"
    fi
    read -p "Press Enter to continue..."
}

# 主循环
while true; do
    show_title
    show_menu
    read choice
    
    case $choice in
        1)
            run_full_test
            ;;
        2)
            run_quick_test
            ;;
        3)
            generate_report
            ;;
        4)
            clean_data
            ;;
        5)
            echo -e "${GREEN}Exiting... Goodbye!${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid choice! Please enter a number between 1 and 5.${NC}"
            sleep 1
            ;;
    esac
done
