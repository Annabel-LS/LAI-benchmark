# config.py
import os

# 基础路径
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
FIGURES_DIR = os.path.join(BASE_DIR, "figures")

# 确保目录存在
for directory in [RESULTS_DIR, LOGS_DIR, FIGURES_DIR]:
    os.makedirs(directory, exist_ok=True)

# 数据文件路径（请根据实际情况修改）
DATA_FILES = {
    "H_ref1": "",
    "H_ref2": "", 
    "H_adm": ""
}

# 完整测试配置（修改后的梯度，无重复）
FULL_TEST_CONFIG = {
    "snp_counts": [1000, 5000, 10000, 25000, 50000, 75000, 
                   100000, 150000, 200000, 250000, 300000, 
                   400000, 500000, 600000, 700000, 796678],
    "repeats": 1,  # 每个测试点只测试一次
    "threads": #,
    "methods": ["loter_smooth"],
    "output_file": os.path.join(RESULTS_DIR, "full_test_results.csv")
}

# 快速测试配置（修改后的梯度，无重复）
QUICK_TEST_CONFIG = {
    "snp_counts": [1000, 5000, 10000, 50000, 100000, 200000, 
                   300000, 400000, 500000, 600000, 700000, 796678],
    "repeats": 1,  # 每个测试点只测试一次
    "threads": #,
    "methods": ["loter_smooth"],
    "output_file": os.path.join(RESULTS_DIR, "quick_test_results.csv")
}
