# 在 run_full_test.py 中添加以下函数（放在导入语句之后，主代码之前）
import time
import numpy as np
import pandas as pd
import os
from datetime import datetime

from config import DATA_FILES, FULL_TEST_CONFIG, RESULTS_DIR
import loter.locanc.local_ancestry as lc

def find_data_file(key, file_path):
    """
    智能查找数据文件，尝试多个可能的位置和文件名格式
    """
    possible_paths = [
        # 原始路径
        file_path,
        # 小写版本
        file_path.replace("_CHS.npy", "_chs.npy").replace("_YRI.npy", "_yri.npy").replace("_MEX.npy", "_mex.npy"),
        # 当前目录的final版本
        os.path.join(os.path.dirname(__file__), f"H_{key[-1].lower()}_final.npy"),
        # Loter数据目录的final版本
        file_path.replace(".npy", "_final.npy"),
        # 其他可能的位置
        f"/data/H_{key[-1].lower()}.npy",
        f"/data/H_{key[-1].upper()}.npy",
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"    Found {key} at: {path}")
            return path
    
    return file_path

def load_data_smart():
    """智能加载数据文件"""
    print("\n1. Loading data...")
    data = {}
    
    for key, file_path in DATA_FILES.items():
        print(f"\n   Searching for {key}...")
        
        # 查找文件
        actual_path = find_data_file(key, file_path)
        
        if os.path.exists(actual_path):
            try:
                data[key] = np.load(actual_path, allow_pickle=True)
                print(f"    Loaded {key}: {data[key].shape}")
            except Exception as e:
                print(f"    Error loading {key}: {e}")
                return None
        else:
            print(f"    ERROR: File not found for {key}")
            print(f"    Searched for: {os.path.basename(file_path)}")
            
            # 列出Loter数据目录下的文件
            data_dir = "/Loter-master/data"
            if os.path.exists(data_dir):
                print(f"    Available files in {data_dir}:")
                for f in os.listdir(data_dir):
                    if f.endswith('.npy'):
                        print(f"      - {f}")
            
            return None
    
    return data

# 然后修改主函数部分
print("=" * 50)
print("Running Full Test...")
print("=" * 50)

# 加载数据
data = load_data_smart()
if data is None:
    print("\nERROR: Failed to load data. Exiting.")
    exit(1)

max_snps = data["H_ref1"].shape[1]
print(f"\n   Maximum SNPs available: {max_snps}")
print(f"   Test gradient: {FULL_TEST_CONFIG['snp_counts']}")

# 运行测试
print("\n2. Running tests (each gradient tested once)...")
results = []

for snp_count in FULL_TEST_CONFIG["snp_counts"]:
    # 确保不超过最大SNP数
    actual_snp_count = min(snp_count, max_snps)
    
    print(f"\n   Testing with {actual_snp_count:,} SNPs...", end="")
    
    # 创建数据子集
    data_subset = {
        "H_ref1": data["H_ref1"][:, :actual_snp_count],
        "H_ref2": data["H_ref2"][:, :actual_snp_count],
        "H_adm": data["H_adm"][:, :actual_snp_count]
    }
    
    for method in FULL_TEST_CONFIG["methods"]:
        # 计时
        start_time = time.time()
        
        # 运行Loter
        try:
            if method == "loter_smooth":
                result = lc.loter_smooth(
                    l_H=[data_subset["H_ref1"], data_subset["H_ref2"]],

                    h_adm=data_subset["H_adm"],
                    num_threads=FULL_TEST_CONFIG["threads"]
                )
            elif method == "loter_local_ancestry":
                result = lc.loter_local_ancestry(
                    l_H=[data_subset["H_ref1"], data_subset["H_ref2"]],
                    h_adm=data_subset["H_adm"],
                    num_threads=FULL_TEST_CONFIG["threads"]
                )
            
            elapsed_time = time.time() - start_time
            
            print(f" Done ({elapsed_time:.2f} seconds)")
            
            # 保存结果
            results.append({
                "snp_count": actual_snp_count,
                "method": method,
                "time_seconds": elapsed_time,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "status": "success"
            })
            
        except Exception as e:
            print(f" Error: {e}")
            results.append({
                "snp_count": actual_snp_count,
                "method": method,
                "time_seconds": 0,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "status": f"failed: {str(e)[:100]}"
            })

# 保存结果到CSV
print("\n3. Saving results...")
df = pd.DataFrame(results)
df.to_csv(FULL_TEST_CONFIG["output_file"], index=False)
print(f"   Results saved to: {FULL_TEST_CONFIG['output_file']}")

# 显示摘要
print("\n4. Test Summary:")
print("   " + "=" * 40)
print(f"   Total tests: {len(results)}")
print(f"   Successful tests: {len([r for r in results if r['status'] == 'success'])}")
print(f"   Failed tests: {len([r for r in results if r['status'] != 'success'])}")
print(f"   Tested SNP counts: {len(FULL_TEST_CONFIG['snp_counts'])}")
print(f"   Methods: {FULL_TEST_CONFIG['methods']}")

# 显示测试时间统计
successful_results = [r for r in results if r['status'] == 'success']
if successful_results:
    total_time = sum(r['time_seconds'] for r in successful_results)
    avg_time = total_time / len(successful_results)
    print(f"   Total test time: {total_time:.2f} seconds")
    print(f"   Average time per test: {avg_time:.2f} seconds")

print("\n" + "=" * 50)
print("Full Test Completed!")
print("=" * 50)
