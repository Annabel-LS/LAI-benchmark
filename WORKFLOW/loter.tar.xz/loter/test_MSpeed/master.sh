#!/bin/bash
# Loter 速度测试主程序

# 进入脚本所在目录
cd "$(dirname "$0")"

# 检查 Python 环境
if ! command -v python3 &> /dev/null; then
    echo "错误：未找到 python3，请安装 Python 3 后再试。"
    exit 1
fi

# 定义颜色（可选）
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

show_menu() {
    echo -e "\n${GREEN}========================================${NC}"
    echo -e "${GREEN}        Loter 速度测试工具${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo "1. 完整测试（保存结果文件）"
    echo "2. 快速测试（保存结果文件）"
    echo "3. 模拟测试（不生成数据文件）"
    echo "4. 生成数据报告"
    echo "5. 清除数据"
    echo "0. 退出"
    echo -n "请选择 [0-5]: "
}

while true; do
    show_menu
    read choice
    case $choice in
        1)
            echo "执行完整测试..."
            python3 run_speed_test.py --type full --save
            ;;
        2)
            echo "执行快速测试..."
            python3 run_speed_test.py --type fast --save
            ;;
        3)
            echo "执行模拟测试（不保存结果文件）..."
            python3 run_speed_test.py --type sim --no-save
            ;;
        4)
            echo "生成数据报告..."
            python3 generate_report.py
            ;;
        5)
            echo "清除数据..."
            python3 clean_data.py
            ;;
        0)
            echo "退出程序。"
            exit 0
            ;;
        *)
            echo -e "${RED}无效选项，请重新输入。${NC}"
            ;;
    esac
done
