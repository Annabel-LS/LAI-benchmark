# clean_data.py
import os
import shutil
from config import RESULTS_DIR, LOGS_DIR, FIGURES_DIR

def clean_data():
    """
    清理测试数据
    """
    print("=" * 50)
    print("Cleaning Test Data")
    print("=" * 50)
    
    directories = [RESULTS_DIR, LOGS_DIR, FIGURES_DIR]
    files_removed = 0
    
    for directory in directories:
        if os.path.exists(directory):
            print(f"\nCleaning {directory}...")
            
            # 删除目录下的所有文件，但保留目录本身
            for filename in os.listdir(directory):
                file_path = os.path.join(directory, filename)
                try:
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                        print(f"  Removed: {filename}")
                        files_removed += 1
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                        print(f"  Removed directory: {filename}")
                        files_removed += 1
                except Exception as e:
                    print(f"  Error removing {filename}: {e}")
        else:
            print(f"\nDirectory does not exist: {directory}")
    
    print("\n" + "=" * 50)
    print(f"Cleanup complete! Removed {files_removed} files/directories.")
    print("=" * 50)

if __name__ == "__main__":
    clean_data()
