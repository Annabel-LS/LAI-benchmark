#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE_DIR, "speed_test_results")
LOGS_DIR = os.path.join(BASE_DIR, "logs")


# ==================== 配置 ====================
# 输入文件路径（请根据实际情况修改）
REF_FILES = [
    "CHS.npy",
    "YRI.npy",
    "CEU.npy",
    "GBR.npy",
    "JPT.npy",
    "TSI.npy",
]
ADM_FILE = "MEX.npy"

# SNP 梯度
FAST_GRADIENTS = [1000, 5000, 10000, 50000, 100000, 200000, 300000, 400000, 500000, 600000, 700000, 796678]
FULL_GRADIENTS = [1000, 5000, 10000, 25000, 50000, 75000, 100000, 150000, 200000, 250000, 300000, 400000, 500000, 600000, 700000, 796678]

# 输出目录和文件
OUTPUT_DIR = "speed_test_results"
TIME_LOG = os.path.join(OUTPUT_DIR, "times.txt")
REPORT_FILE = os.path.join(OUTPUT_DIR, "report.txt")
FIGURES_DIR = OUTPUT_DIR
PLOT_FILE = os.path.join(FIGURES_DIR, "loter_performance.png")

# Loter 参数
NUM_THREADS = #          # 可根据机器调整
USE_SMOOTH = True        # True: 使用 loter_smooth（带相位校正）; False: 仅 bagging
