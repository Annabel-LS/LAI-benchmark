#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import argparse
import numpy as np
import config

# 导入 Loter
try:
    import loter.locanc.local_ancestry as lc
except ImportError:
    print("错误：未找到 Loter 模块。请先安装 Loter（pip install loter）")
    sys.exit(1)

def load_data():
    """加载所有参考和混合文件到内存，并将参考文件转置为 (n_haplotypes, n_snps)"""
    print("正在加载参考文件...")
    ref_arrays = []
    for f in config.REF_FILES:
        if not os.path.exists(f):
            print(f"错误：文件不存在 {f}")
            sys.exit(1)
        arr = np.load(f)
        # 关键修改：转置参考文件，从 (n_snps, n_haplotypes) 变为 (n_haplotypes, n_snps)
        arr = arr.T
        print(f"  {os.path.basename(f)}: 转置后形状 {arr.shape}")
        ref_arrays.append(arr)
    print("正在加载混合文件...")
    if not os.path.exists(config.ADM_FILE):
        print(f"错误：文件不存在 {config.ADM_FILE}")
        sys.exit(1)
    adm_arr = np.load(config.ADM_FILE)
    print(f"  {os.path.basename(config.ADM_FILE)}: {adm_arr.shape}")
    return ref_arrays, adm_arr

def get_max_snps(ref_arrays, adm_arr):
    """获取所有文件的最小 SNP 数（即列数）"""
    min_snps = min(arr.shape[1] for arr in ref_arrays + [adm_arr])
    print(f"所有文件的最小 SNP 数为: {min_snps}")
    return min_snps

def run_loter(ref_arrays, adm_arr, n_snps, save_output=False):
    """
    对前 n_snps 个 SNP 运行 Loter 推断，返回耗时（秒）
    """
    # 切分子集（视图，不复制数据）
    ref_sub = [arr[:, :n_snps] for arr in ref_arrays]
    adm_sub = adm_arr[:, :n_snps]

    # 计时
    start = time.perf_counter()
    if config.USE_SMOOTH:
        result = lc.loter_smooth(l_H=ref_sub, h_adm=adm_sub, num_threads=config.NUM_THREADS)
    else:
        result = lc.loter_local_ancestry(l_H=ref_sub, h_adm=adm_sub, num_threads=config.NUM_THREADS)
    elapsed = time.perf_counter() - start

    # 可选保存结果
    if save_output:
        os.makedirs(config.OUTPUT_DIR, exist_ok=True)
        out_file = os.path.join(config.OUTPUT_DIR, f"result_{n_snps}.npy")
        np.save(out_file, result)
        print(f"结果已保存到 {out_file}")

    return elapsed

def record_time(n_snps, elapsed):
    """记录时间到文件"""
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    with open(config.TIME_LOG, "a") as f:
        f.write(f"{n_snps}\t{elapsed:.4f}\n")

def run_test(gradients, save_output):
    """执行测试循环"""
    print("\n加载数据...")
    ref_arrays, adm_arr = load_data()
    max_snps = get_max_snps(ref_arrays, adm_arr)

    # 过滤大于 max_snps 的梯度
    gradients = [g for g in gradients if g <= max_snps]
    if not gradients:
        print("错误：所有梯度均大于文件最大 SNP 数，无法测试。")
        return

    print(f"\n将测试以下 SNP 数量: {gradients}")
    print("开始测试...\n")

    for n_snps in gradients:
        print(f"正在测试 SNP 数量: {n_snps}")
        elapsed = run_loter(ref_arrays, adm_arr, n_snps, save_output)
        print(f"  耗时: {elapsed:.4f} 秒")
        record_time(n_snps, elapsed)

    print("\n测试完成！")

def main():
    parser = argparse.ArgumentParser(description="Loter 速度测试")
    parser.add_argument("--type", choices=["full", "fast", "sim"], required=True,
                        help="测试类型: full(完整梯度), fast(快速梯度), sim(模拟测试-不保存结果)")
    parser.add_argument("--save", action="store_true", help="是否保存结果文件")
    parser.add_argument("--no-save", dest="save", action="store_false", help="不保存结果文件")
    parser.set_defaults(save=True)  # 默认保存

    args = parser.parse_args()

    # 根据类型选择梯度
    if args.type == "full":
        gradients = config.FULL_GRADIENTS
    elif args.type == "fast":
        gradients = config.FAST_GRADIENTS
    elif args.type == "sim":
        gradients = config.FAST_GRADIENTS
        args.save = False   # 模拟测试强制不保存

    run_test(gradients, args.save)

if __name__ == "__main__":
    main()
