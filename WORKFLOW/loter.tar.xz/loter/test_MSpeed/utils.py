# utils.py
import os
import time
from datetime import datetime

def get_timestamp():
    """获取当前时间戳"""
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def format_time(seconds):
    """格式化时间显示"""
    if seconds < 60:
        return f"{seconds:.2f} seconds"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.2f} minutes"
    else:
        hours = seconds / 3600
        return f"{hours:.2f} hours"

def print_progress(current, total, message=""):
    """显示进度条"""
    progress = (current / total) * 100
    bar_length = 40
    filled_length = int(bar_length * current // total)
    bar = '█' * filled_length + '░' * (bar_length - filled_length)
    
    if message:
        print(f"\r{message} [{bar}] {progress:.1f}% ({current}/{total})", end="")
    else:
        print(f"\rProgress: [{bar}] {progress:.1f}% ({current}/{total})", end="")
    
    if current == total:
        print()
