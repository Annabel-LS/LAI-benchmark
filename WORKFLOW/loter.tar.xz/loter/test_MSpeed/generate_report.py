#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import datetime
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter
import config

def format_snp_tick(x, pos):
    """格式化SNP数量刻度标签"""
    if x >= 1_000_000:
        return f'{x/1_000_000:.1f}M'
    elif x >= 1_000:
        return f'{x/1_000:.0f}K'
    else:
        return f'{x:.0f}'

def plot_loter_performance(df, output_file):
    """
    根据DataFrame绘制性能曲线，保存为PNG文件
    """
    # 确保数据按SNP数量排序
    df = df.sort_values('snp_count').copy()
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(14, 8))
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    
    # 计算统计量
    total_time = df['time_seconds'].sum()
    avg_time = df['time_seconds'].mean()
    max_snp = df['snp_count'].max()
    min_time = df['time_seconds'].min()
    max_time = df['time_seconds'].max()
    df['time_per_1000'] = df['time_seconds'] / (df['snp_count'] / 1000.0)
    avg_time_per_1000 = df['time_per_1000'].mean()
    
    # 绘制折线图
    line, = ax.plot(df['snp_count'], df['time_seconds'], 
                   marker='o', linewidth=3, markersize=10,
                   color='blue', markerfacecolor='white', 
                   markeredgecolor='blue', markeredgewidth=2)
    
    # 为SNP数 >= 50000的数据点添加数值标签
    for _, row in df.iterrows():
        snp = row['snp_count']
        t = row['time_seconds']
        if snp >= 50000:
            # 根据位置调整偏移方向，避免标签重叠
            if snp in [50000, 75000, 150000, 250000, 350000, 450000]:
                y_offset = 20
            elif snp in [100000, 200000, 300000, 400000, 500000, 600000, 700000]:
                y_offset = -25
            elif snp == 796678:
                y_offset = -35
            else:
                y_offset = 20
            ax.annotate(f"{t:.1f}s", 
                       xy=(snp, t),
                       xytext=(0, y_offset), textcoords='offset points',
                       ha='center', fontsize=10, fontweight='bold',
                       color='black',
                       bbox=dict(boxstyle="round,pad=0.3", 
                                facecolor="white", 
                                edgecolor="lightgray", 
                                alpha=0.9))
    
    # 轴标签和标题
    ax.set_xlabel('Number of SNPs', fontsize=12, fontweight='bold', color='black')
    ax.set_ylabel('Running Time (seconds)', fontsize=12, fontweight='bold', color='black')
    ax.set_title('Loter Running Time vs SNP Count', 
                fontsize=16, fontweight='bold', pad=20, color='black')
    
    # 网格线
    ax.grid(True, linestyle='--', alpha=0.3, color='gray')
    
    # X轴刻度格式化
    ax.xaxis.set_major_formatter(FuncFormatter(format_snp_tick))
    # 选取关键点作为刻度
    key_points = []
    min_snp = df['snp_count'].min()
    max_snp = df['snp_count'].max()
    key_points.append(min_snp)
    for sp in [50000, 100000, 200000, 300000, 400000, 500000, 600000, 700000, 796678]:
        if sp in df['snp_count'].values:
            key_points.append(sp)
    key_points = sorted(set(key_points))
    ax.set_xticks(key_points)
    # 留一点边距
    ax.set_xlim(max(0, min_snp * 0.95), max_snp * 1.02)
    
    # Y轴刻度
    y_max = df['time_seconds'].max()
    y_ticks = np.linspace(0, y_max * 1.15, 10)
    ax.set_yticks(y_ticks)
    ax.set_yticklabels([f"{y:.0f}" for y in y_ticks], fontsize=10)
    
    # 添加性能统计框
    perf_text = [
        "Performance Statistics",
        "-" * 25,
        f"Total SNPs: {max_snp:,}",
        f"Total Time: {total_time:.1f} s",
        f"Min Time: {min_time:.1f} s",
        f"Max Time: {max_time:.1f} s",
        f"Avg per 1k SNPs: {avg_time_per_1000:.4f} s"
    ]
    ax.text(0.05, 0.95, '\n'.join(perf_text),
            transform=ax.transAxes,
            fontsize=11, fontweight='bold', color='black',
            verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.95,
                     edgecolor='blue', linewidth=2))
    
    # 调整布局
    plt.tight_layout(rect=[0.05, 0.05, 0.95, 0.95])
    
    # 保存图片
    plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    return output_file

def generate_text_report(df, report_file):
    """生成文本报告"""
    # 排序
    df = df.sort_values('snp_count').copy()
    
    total_time = df['time_seconds'].sum()
    avg_time = df['time_seconds'].mean()
    max_snp = df['snp_count'].max()
    min_time = df['time_seconds'].min()
    max_time = df['time_seconds'].max()
    df['time_per_1000'] = df['time_seconds'] / (df['snp_count'] / 1000.0)
    avg_time_per_1000 = df['time_per_1000'].mean()
    
    # 确定测试类型
    if len(df) == len(config.FULL_GRADIENTS):
        test_type = "Full Test"
    elif len(df) == len(config.FAST_GRADIENTS):
        test_type = "Fast Test"
    else:
        test_type = "Custom Test"
    
    method = "Loter with phase correction" if config.USE_SMOOTH else "Loter bagging only"
    
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write("LOTER PERFORMANCE TEST REPORT\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Report generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Test Type: {test_type}\n")
        f.write(f"Data File: {os.path.basename(config.TIME_LOG)}\n")
        f.write(f"Method: {method}\n")
        f.write(f"Threads: {config.NUM_THREADS}\n\n")
        
        f.write("TEST SUMMARY\n")
        f.write("-" * 40 + "\n")
        f.write(f"Total test runs: {len(df)}\n")
        f.write(f"Number of different SNP counts: {df['snp_count'].nunique()}\n\n")
        
        f.write("PERFORMANCE STATISTICS\n")
        f.write("-" * 40 + "\n")
        f.write(f"Maximum SNPs tested: {max_snp:,}\n")
        f.write(f"Total testing time: {total_time:.2f} seconds ({total_time/3600:.2f} hours)\n")
        f.write(f"Minimum time: {min_time:.2f} seconds\n")
        f.write(f"Maximum time: {max_time:.2f} seconds\n")
        f.write(f"Average time: {avg_time:.2f} seconds\n")
        f.write(f"Average per 1k SNPs: {avg_time_per_1000:.4f} seconds\n\n")
        
        f.write("DETAILED RESULTS\n")
        f.write("-" * 40 + "\n")
        for _, row in df.iterrows():
            t_per_1000 = row['time_seconds'] / (row['snp_count'] / 1000.0)
            f.write(f"  {row['snp_count']:,} SNPs: {row['time_seconds']:.2f} seconds (per 1k: {t_per_1000:.4f}s)\n")
        
        fastest_idx = df['time_seconds'].idxmin()
        slowest_idx = df['time_seconds'].idxmax()
        fastest = df.loc[fastest_idx]
        slowest = df.loc[slowest_idx]
        f.write(f"\nFastest configuration:\n")
        f.write(f"  {fastest['snp_count']:,} SNPs: {fastest['time_seconds']:.2f} seconds\n")
        f.write(f"\nSlowest configuration:\n")
        f.write(f"  {slowest['snp_count']:,} SNPs: {slowest['time_seconds']:.2f} seconds\n")
        if slowest['time_seconds'] > 0:
            f.write(f"\nSlowest/Fastest ratio: {slowest['time_seconds'] / fastest['time_seconds']:.2f}x\n")
        
        f.write("\n" + "=" * 60 + "\n")
        f.write("END OF REPORT\n")
        f.write("=" * 60 + "\n")
    
    print(f"文本报告已生成：{report_file}")

def generate_report():
    """主入口：读取时间数据，生成报告和图表"""
    if not os.path.exists(config.TIME_LOG):
        print(f"错误：未找到时间记录文件 {config.TIME_LOG}，请先运行测试。")
        return
    
    # 读取数据到DataFrame
    data = []
    with open(config.TIME_LOG, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) == 2:
                snp, t = parts
                data.append([int(snp), float(t)])
    if not data:
        print("错误：时间文件为空或格式不正确。")
        return
    
    df = pd.DataFrame(data, columns=['snp_count', 'time_seconds'])
    
    # 确保输出目录存在
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    
    # 生成文本报告
    generate_text_report(df, config.REPORT_FILE)
    
    # 生成图表
    print("\n生成性能图表...")
    plot_file = plot_loter_performance(df, config.PLOT_FILE)
    print(f"图表已保存：{plot_file}")
    
    # 控制台输出关键信息
    print("\n关键性能统计：")
    print("-" * 40)
    total_time = df['time_seconds'].sum()
    max_snp = df['snp_count'].max()
    avg_time_per_1000 = (df['time_seconds'] / (df['snp_count'] / 1000.0)).mean()
    print(f"  最大 SNP 数: {max_snp:,}")
    print(f"  总测试时间: {total_time:.2f} 秒 ({total_time/3600:.2f} 小时)")
    print(f"  平均每千 SNP 耗时: {avg_time_per_1000:.4f} 秒")
    print("\n" + "=" * 50)
    print("报告生成完成！")
    print("=" * 50)

if __name__ == "__main__":
    generate_report()
