#!/usr/bin/env python3
"""
适配 Loter v1.0.1：使用 loter.locanc.local_ancestry.loter_smooth
"""

import numpy as np
import logging
from pathlib import Path

BASE_DIR = Path("your_project")
ADMEX_DIR = BASE_DIR / "admex"
OUTPUT_DIR = BASE_DIR / "results_sparse"

CHS_FILE = BASE_DIR / "CHS.npy"
YRI_FILE = BASE_DIR / "YRI.npy"

DOWNSAMPLE_STEP = 200

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def downsample(x, step):
    return x[:, ::step]

def main():
    logger.info("🚀 开始 Loter 推断（使用 loter.locanc.local_ancestry）")
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    chs = np.load(CHS_FILE)
    yri = np.load(YRI_FILE)
    chs_s = downsample(chs, DOWNSAMPLE_STEP)
    yri_s = downsample(yri, DOWNSAMPLE_STEP)
    logger.info(f"参考面板: CHS={chs_s.shape}, YRI={yri_s.shape}")
    
    for gen in ['10', '40', '60', '80', '100']:
        adm_file = ADMEX_DIR / f"adm_{gen}.npy"
        if not adm_file.exists():
            continue
        
        adm = np.load(adm_file)
        adm_s = downsample(adm, DOWNSAMPLE_STEP)
        logger.info(f"🧬 处理 {gen} 代: {adm_s.shape}")
        
        try:
            # ✅ 正确导入方式（v1.0.1）
            from loter.locanc.local_ancestry import loter_smooth
            
            ref_list = [chs_s.T, yri_s.T]   # (n_snps, n_ref)
            adm_input = adm_s.T              # (n_snps, n_adm)
            
            res = loter_smooth(ref_list, adm_input, num_threads=4)
            # res: (n_snps, n_admixed_individuals)
            
            # 转为单倍型格式
            n_snps, n_samples = res.shape
            pred_haps = np.empty((n_snps, 2 * n_samples), dtype=np.int8)
            for i in range(n_samples):
                pred_haps[:, 2*i] = res[:, i]
                pred_haps[:, 2*i+1] = res[:, i]
            
            out_file = OUTPUT_DIR / f"loter_{gen}.npy"
            np.save(out_file, pred_haps)
            logger.info(f"✅ 保存: {out_file}")
            
        except Exception as e:
            logger.error(f"❌ {gen} 代失败: {e}")
            continue
    
    logger.info("🎉 完成！")

if __name__ == "__main__":
    main()
