#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import logging
from pathlib import Path

import numpy as np
from tqdm import tqdm

import loter.locanc.local_ancestry as lc


# ==================== 固定配置（根据你的路径）====================
BASE_DIR = Path("your_project")
ADMIXED_DIR = BASE_DIR / "admex"
REF1_PATH = BASE_DIR / "CHS.npy"
REF2_PATH = BASE_DIR / "YRI.npy"
OUTPUT_DIR = BASE_DIR / "results"
LOG_FILE = BASE_DIR / "loter_batch_run.log"
PID_FILE = BASE_DIR / "loter_batch.pid"

# 待分析的文件名列表（按代数）
ADMIXED_FILES = ["adm_40.npy", "adm_60.npy", "adm_80.npy", "adm_100.npy"]

NUM_THREADS = 16


# ==================== 工具函数 ====================
def setup_logger(log_file):
    logger = logging.getLogger("LoterBatch")
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()

    file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
    file_formatter = logging.Formatter(
        '[%(asctime)s] %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(file_formatter)

    console_handler = logging.StreamHandler(sys.stdout)
    console_formatter = logging.Formatter('%(levelname)s: %(message)s')
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


def is_already_running(pid_file):
    if not pid_file.exists():
        return False
    try:
        with open(pid_file, 'r') as f:
            old_pid = int(f.read().strip())
        os.kill(old_pid, 0)
        return True
    except (OSError, ValueError, ProcessLookupError):
        pid_file.unlink(missing_ok=True)
        return False


def write_pid(pid_file):
    with open(pid_file, 'w') as f:
        f.write(str(os.getpid()))


def cleanup_pid(pid_file):
    pid_file.unlink(missing_ok=True)


# ==================== 主流程 ====================
def main():
    logger = setup_logger(LOG_FILE)
    logger.info("=" * 70)
    logger.info("🚀 Starting Loter batch processing for admixture generations")

    if is_already_running(PID_FILE):
        logger.error("⚠️ Another instance is already running! Exiting.")
        sys.exit(1)

    write_pid(PID_FILE)
    logger.info(f"✅ PID {os.getpid()} written to {PID_FILE}")

    try:
        OUTPUT_DIR.mkdir(exist_ok=True, parents=True)
        logger.info(f"📁 Output directory: {OUTPUT_DIR}")

        if not REF1_PATH.exists():
            raise FileNotFoundError(f"Reference file not found: {REF1_PATH}")
        if not REF2_PATH.exists():
            raise FileNotFoundError(f"Reference file not found: {REF2_PATH}")

        admixed_paths = [ADMIXED_DIR / f for f in ADMIXED_FILES]
        for p in admixed_paths:
            if not p.exists():
                raise FileNotFoundError(f"Admixed file not found: {p}")

        # 加载参考面板 → ✅ 关键修改：加 .T 转置
        logger.info("📥 Loading reference panels...")
        H_ref1 = np.load(REF1_PATH).T  # ← 转置
        H_ref2 = np.load(REF2_PATH).T  # ← 转置
        l_H = [H_ref1, H_ref2]
        logger.info(f"   CHS shape: {H_ref1.shape}")  # 应显示 (308, 796678)
        logger.info(f"   YRI shape: {H_ref2.shape}")  # 应显示 (338, 796678)

        start_time = time.time()
        successful = 0
        failed = []

        logger.info("🧬 Starting ancestry inference...")
        for adm_file in tqdm(admixed_paths, desc="Generations", unit="file"):
            try:
                logger.info(f"Processing {adm_file.name}...")
                h_adm = np.load(adm_file).T  # ← 转置！混合样本也要转
                logger.info(f"   Admixed shape: {h_adm.shape}")  # 改成 INFO

                res = lc.loter_smooth(l_H=l_H, h_adm=h_adm, num_threads=NUM_THREADS)

                output_path = OUTPUT_DIR / f"{adm_file.stem}_ancestry.npy"
                np.save(output_path, res)
                logger.info(f"✅ Saved: {output_path.name}")
                successful += 1

            except Exception as e:
                error_msg = f"❌ Failed on {adm_file.name}: {e}"
                logger.error(error_msg)
                failed.append(adm_file.name)

        elapsed = time.time() - start_time
        logger.info("\n" + "=" * 70)
        logger.info(f"🎉 Batch completed in {elapsed:.2f} seconds")
        logger.info(f"✅ Successful: {successful} | ❌ Failed: {len(failed)}")
        if failed:
            logger.info(f"Failed files: {', '.join(failed)}")

    except Exception as e:
        logger.exception(f"💥 Unexpected error: {e}")
        sys.exit(1)

    finally:
        cleanup_pid(PID_FILE)
        logger.info("🧹 PID file cleaned up.")


if __name__ == "__main__":
    main()
