#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 SALAI-Net 性能测试报告（折线图）
用法：python generate_speed_report.py [结果文件路径]
"""

import os
import sys
import pandas as pd
import matplotlib.pyplot as plt

def generate_report(results_file):
    if not os.path.exists(results_file):
        print(f"错误：结果文件不存在 - {results_file}")
        return False
    
    # 读取数据
    df = pd.read_csv(results_file)
    df_success = df[df['status'] == 'success'].copy()
    if df_success.empty:
        print("没有成功的测试结果")
        return False
    
    # 按样本数排序
    df_success = df_success.sort_values('sample_size').reset_index(drop=True)
    
    # 创建图形
    plt.figure(figsize=(8, 6), dpi=600)
    plt.rcParams['font.family'] = 'Arial'
    
    # 绘制折线图
    plt.plot(df_success['sample_size'], df_success['time_seconds'],
             marker='o', linestyle='-', linewidth=2, markersize=8, color='#2E86AB')
    
    # 设置坐标轴标签和标题
    plt.xlabel('Number of Samples', fontsize=12, fontname='Arial')
    plt.ylabel('Runtime (seconds)', fontsize=12, fontname='Arial')
    plt.title('SALAI-Net Runtime vs Sample Size (9th Generation)', fontsize=14, fontname='Arial')
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # 获取Y轴范围用于动态偏移量
    y_min, y_max = plt.gca().get_ylim()
    y_range = y_max - y_min
    offset = y_range * 0.03  # 偏移量为Y轴范围的3%
    
    # 为每个节点添加标签，交替显示在上方或下方
    for idx, row in df_success.iterrows():
        if idx % 2 == 0:      # 偶数索引（第一个点，即20）显示在上方
            va = 'bottom'
            y_pos = row['time_seconds'] + offset
        else:                 # 奇数索引（第二个点，即60）显示在下方
            va = 'top'
            y_pos = row['time_seconds'] - offset
        
        plt.text(row['sample_size'], y_pos, f"{row['time_seconds']:.1f}s",
                 ha='center', va=va, fontsize=9, fontname='Arial')
    
    # 保存图像
    plot_file = os.path.join(os.path.dirname(results_file), "speed_vs_samples.png")
    plt.tight_layout()
    plt.savefig(plot_file, dpi=600)
    print(f"折线图已保存: {plot_file}")
    return True

if __name__ == "__main__":
    # 支持命令行参数传入结果文件路径
    if len(sys.argv) > 1:
        results_file = sys.argv[1]
    else:
        # 默认路径（与主程序保持一致）
        results_file = "speed_results.csv"
    generate_report(results_file)
