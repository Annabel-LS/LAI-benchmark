#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SALAI-Net测试报告生成脚本
生成运行时间与SNP数量关系图
"""

import os
import sys
import glob
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import argparse
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional

# 设置中文字体（如果需要）
matplotlib.rcParams['font.sans-serif'] = ['DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/report_generation.log')
    ]
)
logger = logging.getLogger(__name__)

def find_latest_results(results_dir: str) -> Optional[str]:
    """查找最新的结果文件"""
    csv_files = glob.glob(os.path.join(results_dir, "results_*.csv"))
    if not csv_files:
        logger.warning(f"未找到结果文件: {results_dir}")
        return None
    
    # 按修改时间排序
    csv_files.sort(key=os.path.getmtime, reverse=True)
    return csv_files[0]

def load_results(results_file: str) -> pd.DataFrame:
    """加载测试结果"""
    try:
        df = pd.read_csv(results_file)
        logger.info(f"加载结果文件: {results_file}")
        logger.info(f"数据形状: {df.shape}")
        
        # 显示列名
        logger.info(f"列名: {list(df.columns)}")
        
        # 显示成功/失败统计
        if 'Success' in df.columns:
            success_count = (df['Success'] == 'Yes').sum()
            logger.info(f"成功测试: {success_count}/{len(df)}")
        
        # 显示SNP范围
        if 'SNP_Count' in df.columns:
            logger.info(f"SNP范围: {df['SNP_Count'].min():,} - {df['SNP_Count'].max():,}")
        
        return df
    except Exception as e:
        logger.error(f"加载结果文件失败: {e}")
        raise

def create_performance_summary(df: pd.DataFrame) -> Dict:
    """创建性能摘要"""
    # 检查列名
    time_column = None
    for col in ['Run_Time_s', 'Avg_Time_s', 'Runtime_s', 'Time_s']:
        if col in df.columns:
            time_column = col
            break
    
    if time_column is None:
        logger.error("未找到时间列")
        # 尝试推断
        time_cols = [col for col in df.columns if 'time' in col.lower() or 'Time' in col]
        if time_cols:
            time_column = time_cols[0]
            logger.warning(f"推断时间列为: {time_column}")
        else:
            # 如果没有时间列，创建一个空的摘要
            return {
                'test_date': datetime.now().strftime("%Y-%m-%d"),
                'total_tests': len(df),
                'successful_tests': 0,
                'success_rate': 0,
                'platform': 'Unknown',
                'max_runtime': 0,
                'min_runtime': 0,
                'avg_runtime': 0,
                'median_runtime': 0
            }
    
    # 创建摘要
    summary = {
        'test_date': df['Test_Date'].iloc[0] if 'Test_Date' in df.columns else datetime.now().strftime("%Y-%m-%d"),
        'total_tests': len(df),
        'successful_tests': len(df[df['Success'] == 'Yes']) if 'Success' in df.columns else 0,
        'success_rate': len(df[df['Success'] == 'Yes']) / len(df) * 100 if 'Success' in df.columns and len(df) > 0 else 0,
        'platform': df['Platform'].iloc[0] if 'Platform' in df.columns else 'Unknown',
        'max_runtime': df[time_column].max() if time_column in df.columns else 0,
        'min_runtime': df[time_column].min() if time_column in df.columns else 0,
        'avg_runtime': df[time_column].mean() if time_column in df.columns else 0,
        'median_runtime': df[time_column].median() if time_column in df.columns else 0,
        'time_column': time_column  # 添加时间列名用于后续使用
    }
    
    return summary

def format_performance_box(summary: Dict) -> str:
    """格式化性能框文本"""
    lines = [
        "Performance Summary:",
        f"- Test Date: {summary['test_date']}",
        f"- Total Tests: {summary['total_tests']}",
        f"- Successful Tests: {summary['successful_tests']}",
        f"- Success Rate: {summary['success_rate']:.1f}%",
        f"- Platform: {summary['platform']}",
        f"- Max Runtime: {summary['max_runtime']:.2f}s",
        f"- Min Runtime: {summary['min_runtime']:.2f}s",
        f"- Avg Runtime: {summary['avg_runtime']:.2f}s",
        f"- Median Runtime: {summary['median_runtime']:.2f}s"
    ]
    
    # 检查是否有其他指标
    if 'max_memory_mb' in summary and summary['max_memory_mb'] > 0:
        lines.append(f"- Max Memory: {summary['max_memory_mb']:.1f} MB")
    
    if 'avg_cpu_percent' in summary and summary['avg_cpu_percent'] > 0:
        lines.append(f"- Avg CPU: {summary['avg_cpu_percent']:.1f}%")
    
    return '\n'.join(lines)

def create_runtime_vs_snp_plot(df: pd.DataFrame, output_path: str, 
                              summary_text: str, title: str = None):
    """创建运行时间与SNP数量关系图"""
    
    if title is None:
        title = "SALAI Runtime vs SNP Count Analysis for SALAI-Net"
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 确定时间列
    time_column = 'Run_Time_s'
    if time_column not in df.columns:
        # 尝试查找时间列
        time_cols = [col for col in df.columns if 'time' in col.lower() or 'Time' in col]
        if time_cols:
            time_column = time_cols[0]
            logger.info(f"使用时间列: {time_column}")
        else:
            logger.error("未找到时间列")
            return
    
    # 设置颜色
    colors = plt.cm.viridis(np.linspace(0.2, 0.8, len(df)))
    
    # 绘制折线图 - 只绘制成功的测试点
    if 'Success' in df.columns:
        successful_df = df[df['Success'] == 'Yes']
        if len(successful_df) > 0:
            ax.plot(successful_df['SNP_Count'], successful_df[time_column], 'o-', linewidth=2, 
                    markersize=8, color=colors[0], label='Runtime (Successful)')
            
            # 标记每个数据点
            for i, row in successful_df.iterrows():
                ax.annotate(f"{row[time_column]:.1f}s", 
                           (row['SNP_Count'], row[time_column]),
                           textcoords="offset points", 
                           xytext=(0,10), 
                           ha='center',
                           fontsize=9,
                           bbox=dict(boxstyle="round,pad=0.3", 
                                    facecolor="wheat", 
                                    alpha=0.7))
        
        # 绘制失败的测试点
        failed_df = df[df['Success'] == 'No']
        if len(failed_df) > 0:
            ax.scatter(failed_df['SNP_Count'], [0] * len(failed_df), 
                      marker='x', s=100, color='red', label='Failed Tests')
            # 标记失败点
            for i, row in failed_df.iterrows():
                ax.annotate(f"Failed\n({row['SNP_Count']:,})", 
                           (row['SNP_Count'], 0),
                           textcoords="offset points", 
                           xytext=(0,10), 
                           ha='center',
                           fontsize=8,
                           color='red')
    else:
        # 如果没有Success列，绘制所有点
        ax.plot(df['SNP_Count'], df[time_column], 'o-', linewidth=2, 
                markersize=8, color=colors[0], label='Runtime')
        
        # 标记每个数据点
        for i, row in df.iterrows():
            ax.annotate(f"{row[time_column]:.1f}s", 
                       (row['SNP_Count'], row[time_column]),
                       textcoords="offset points", 
                       xytext=(0,10), 
                       ha='center',
                       fontsize=9,
                       bbox=dict(boxstyle="round,pad=0.3", 
                                facecolor="wheat", 
                                alpha=0.7))
    
    # 设置对数刻度
    ax.set_xscale('log')
    ax.set_yscale('log')
    
    # 设置轴标签
    ax.set_xlabel('Number of SNPs (log scale)', fontsize=12)
    ax.set_ylabel('Execution Time (seconds, log scale)', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    
    # 获取实际的测试梯度值
    test_gradients = df['SNP_Count'].unique()
    
    # 设置x轴刻度为实际测试梯度值
    ax.set_xticks(test_gradients)
    
    # 创建自定义的刻度标签函数，将数值转换为K格式
    def format_snp_tick(x, pos):
        """格式化SNP刻度标签"""
        if x >= 1000000:
            return f'{x/1000000:.1f}M'
        elif x >= 1000:
            return f'{x/1000:.0f}K'
        else:
            return f'{x:.0f}'
    
    # 应用自定义刻度标签
    from matplotlib.ticker import FuncFormatter
    ax.xaxis.set_major_formatter(FuncFormatter(format_snp_tick))
    
    # 旋转x轴标签以避免重叠
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
    
    # 添加网格
    ax.grid(True, which='major', linestyle='-', alpha=0.6)
    ax.grid(True, which='minor', linestyle=':', alpha=0.3)
    
    # 添加性能框
    ax.text(0.02, 0.98, summary_text,
            transform=ax.transAxes,
            fontsize=9,
            verticalalignment='top',
            bbox=dict(boxstyle="round,pad=0.5",
                     facecolor="lightblue",
                     alpha=0.8))
    

    
    # 调整布局
    plt.tight_layout()
    
    # 保存图形
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    logger.info(f"图表已保存: {output_path}")

def create_additional_plots(df: pd.DataFrame, output_dir: str):
    """创建附加图表"""
    
    # 1. 成功率与SNP数量关系
    if 'Success' in df.columns:
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # 计算成功率
        df['Success_Num'] = df['Success'].apply(lambda x: 1 if x == 'Yes' else 0)
        
        ax.plot(df['SNP_Count'], df['Success_Num'], 's-', 
                color='green', linewidth=2, markersize=6)
        ax.set_xscale('log')
        ax.set_xlabel('Number of SNPs')
        ax.set_ylabel('Success (1=Yes, 0=No)')
        ax.set_title('Test Success vs SNP Count', fontsize=12, fontweight='bold')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'success_vs_snp.png'), dpi=300)
        plt.close()
    
    # 2. 线性刻度图表（非对数）
    time_column = 'Run_Time_s'
    if time_column not in df.columns:
        time_cols = [col for col in df.columns if 'time' in col.lower() or 'Time' in col]
        if time_cols:
            time_column = time_cols[0]
    
    if time_column in df.columns:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # 左侧：线性刻度
        ax1.plot(df['SNP_Count'], df[time_column], 'o-', linewidth=2, markersize=6)
        ax1.set_xlabel('Number of SNPs')
        ax1.set_ylabel('Execution Time (seconds)')
        ax1.set_title('Runtime vs SNP Count (Linear Scale)', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # 右侧：对数刻度
        ax2.plot(df['SNP_Count'], df[time_column], 'o-', linewidth=2, markersize=6)
        ax2.set_xscale('log')
        ax2.set_yscale('log')
        ax2.set_xlabel('Number of SNPs (log scale)')
        ax2.set_ylabel('Execution Time (seconds, log scale)')
        ax2.set_title('Runtime vs SNP Count (Log Scale)', fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'runtime_comparison.png'), dpi=300)
        plt.close()

def generate_text_report(df: pd.DataFrame, summary: Dict, output_path: str):
    """生成文本报告"""
    
    # 确定时间列
    time_column = summary.get('time_column', 'Run_Time_s')
    
    report_lines = [
        "=" * 60,
        "SALAI-Net SNP Runtime Benchmark Report",
        "=" * 60,
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Data Source: {len(df)} test points",
        "",
        "PERFORMANCE SUMMARY",
        "-" * 40,
        f"Test Date: {summary['test_date']}",
        f"Platform: {summary['platform']}",
        f"Total Tests: {summary['total_tests']}",
        f"Successful Tests: {summary['successful_tests']}",
        f"Success Rate: {summary['success_rate']:.1f}%",
        f"Maximum Runtime: {summary['max_runtime']:.2f} seconds",
        f"Minimum Runtime: {summary['min_runtime']:.2f} seconds",
        f"Average Runtime: {summary['avg_runtime']:.2f} seconds",
        f"Median Runtime: {summary['median_runtime']:.2f} seconds",
        "",
        "DETAILED RESULTS",
        "-" * 40,
    ]
    
    # 添加详细数据
    for _, row in df.iterrows():
        success = row['Success'] if 'Success' in row else 'Unknown'
        runtime = row[time_column] if time_column in row else 0.0
        
        report_lines.append(
            f"SNP={row['SNP_Count']:,}: "
            f"Time={runtime:.2f}s, "
            f"Success={success}"
        )
    
    # 分析趋势
    if len(df) >= 3 and time_column in df.columns:
        report_lines.extend([
            "",
            "TREND ANALYSIS",
            "-" * 40,
            f"As SNP count increases, runtime shows:",
        ])
        
        # 简单趋势分析
        try:
            from scipy import stats
            # 移除失败的点
            success_df = df[df['Success'] == 'Yes'] if 'Success' in df.columns else df
            
            if len(success_df) >= 3:
                x = np.log(success_df['SNP_Count'])
                y = np.log(success_df[time_column])
                slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
                
                report_lines.extend([
                    f"- Log-log slope: {slope:.3f} (R² = {r_value**2:.3f})",
                    f"- Time ~ SNP^{slope:.3f}",
                    f"- For 10× more SNPs, expect {10**slope:.2f}× more time"
                ])
        except ImportError:
            report_lines.append("- Note: Install scipy for trend analysis")
    
    report_lines.extend([
        "",
        "RECOMMENDATIONS",
        "-" * 40,
        "1. For datasets with < 10,000 SNPs, runtime is minimal (< 10 seconds)",
        "2. Consider using CPU mode for datasets with > 100,000 SNPs to avoid GPU memory issues",
        "3. Monitor memory usage for large SNP sets",
        "4. Optimal batch size for GPU: 32, for CPU: 8-16",
        "5. Consider splitting very large datasets (> 500,000 SNPs) into chunks",
        "",
        "=" * 60,
    ])
    
    # 写入文件
    with open(output_path, 'w') as f:
        f.write('\n'.join(report_lines))
    
    logger.info(f"文本报告已保存: {output_path}")

def generate_html_report(df: pd.DataFrame, summary: Dict, output_path: str, 
                        plot_path: str):
    """生成HTML报告"""
    
    # 确定时间列
    time_column = summary.get('time_column', 'Run_Time_s')
    
    # 创建HTML表格行
    table_rows = ""
    for _, row in df.iterrows():
        success = row['Success'] if 'Success' in row else 'Unknown'
        runtime = row[time_column] if time_column in row else 0.0
        
        # 根据成功状态设置颜色
        success_color = "green" if success == 'Yes' else "red" if success == 'No' else "gray"
        
        table_rows += f"""
        <tr>
            <td>{row['SNP_Count']:,}</td>
            <td>{runtime:.2f}</td>
            <td style="color: {success_color}; font-weight: bold;">{success}</td>
            <td>{row.get('Test_Date', '')}</td>
            <td>{row.get('Platform', '')}</td>
        </tr>
        """
    
    html_template = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>SALAI-Net SNP Runtime Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            h1, h2 {{ color: #2c3e50; }}
            .summary {{ background: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 30px; }}
            .data-table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            .data-table th, .data-table td {{ border: 1px solid #ddd; padding: 8px; text-align: center; }}
            .data-table th {{ background: #2c3e50; color: white; }}
            .data-table tr:nth-child(even) {{ background: #f2f2f2; }}
            .data-table tr:hover {{ background: #e8f4f8; }}
            .plot {{ text-align: center; margin: 30px 0; padding: 20px; background: white; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .plot img {{ max-width: 100%; height: auto; border: 1px solid #ddd; }}
            .success {{ color: green; }}
            .failure {{ color: red; }}
            .stat-box {{ display: flex; justify-content: space-between; margin: 20px 0; }}
            .stat-item {{ flex: 1; text-align: center; padding: 15px; background: #e8f4f8; margin: 0 5px; border-radius: 5px; }}
            .stat-value {{ font-size: 24px; font-weight: bold; color: #2c3e50; }}
            .stat-label {{ font-size: 14px; color: #7f8c8d; }}
        </style>
    </head>
    <body>
        <h1>SALAI-Net SNP Runtime Benchmark Report</h1>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        
        <div class="summary">
            <h2>Performance Summary</h2>
            
            <div class="stat-box">
                <div class="stat-item">
                    <div class="stat-value">{summary['total_tests']}</div>
                    <div class="stat-label">Total Tests</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" style="color: {'green' if summary['success_rate'] > 50 else 'orange'}">{summary['success_rate']:.1f}%</div>
                    <div class="stat-label">Success Rate</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{summary['avg_runtime']:.2f}s</div>
                    <div class="stat-label">Avg Runtime</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">{summary['platform']}</div>
                    <div class="stat-label">Platform</div>
                </div>
            </div>
            
            <p><strong>Test Date:</strong> {summary['test_date']}</p>
            <p><strong>Maximum Runtime:</strong> {summary['max_runtime']:.2f} seconds</p>
            <p><strong>Minimum Runtime:</strong> {summary['min_runtime']:.2f} seconds</p>
            <p><strong>Median Runtime:</strong> {summary['median_runtime']:.2f} seconds</p>
        </div>
        
        <div class="plot">
            <h2>Runtime vs SNP Count</h2>
            <img src="{os.path.basename(plot_path)}" alt="Runtime vs SNP Count">
            <p><em>Note: Both axes use logarithmic scale. Failed tests are marked with red X.</em></p>
        </div>
        
        <h2>Detailed Results</h2>
        <table class="data-table">
            <thead>
                <tr>
                    <th>SNP Count</th>
                    <th>Runtime (s)</th>
                    <th>Success</th>
                    <th>Test Date</th>
                    <th>Platform</th>
                </tr>
            </thead>
            <tbody>
                {table_rows}
            </tbody>
        </table>
        
        <h2>Key Findings</h2>
        <ul>
            <li>Runtime generally increases with SNP count, but the relationship is not strictly linear</li>
            <li>Memory constraints may limit performance for datasets with > 100,000 SNPs on GPU</li>
            <li>Optimal batch size varies with dataset size and available hardware</li>
            <li>Consider data preprocessing and filtering to reduce SNP count while maintaining accuracy</li>
        </ul>
        
        <h2>Recommendations</h2>
        <ol>
            <li>For small datasets (&lt; 10,000 SNPs), use default GPU settings</li>
            <li>For medium datasets (10,000-100,000 SNPs), monitor GPU memory usage</li>
            <li>For large datasets (&gt; 100,000 SNPs), consider using CPU mode</li>
            <li>Adjust batch size based on available memory: 32 for GPU, 8-16 for CPU</li>
            <li>For production use, test on representative data sizes before deployment</li>
        </ol>
        
        <footer style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd; color: #7f8c8d;">
            <p>Report generated by SALAI-Net Benchmark Tool</p>
            <p>Test conducted on {summary['platform']} platform</p>
        </footer>
    </body>
    </html>
    """
    
    with open(output_path, 'w') as f:
        f.write(html_template)
    
    logger.info(f"HTML报告已保存: {output_path}")

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='生成SALAI-Net测试报告')
    parser.add_argument('--results-dir', '-r', default='data/results',
                       help='结果文件目录')
    parser.add_argument('--output-dir', '-o', default='reports',
                       help='报告输出目录')
    parser.add_argument('--results-file', '-f', default=None,
                       help='指定结果文件路径（默认使用最新文件）')
    parser.add_argument('--date', '-d', default=None,
                       help='报告日期标识')
    parser.add_argument('--title', '-t', default=None,
                       help='图表标题')
    
    args = parser.parse_args()
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(os.path.join(args.output_dir, 'figures'), exist_ok=True)
    
    # 确定结果文件
    if args.results_file and os.path.exists(args.results_file):
        results_file = args.results_file
    else:
        results_file = find_latest_results(args.results_dir)
    
    if not results_file:
        logger.error("未找到结果文件")
        return 1
    
    # 加载数据
    try:
        df = load_results(results_file)
    except Exception as e:
        logger.error(f"无法加载结果: {e}")
        return 1
    
    # 创建性能摘要
    summary = create_performance_summary(df)
    summary_text = format_performance_box(summary)
    
    # 确定报告标识
    if args.date:
        report_id = args.date
    else:
        report_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 生成主图表
    plot_filename = f"runtime_vs_snp_{report_id}.png"
    plot_path = os.path.join(args.output_dir, 'figures', plot_filename)
    
    title = args.title if args.title else "Runtime vs SNP Count Analysis for SALAI-Net"
    create_runtime_vs_snp_plot(df, plot_path, summary_text, title)
    
    # 生成附加图表
    create_additional_plots(df, os.path.join(args.output_dir, 'figures'))
    
    # 生成文本报告
    text_report_path = os.path.join(args.output_dir, f"summary_{report_id}.txt")
    generate_text_report(df, summary, text_report_path)
    
    # 生成HTML报告
    html_report_path = os.path.join(args.output_dir, f"report_{report_id}.html")
    generate_html_report(df, summary, html_report_path, plot_path)
    
    # 生成CSV报告（原始数据）
    csv_report_path = os.path.join(args.output_dir, f"data_{report_id}.csv")
    df.to_csv(csv_report_path, index=False)
    
    # 输出总结
    logger.info("=" * 60)
    logger.info("报告生成完成!")
    logger.info(f"主图表: {plot_path}")
    logger.info(f"文本报告: {text_report_path}")
    logger.info(f"HTML报告: {html_report_path}")
    logger.info(f"数据文件: {csv_report_path}")
    logger.info("=" * 60)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
