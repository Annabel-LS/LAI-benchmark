#!/bin/bash

source $(dirname "$0")/functions.sh

echo "Generating performance report..."

# Check for time record files
TIMEFILES=(
    "$REPORTS_DIR/full_test_times.csv"
    "$REPORTS_DIR/quick_test_times.csv"
    "$REPORTS_DIR/simulate_test_times.csv"
    "$REPORTS_DIR/full_ref_test_times.csv"
    "$REPORTS_DIR/custom_test_times.csv"
)

REPORT_FILE=""
for timefile in "${TIMEFILES[@]}"; do
    if [ -f "$timefile" ] && [ -s "$timefile" ]; then
        REPORT_FILE="$timefile"
        echo "Found time record file: $REPORT_FILE"
        break
    fi
done

if [ -z "$REPORT_FILE" ]; then
    echo "Error: No time record files found"
    echo "Please run tests first"
    exit 1
fi

# Generate chart
echo "Generating performance chart..."
python3 "$BASE_DIR/plot_results.py" \
    --input "$REPORT_FILE" \
    --output "$REPORTS_DIR/performance_plot.png"

if [ $? -eq 0 ]; then
    echo "Chart generated: $REPORTS_DIR/performance_plot.png"
fi

# Generate text report
TEXT_REPORT="$REPORTS_DIR/performance_report.txt"
echo "Generating text report: $TEXT_REPORT"

# Get current date
REPORT_DATE=$(date "+%Y-%m-%d %H:%M:%S")

# Create report
cat > "$TEXT_REPORT" << EOF
========================================
aMAP Performance Test Report
========================================
Report Date: $REPORT_DATE
Data File: $(basename "$REPORT_FILE")

Test Configuration:
- Test mode: Sample SNP variation only
- Reference populations: Full datasets
- Window sizes: 20 to 200 SNPs, step 10

Performance Results:
========================================
EOF

# Add data table
echo "SNP Count  |  Formatted  |  Time (s)" >> "$TEXT_REPORT"
echo "-----------|-------------|-----------" >> "$TEXT_REPORT"

# Process each data point
tail -n +2 "$REPORT_FILE" | while IFS=',' read snp time; do
    # Format SNP count
    if [ $snp -ge 1000 ]; then
        if [ $((snp % 1000)) -eq 0 ]; then
            formatted=$(echo "scale=0; $snp/1000" | bc)
            formatted="${formatted}K"
        else
            formatted=$(echo "scale=1; $snp/1000" | bc)
            formatted="${formatted}K"
        fi
    else
        formatted=$snp
    fi
    
    printf "%-10d | %-11s | %8.2f\n" "$snp" "$formatted" "$time" >> "$TEXT_REPORT"
done

# Calculate and add statistics
echo "" >> "$TEXT_REPORT"
echo "Performance Statistics:" >> "$TEXT_REPORT"
echo "-----------------------" >> "$TEXT_REPORT"

awk -F',' '
BEGIN {
    count = 0
    sum = 0
    min_val = 0
    max_val = 0
}
NR>1 {
    count++
    time = $2
    sum += time
    
    if (NR == 2) {
        min_val = time
        max_val = time
        min_snp = $1
        max_snp = $1
    }
    
    if (time < min_val) {
        min_val = time
        min_snp = $1
    }
    
    if (time > max_val) {
        max_val = time
        max_snp = $1
    }
}
END {
    if (count > 0) {
        avg = sum / count
        
        # Format SNP counts
        min_formatted = (min_snp >= 1000) ? sprintf("%.0fK", min_snp/1000) : min_snp
        max_formatted = (max_snp >= 1000) ? sprintf("%.0fK", max_snp/1000) : max_snp
        
        printf "Test Cases:           %d\n", count
        printf "Total Execution Time: %.2f seconds\n", sum
        printf "Average Time:         %.2f seconds\n", avg
        printf "Minimum Time:         %.2f seconds (%s SNPs)\n", min_val, min_formatted
        printf "Maximum Time:         %.2f seconds (%s SNPs)\n", max_val, max_formatted
        
        # Calculate time per 1000 SNPs ratio
        if (count > 1) {
            # Get first and last values for trend calculation
            # Need to re-read file or store array
        }
    }
}' "$REPORT_FILE" >> "$TEXT_REPORT"

# Calculate time per SNP ratio
echo "" >> "$TEXT_REPORT"
echo "Time per 1000 SNPs:" >> "$TEXT_REPORT"
echo "-------------------" >> "$TEXT_REPORT"

# Calculate time per 1000 SNPs for each data point
tail -n +2 "$REPORTS_DIR/full_test_times.csv" | while IFS=',' read snp time; do
    time_per_1000=$(echo "scale=4; $time * 1000 / $snp" | bc)
    if [ $snp -ge 1000 ]; then
        formatted=$(echo "scale=0; $snp/1000" | bc)
        formatted="${formatted}K"
    else
        formatted=$snp
    fi
    printf "%-8s: %.4f seconds per 1000 SNPs\n" "$formatted" "$time_per_1000" >> "$TEXT_REPORT"
done

# Add summary
echo "" >> "$TEXT_REPORT"
echo "Summary:" >> "$TEXT_REPORT"
echo "-------" >> "$TEXT_REPORT"
echo "This report shows how aMAP execution time scales with increasing SNP count" >> "$TEXT_REPORT"
echo "in the sample file while keeping reference populations constant." >> "$TEXT_REPORT"
echo "" >> "$TEXT_REPORT"
echo "The performance chart is saved as: performance_plot.png" >> "$TEXT_REPORT"
echo "Raw data is available in: $(basename "$REPORT_FILE")" >> "$TEXT_REPORT"

# Display report summary
echo ""
echo "========================================"
echo "Performance Report Generated"
echo "========================================"
echo "Chart:    $REPORTS_DIR/performance_plot.png"
echo "Report:   $TEXT_REPORT"
echo "Data:     $REPORT_FILE"
echo ""
echo "Report preview:"
echo "--------------"
head -30 "$TEXT_REPORT"
