#!/bin/bash

source $(dirname "$0")/functions.sh

echo "开始模拟测试..."
create_directories

# 创建模拟时间记录文件
TIMEFILE="$REPORTS_DIR/simulate_test_times.csv"
echo "SNP数量,运行时间(秒)" > "$TIMEFILE"

echo "模拟测试：不生成实际数据文件"
echo "使用梯度: ${FULL_GRADIENTS[*]}"
echo ""

for snp_count in "${FULL_GRADIENTS[@]}"; do
    echo "模拟测试 SNP数量: $snp_count"
    
    # 模拟运行时间（基于SNP数量的函数）
    # 这里使用一个简单的模拟公式：时间 = SNP数量 * 0.001 + 随机波动
    BASE_TIME=$(echo "$snp_count * 0.001" | bc -l)
    RANDOM_FACTOR=$(echo "scale=2; $RANDOM % 100 / 100.0" | bc -l)
    SIM_TIME=$(echo "$BASE_TIME * (0.8 + 0.4 * $RANDOM_FACTOR)" | bc -l)
    
    # 确保时间至少有1秒
    if (( $(echo "$SIM_TIME < 1" | bc -l) )); then
        SIM_TIME="1.0"
    fi
    
    # 记录模拟时间
    echo "$snp_count,$SIM_TIME" >> "$TIMEFILE"
    
    echo "  模拟运行时间: $SIM_TIME 秒"
    sleep 0.5  # 稍微延迟，让用户看到进度
done

echo ""
echo "模拟测试完成！"
echo "模拟时间记录保存在: $TIMEFILE"
echo ""
echo "注意：这是模拟测试，没有实际运行 aMAP 或生成数据文件"
