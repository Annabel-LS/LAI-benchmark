#!/bin/bash

# 主菜单脚本
CURRENT_DIR=$(dirname "$(readlink -f "$0")")
source $CURRENT_DIR/functions.sh

show_menu() {
    clear
    echo "========================================"
    echo "    aMAP 性能测试平台"
    echo "========================================"
    echo "1. 完成测试（完整梯度）"
    echo "2. 快速测试（快速梯度）"
    echo "3. 模拟测试（不生成数据文件）"
    echo "4. 自定义梯度测试"
    echo "5. 生成数据报告"
    echo "6. 查看现有的报告"
    echo "7. 清除数据"
    echo "8. Exit"
    echo "========================================"
    echo -n "请选择操作（1-8）: "
}

while true; do
    show_menu
    read choice
    
    case $choice in
        1)
            echo "开始完整测试..."
            bash $CURRENT_DIR/full_test.sh
            ;;
        2)
            echo "开始快速测试..."
            bash $CURRENT_DIR/quick_test.sh
            ;;
        3)
            echo "开始模拟测试..."
            bash $CURRENT_DIR/simulate_test.sh
            ;;
        4)
             echo "自定义测试"
            echo -n "Enter test gradients (space separated): "
            read -a custom_gradients
            if [ ${#custom_gradients[@]} -gt 0 ]; then
                bash $CURRENT_DIR/test_with_full_refs.sh "${custom_gradients[@]}"
            else
                echo "No valid gradients entered"
            fi
            ;;
        5)
             echo "生成数据报告..."
            bash $CURRENT_DIR/generate_report.sh
            ;;
        6)
            echo "查看现有报告..."
            bash $CURRENT_DIR/summarize_results.sh
            ;;
        7)
             echo "清除测试数据..."
            bash $CURRENT_DIR/cleanup.sh
            ;;
        8)
            echo "退出程序"
            exit 0
            ;;
        *)
            echo "无效选择，请重新输入"
            sleep 2
            ;;
    esac
    
    echo "按任意键返回主菜单..."
    read -n 1
done
