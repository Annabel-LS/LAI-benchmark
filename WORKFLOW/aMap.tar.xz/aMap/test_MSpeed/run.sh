#!/bin/bash
# 文件名: benchmark_amap.sh
# 用途: 运行AMAP软件并记录运行时间

# 设置工作目录和AMAP jar路径（请根据实际情况修改）
WORK_DIR="your_project"
AMAP_JAR="$WORK_DIR/amap.jar"
RESULT_FILE="$WORK_DIR/runtime_results.csv"

cd "$WORK_DIR" || { echo "无法进入工作目录 $WORK_DIR"; exit 1; }

# 检查AMAP jar是否存在
if [ ! -f "$AMAP_JAR" ]; then
    echo "错误: 找不到 $AMAP_JAR"
    exit 1
fi

# 初始化结果文件，若不存在则写入表头
if [ ! -f "$RESULT_FILE" ]; then
    echo "config_file,reference_count,start_time,end_time,duration_seconds" > "$RESULT_FILE"
fi

# 获取配置文件列表（请根据实际命名模式修改）
# 假设配置文件命名为 config_数字.xml，如 config_40.xml, config_60.xml ...
# 若命名不同，请调整下面的通配符
config_files=$(ls config_*.xml 2>/dev/null)

if [ -z "$config_files" ]; then
    echo "错误: 没有找到配置文件 (config_*.xml)"
    exit 1
fi

# 循环处理每个配置文件
for config in $config_files; do
    echo "========================================"
    echo "开始处理配置文件: $config"
    
    # 从配置文件名提取参考样本数（假设文件名为 config_数字.xml）
    ref_count=$(echo "$config" | sed -n 's/config_\([0-9]\+\)\.xml/\1/p')
    if [ -z "$ref_count" ]; then
        ref_count="unknown"   # 若提取失败，标记为unknown
    fi
    
    # 记录开始时间
    start_time=$(date +"%Y-%m-%d %H:%M:%S")
    start_seconds=$(date +%s)
    
    # 运行AMAP，将输出重定向到日志文件（可选）
    log_file="amap_${ref_count}.log"
    echo "运行命令: java -jar $AMAP_JAR $config > $log_file 2>&1"
    java -jar "$AMAP_JAR" "$config" > "$log_file" 2>&1
    
    # 记录结束时间
    end_time=$(date +"%Y-%m-%d %H:%M:%S")
    end_seconds=$(date +%s)
    duration=$((end_seconds - start_seconds))
    
    # 将结果写入CSV
    echo "$config,$ref_count,$start_time,$end_time,$duration" >> "$RESULT_FILE"
    
    echo "完成: $config, 耗时 ${duration} 秒"
    echo "----------------------------------------"
done

echo "所有任务完成。运行时间已记录到 $RESULT_FILE"
