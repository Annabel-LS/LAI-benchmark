#!/bin/bash

source $(dirname "$0")/functions.sh

echo "清除测试数据..."
echo "这将删除以下目录:"
echo "  - $TEST_CONFIGS_DIR"
echo "  - $TEST_RESULTS_DIR"
echo "  - $REPORTS_DIR"
echo ""
read -p "确认要删除吗？(y/N): " confirm

if [[ $confirm == "y" || $confirm == "Y" ]]; then
    rm -rf "$TEST_CONFIGS_DIR"
    rm -rf "$TEST_RESULTS_DIR"
    rm -rf "$REPORTS_DIR"
    
    # 重新创建空目录
    create_directories
    
    echo "测试数据已清除"
else
    echo "操作已取消"
fi
