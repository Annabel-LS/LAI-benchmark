#!/usr/bin/env python3
import argparse
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

def format_snp_count(snp_count):
    """Format SNP count in K units"""
    if snp_count >= 1000:
        if snp_count % 1000 == 0:
            return f"{snp_count/1000:.0f}K"
        else:
            return f"{snp_count/1000:.1f}K"
    return str(snp_count)

def create_simple_performance_plot(input_file, output_file):
    """Create simple performance plot with English labels"""
    # Read data
    df = pd.read_csv(input_file)
    
    # Create figure with appropriate size
    plt.figure(figsize=(12, 7))
    
    # Prepare x-axis labels (formatted SNP counts)
    x_labels = [format_snp_count(x) for x in df['SNP数量']]
    x_positions = np.arange(len(x_labels))
    
    # Plot line with markers
    plt.plot(x_positions, df['运行时间(秒)'], 
             marker='o', linestyle='-', linewidth=2, markersize=8,
             color='steelblue')
    
    # Add time labels above each point
    for i, (x, y) in enumerate(zip(x_positions, df['运行时间(秒)'])):
        plt.text(x, y + max(df['运行时间(秒)']) * 0.02,  # Position above point
                f'{y:.1f}s', 
                ha='center', va='bottom',
                fontsize=9, fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.2', 
                         facecolor='white', 
                         edgecolor='gray', 
                         alpha=0.8))
    
    # Set axis labels
    plt.xlabel('Number of SNPs', fontsize=12, fontweight='bold')
    plt.ylabel('Execution Time (seconds)', fontsize=12, fontweight='bold')
    plt.title('aMAP Performance: Execution Time vs Number of SNPs', 
              fontsize=14, fontweight='bold')
    
    # Set x-ticks
    plt.xticks(x_positions, x_labels, rotation=45, ha='right')
    plt.grid(True, alpha=0.3, linestyle='--')
    
    # Calculate statistics
    total_tests = len(df)
    min_time = df['运行时间(秒)'].min()
    max_time = df['运行时间(秒)'].max()
    avg_time = df['运行时间(秒)'].mean()
    total_time = df['运行时间(秒)'].sum()
    
    # Add performance stats box
    stats_text = f"""Performance Statistics:
Test Cases: {total_tests}
Total Time: {total_time:.1f} s
Min Time: {min_time:.1f} s
Max Time: {max_time:.1f} s
Avg Time: {avg_time:.1f} s"""
    
    plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes,
             fontsize=10, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8),
             fontfamily='monospace')
    
    # Adjust y-limit for label space
    plt.ylim(0, max(df['运行时间(秒)']) * 1.15)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save figure
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"Chart saved to: {output_file}")
    
    # Show plot
    plt.show()

def main():
    parser = argparse.ArgumentParser(description='Generate performance chart')
    parser.add_argument('--input', required=True, help='Input CSV file path')
    parser.add_argument('--output', required=True, help='Output image file path')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input):
        print(f"Error: Input file does not exist: {args.input}")
        return 1
    
    create_simple_performance_plot(args.input, args.output)
    return 0

if __name__ == '__main__':
    main()
