#!/bin/bash

# 全局变量定义
BASE_DIR=$(dirname "$(readlink -f "$0")")
DATA_DIR="$BASE_DIR/data"
TEST_CONFIGS_DIR="$BASE_DIR/test_configs"
TEST_RESULTS_DIR="$BASE_DIR/test_results"
REPORTS_DIR="$BASE_DIR/reports"
AMAP_JAR="$BASE_DIR/../amap.jar"  # 假设amap.jar在上级目录

# 梯度定义
FULL_GRADIENTS=(1000 5000 10000 25000 50000 75000 100000 150000 200000 250000 300000 400000 500000 600000 700000 796678)
QUICK_GRADIENTS=(1000 5000 10000 50000 100000 200000 300000 400000 500000 600000 700000 796678)

# 创建必要的目录
create_directories() {
    mkdir -p "$TEST_CONFIGS_DIR"
    mkdir -p "$TEST_RESULTS_DIR"
    mkdir -p "$REPORTS_DIR"
    mkdir -p "$DATA_DIR"
}

# 检查数据文件是否存在
check_data_files() {
    local missing_files=()
    
    [ ! -f "$DATA_DIR/YRI.phased" ] && missing_files+=("YRI.phased")
    [ ! -f "$DATA_DIR/CHS.phased" ] && missing_files+=("CHS.phased")
    [ ! -f "$DATA_DIR/sample.phased" ] && missing_files+=("sample.phased")
    [ ! -f "$DATA_DIR/CEU.phased" ] && missing_files+=("CEU.phased")
    [ ! -f "$DATA_DIR/JPT.phased" ] && missing_files+=("JPT.phased")
    [ ! -f "$DATA_DIR/TSI.phased" ] && missing_files+=("TSI.phased")
    
    if [ ${#missing_files[@]} -gt 0 ]; then
        echo "错误：以下数据文件缺失："
        for file in "${missing_files[@]}"; do
            echo "  - $file"
        done
        echo "请将文件放入 $DATA_DIR 目录"
        return 1
    fi
    return 0
}

# 检查aMAP软件是否存在
check_amap() {
    if [ ! -f "$AMAP_JAR" ]; then
        echo "错误：未找到 amap.jar"
        echo "请确保 amap.jar 存在于: $AMAP_JAR"
        return 1
    fi
    return 0
}

# 获取文件行数（排除标题行）
get_snp_count() {
    local file="$1"
    if [ -f "$file" ]; then
        # 假设第一行是标题，计算实际SNP数量
        echo $(( $(wc -l < "$file") - 1 ))
    else
        echo "0"
    fi
}

# 生成aMAP配置文件
generate_config() {
    local snp_count="$1"
    local config_file="$2"
    local sample_file="$3"
    local yri_file="$4"
    local chs_file="$5"
    local ceu_file="$6"
    local gbr_file="$7"
    local jpt_file="$8"
    local tsi_file="$9"
    local output_dir="${10}" 
    
    cat > "$config_file" << EOF
<?xml version="1.0" ?>
<case>
    <positionCount>$snp_count</positionCount>
    <populations>
        <population id="sample">
            <type>sample</type>
            <ordinal>0</ordinal>
            <fileName>$sample_file</fileName>
        </population>
        <population id="yri">
            <type>reference</type>
            <ordinal>2</ordinal>
            <fileName>$yri_file</fileName><!--参考群体2-->
        </population>
        <population id="chs">
            <type>reference</type>
            <ordinal>1</ordinal>
            <fileName>$chs_file</fileName><!--参考群体1-->
        </population>
        <population id="ceu">
	<type>reference</type><!--参考群体3-->
	<ordinal>3</ordinal>
	<fileName>$ceu_file</fileName>
	</population>
	<population id="gbr">
	<type>reference</type><!--参考群体4-->
	<ordinal>4</ordinal>
	<fileName>$gbr_file</fileName>
	</population>
	<population id="jpt">
	<type>reference</type><!--参考群体5-->
	<ordinal>5</ordinal>
	<fileName>$jpt_file</fileName>
	</population>
	<population id="tsi">
	<type>reference</type><!--参考群体6-->
	<ordinal>6</ordinal>
	<fileName>$tsi_file</fileName>
	</population>
    </populations>
    <outputDir>$output_dir</outputDir>
    <minWinSize>20</minWinSize>
    <winStep>10</winStep>
    <maxWinSize>200</maxWinSize>
</case>
EOF
}
