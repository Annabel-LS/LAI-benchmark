#!/bin/bash

source $(dirname "$0")/functions.sh

echo "Creating data summary..."

# Find all CSV result files
echo "Available result files:"
echo "-----------------------"
find "$REPORTS_DIR" -name "*.csv" -type f | while read file; do
    echo "- $(basename "$file")"
done

# Create combined summary
SUMMARY_FILE="$REPORTS_DIR/combined_summary.csv"
echo "TestName,MinSNPs,MaxSNPs,TestCount,TotalTime,AvgTime" > "$SUMMARY_FILE"

for csv_file in "$REPORTS_DIR"/*.csv; do
    if [ -f "$csv_file" ] && [ "$(basename "$csv_file")" != "combined_summary.csv" ]; then
        test_name=$(basename "$csv_file" .csv)
        
        # Extract statistics using awk
        stats=$(awk -F',' '
        NR>1 {
            count++
            sum+=$2
            snps[count]=$1
            times[count]=$2
            if($2<min_time || NR==2) min_time=$2
            if($2>max_time || NR==2) max_time=$2
            if($1<min_snp || NR==2) min_snp=$1
            if($1>max_snp || NR==2) max_snp=$1
        }
        END {
            if(count>0) {
                avg=sum/count
                printf("%s,%d,%d,%d,%.2f,%.2f", test_name, min_snp, max_snp, count, sum, avg)
            }
        }' test_name="$test_name" "$csv_file")
        
        if [ ! -z "$stats" ]; then
            echo "$stats" >> "$SUMMARY_FILE"
        fi
    fi
done

echo ""
echo "Combined summary saved to: $SUMMARY_FILE"
echo ""
echo "Summary table:"
echo "--------------"
column -t -s ',' "$SUMMARY_FILE"
