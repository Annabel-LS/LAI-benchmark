#!/bin/bash

CONFIG_FILE="$1"
AMAP_JAR="$(dirname "$0")/../amap.jar"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "错误：配置文件不存在: $CONFIG_FILE"
    exit 1
fi

if [ ! -f "$AMAP_JAR" ]; then
    echo "错误：未找到 amap.jar"
    exit 1
fi

echo "使用配置文件: $CONFIG_FILE"
java -jar "$AMAP_JAR" "$CONFIG_FILE"

if [ $? -eq 0 ]; then
    echo "aMAP 运行成功"
else
    echo "aMAP 运行失败"
    exit 1
fi
