#!/bin/bash

source $(dirname "$0")/functions.sh

echo "开始快速测试..."
create_directories

# 检查必要文件
if ! check_data_files || ! check_amap; then
    exit 1
fi

echo "使用梯度: ${QUICK_GRADIENTS[*]}"
echo ""

# 创建时间记录文件
TIMEFILE="$REPORTS_DIR/quick_test_times.csv"
echo "SNP数量,运行时间(秒)" > "$TIMEFILE"

for snp_count in "${QUICK_GRADIENTS[@]}"; do
    echo "========================================"
    echo "测试 SNP数量: $snp_count"
    echo "========================================"
    
    # 为每个梯度创建独立的测试目录
    TEST_DIR="$TEST_RESULTS_DIR/snp_$snp_count"
    mkdir -p "$TEST_DIR"
    
    # 截取指定数量的SNP
    echo "截取数据文件..."
    python3 "$BASE_DIR/extract_snps.py" \
        --sample "$DATA_DIR/sample.phased" \
        --yri "$DATA_DIR/YRI.phased" \
        --chs "$DATA_DIR/CHS.phased" \
        --output-dir "$TEST_DIR" \
        --count "$snp_count"
    
    if [ $? -ne 0 ]; then
        echo "截取数据失败，跳过梯度 $snp_count"
        continue
    fi
    
    # 生成配置文件
    CONFIG_FILE="$TEST_CONFIGS_DIR/config_$snp_count.xml"
    generate_config \
        "$snp_count" \
        "$CONFIG_FILE" \
        "$TEST_DIR/sample_subset.phased" \
        "$TEST_DIR/yri_subset.phased" \
        "$TEST_DIR/chs_subset.phased" \
        "$TEST_DIR/output"
    
    # 运行测试并计时
    echo "运行 aMAP..."
    START_TIME=$(date +%s.%N)
    
    bash "$BASE_DIR/run_amap.sh" "$CONFIG_FILE"
    
    END_TIME=$(date +%s.%N)
    RUNTIME=$(echo "$END_TIME - $START_TIME" | bc)
    
    # 记录时间
    echo "$snp_count,$RUNTIME" >> "$TIMEFILE"
    echo "完成！运行时间: $RUNTIME 秒"
    echo ""
done

echo "快速测试完成！"
echo "时间记录保存在: $TIMEFILE"
