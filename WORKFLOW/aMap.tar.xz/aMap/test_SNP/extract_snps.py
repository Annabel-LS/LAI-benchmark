#!/usr/bin/env python3
import argparse
import os
import sys

def extract_snps(input_file, output_file, count):
    """截取指定数量的SNP"""
    try:
        with open(input_file, 'r') as f_in, open(output_file, 'w') as f_out:
            # 复制标题行
            header = f_in.readline()
            f_out.write(header)
            
            # 截取指定数量的SNP行
            for i in range(count):
                line = f_in.readline()
                if not line:
                    break
                f_out.write(line)
        
        print(f"已从 {input_file} 截取 {count} 个SNP到 {output_file}")
        return True
        
    except Exception as e:
        print(f"截取文件 {input_file} 时出错: {e}")
        return False

def main():
    parser = argparse.ArgumentParser(description='截取指定数量的SNP')
    parser.add_argument('--sample', required=True, help='样本文件路径')
    parser.add_argument('--yri', required=True, help='YRI参考文件路径')
    parser.add_argument('--chs', required=True, help='CHS参考文件路径')
    parser.add_argument('--output-dir', required=True, help='输出目录')
    parser.add_argument('--count', type=int, required=True, help='要截取的SNP数量')
    
    args = parser.parse_args()
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    # 截取所有三个文件
    files = [
        (args.sample, 'sample_subset.phased'),
        (args.yri, 'yri_subset.phased'),
        (args.chs, 'chs_subset.phased')
    ]
    
    success = True
    for input_file, output_name in files:
        output_file = os.path.join(args.output_dir, output_name)
        if not extract_snps(input_file, output_file, args.count):
            success = False
    
    return 0 if success else 1

if __name__ == '__main__':
    sys.exit(main())
