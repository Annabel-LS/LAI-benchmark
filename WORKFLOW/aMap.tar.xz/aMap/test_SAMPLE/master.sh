#!/bin/bash
# ==================================================
# aMAP 测试主控脚本 (Bash版本)
# 功能：通过用户交互依次执行：
#   1) 运行速度测试 (调用 speed_test.py)
#   2) 生成数据报告 (调用 generate_speed_report.py)
#   3) 删除测试中间数据
# ==================================================

# ---------- 配置区域 ----------
# 请根据实际路径修改以下变量
FULL_FILE="your_sample"   # 完整99人混合文件
AMAP_JAR="amap.jar"                       # amap.jar 路径
OUTPUT_DIR="your_results"           # 测试输出目录
SAMPLES="20 60 80 99"                     # 样本数量列表（空格分隔）

# Python脚本文件名（需与当前目录下的文件名一致）
SPEED_TEST_SCRIPT="speed_test.py"
REPORT_SCRIPT="generate_speed_report.py"
# ------------------------------

# 颜色定义（便于输出）
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 打印带颜色的信息
info() { echo -e "${GREEN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# 检查文件是否存在
check_file() {
    if [ ! -f "$1" ]; then
        error "文件不存在: $1"
    fi
}

# 检查目录是否存在
check_dir() {
    if [ ! -d "$1" ]; then
        error "目录不存在: $1"
    fi
}

# 1. 运行速度测试
run_test() {
    info "开始运行速度测试..."
    
    # 检查必要文件
    check_file "$FULL_FILE"
    check_file "$AMAP_JAR"
    check_file "$SPEED_TEST_SCRIPT"
    
    # 构建命令
    cmd="python $SPEED_TEST_SCRIPT --full_file $FULL_FILE --amap_jar $AMAP_JAR --samples $SAMPLES --output_dir $OUTPUT_DIR"
    info "执行命令: $cmd"
    
    eval $cmd
    if [ $? -eq 0 ]; then
        info "速度测试完成"
    else
        error "速度测试失败"
    fi
}

# 2. 生成数据报告
generate_report() {
    info "开始生成数据报告..."
    
    CSV_FILE="$OUTPUT_DIR/speed_results.csv"
    check_file "$CSV_FILE"
    check_file "$REPORT_SCRIPT"
    
    cmd="python $REPORT_SCRIPT $CSV_FILE --output_dir $OUTPUT_DIR"
    info "执行命令: $cmd"
    
    eval $cmd
    if [ $? -eq 0 ]; then
        info "报告生成完成"
    else
        error "报告生成失败"
    fi
}

# 3. 删除测试中间数据（保留最终结果）
clean_data() {
    info "开始清理测试中间数据..."
    
    if [ ! -d "$OUTPUT_DIR" ]; then
        warn "输出目录不存在: $OUTPUT_DIR，无需清理"
        return
    fi
    
    # 要删除的目录列表
    DEL_DIRS=(
        "$OUTPUT_DIR/temp_configs"
        "$OUTPUT_DIR/sample_files"
        "$OUTPUT_DIR/run_logs"
    )
    
    # 删除以 output_ 开头的子目录（aMAP 输出结果）
    for dir in "$OUTPUT_DIR"/output_*; do
        if [ -d "$dir" ]; then
            DEL_DIRS+=("$dir")
        fi
    done
    
    # 执行删除
    for dir in "${DEL_DIRS[@]}"; do
        if [ -e "$dir" ]; then
            rm -rf "$dir"
            info "已删除: $dir"
        fi
    done
    
    # 可选：删除空目录（但保留最终结果文件）
    info "清理完成，保留最终结果文件 (speed_results.csv, runtime_vs_samples.png, speed_report.txt)"
}

# 显示菜单
show_menu() {
    echo ""
    echo "=========================================="
    echo "   aMAP 测试主控菜单"
    echo "=========================================="
    echo "  1) 运行速度测试"
    echo "  2) 生成数据报告"
    echo "  3) 删除测试中间数据"
    echo "  4) 依次执行所有步骤 (1 -> 2 -> 3)"
    echo "  0) 退出"
    echo "=========================================="
    echo -n "请选择 [0-4]: "
}

# 主循环
main() {
    while true; do
        show_menu
        read choice
        case $choice in
            1)
                run_test
                ;;
            2)
                generate_report
                ;;
            3)
                clean_data
                ;;
            4)
                run_test
                generate_report
                clean_data
                ;;
            0)
                info "退出程序"
                exit 0
                ;;
            *)
                warn "无效输入，请重新选择"
                ;;
        esac
        echo ""  # 空行分隔
    done
}

# 启动主函数
main
