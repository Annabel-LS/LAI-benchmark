#!/usr/bin/env python3
"""
独立的速度测试报告生成脚本
读取速度结果CSV文件，生成折线图和文本报告
标签位置：20在上，60在下，80在上，99在下
"""

import pandas as pd
import matplotlib.pyplot as plt
import argparse
from pathlib import Path

# 设置matplotlib字体（使用系统可用的无衬线字体）
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans', 'Helvetica']
plt.rcParams['font.size'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['figure.dpi'] = 600

def generate_report(csv_file, output_dir=None):
    """
    根据速度结果CSV生成报告和图表
    :param csv_file: 速度结果CSV文件路径（必须包含 num_samples 和 time_seconds 列）
    :param output_dir: 输出目录（默认为CSV文件所在目录）
    """
    # 读取数据
    df = pd.read_csv(csv_file)
    
    # 检查必需的列
    required_cols = ['num_samples', 'time_seconds']
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"CSV文件缺少必需的列: {col}")
    
    # 按样本数排序
    df = df.sort_values('num_samples')
    
    # 确定输出目录
    if output_dir is None:
        output_dir = Path(csv_file).parent
    else:
        output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成折线图
    plt.figure(figsize=(8, 6))
    plt.plot(df['num_samples'], df['time_seconds'], 'o-', linewidth=2, markersize=8, color='#2E86AB')
    
    # 定义每个样本数的标签位置（True=上方，False=下方）
    # 顺序：20,60,80,99
    label_positions = {
        20: 'above',
        60: 'below',
        80: 'above',
        99: 'below'
    }
    
    # 计算偏移量（基于y值范围的百分比）
    y_min = df['time_seconds'].min()
    y_max = df['time_seconds'].max()
    y_range = y_max - y_min
    # 上方偏移为正（y + offset），下方偏移为负（y - offset）
    offset = y_range * 0.05 if y_range > 0 else 1.0
    
    for _, row in df.iterrows():
        x = row['num_samples']
        y = row['time_seconds']
        pos = label_positions.get(x, 'above')  # 默认上方
        
        if pos == 'above':
            y_text = y + offset
            va = 'bottom'
        else:
            y_text = y - offset
            va = 'top'
        
        plt.text(x, y_text, f'{y:.1f}s', 
                 ha='center', va=va, fontsize=9)
    
    plt.xlabel('Number of Samples', fontsize=12)
    plt.ylabel('Run Time (seconds)', fontsize=12)
    plt.title('aMAP Runtime vs. Number of Samples (gen9)', fontsize=14)
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.xticks(df['num_samples'])
    
    # 自动调整边距，防止标签超出画布
    plt.tight_layout()
    plot_path = output_dir / "runtime_vs_samples.png"
    plt.savefig(plot_path, dpi=600, bbox_inches='tight')
    print(f"图表已保存: {plot_path}")
    plt.close()
    
    # 生成文本报告（保持不变）
    report_lines = []
    report_lines.append("="*60)
    report_lines.append("aMAP Speed Test Report")
    report_lines.append("="*60)
    report_lines.append(f"Report generated from: {csv_file}")
    report_lines.append(f"Date: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append("")
    
    snp_count = "796678"
    window_params = "minWin=20, step=10, maxWin=200"
    if 'snp_count' in df.columns:
        snp_count = df['snp_count'].iloc[0]
    if 'window_params' in df.columns:
        window_params = df['window_params'].iloc[0]
    
    report_lines.append(f"SNP count: {snp_count}")
    report_lines.append(f"Window parameters: {window_params}")
    report_lines.append("")
    report_lines.append("Results:")
    report_lines.append(f"{'Samples':<10} {'Time (s)':<12} {'Time (min)':<12}")
    report_lines.append("-"*40)
    
    for _, row in df.iterrows():
        n = row['num_samples']
        t_sec = row['time_seconds']
        t_min = t_sec / 60
        report_lines.append(f"{n:<10} {t_sec:<12.2f} {t_min:<12.2f}")
    
    if len(df) >= 2:
        report_lines.append("")
        report_lines.append("Performance scaling:")
        base_time = df[df['num_samples'] == df['num_samples'].min()]['time_seconds'].values[0]
        for _, row in df.iterrows():
            n = row['num_samples']
            t = row['time_seconds']
            ratio = t / base_time
            report_lines.append(f"  {n} samples: {ratio:.2f}x relative to {df['num_samples'].min()} samples")
    
    report_path = output_dir / "speed_report.txt"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(report_lines))
    print(f"报告已保存: {report_path}")
    
    return df

def main():
    parser = argparse.ArgumentParser(description='Generate speed test report from CSV results')
    parser.add_argument('csv_file', help='Path to the speed results CSV file')
    parser.add_argument('--output_dir', help='Output directory for report and plot (default: same as CSV)')
    args = parser.parse_args()
    
    generate_report(args.csv_file, args.output_dir)

if __name__ == "__main__":
    main()
