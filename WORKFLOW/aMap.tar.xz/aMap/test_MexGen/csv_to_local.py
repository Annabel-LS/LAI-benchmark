import pandas as pd
import os

# 文件路径
original_file = 'gen_your_ancetry.txt'
result_file = 'gen_your_result.csv'

# 检查文件是否存在
print(f"检查文件是否存在:")
print(f"原文件: {os.path.exists(original_file)} - {original_file}")
print(f"结果文件: {os.path.exists(result_file)} - {result_file}")

if not os.path.exists(original_file):
    print(f"错误: 找不到原文件 {original_file}")
    exit(1)
    
if not os.path.exists(result_file):
    print(f"错误: 找不到结果文件 {result_file}")
    exit(1)

try:
    # 读取原文件（TAB分隔）
    original_df = pd.read_csv(original_file, sep='\t')
    print(f"原文件形状：{original_df.shape}")
    print(f"原文件列名：{original_df.columns.tolist()[:10]}...")  # 只显示前10个列名
except Exception as e:
    print(f"读取原文件时出错: {e}")
    print("尝试其他分隔符...")
    original_df = pd.read_csv(original_file)  # 尝试默认分隔符
    print(f"使用默认分隔符读取成功，形状：{original_df.shape}")

try:
    # 读取结果文件（逗号分隔）
    result_df = pd.read_csv(result_file, header=None)
    print(f"\n结果文件形状：{result_df.shape}")
except Exception as e:
    print(f"读取结果文件时出错: {e}")
    print("尝试用不同的方式读取...")
    # 尝试用不同的方式读取
    with open(result_file, 'r') as f:
        first_line = f.readline().strip()
    print(f"结果文件第一行: {first_line[:100]}...")
    
    # 尝试用纯文本读取
    result_df = pd.read_csv(result_file, header=None, engine='python')
    print(f"使用python引擎读取成功，形状：{result_df.shape}")

# 验证数据维度是否匹配
if result_df.shape[0] != original_df.shape[0]:
    print(f"警告：行数不匹配！原文件有{original_df.shape[0]}行，结果文件有{result_df.shape[0]}行")
    print("将使用较小行数进行截断...")
    min_rows = min(result_df.shape[0], original_df.shape[0])
    original_df = original_df.iloc[:min_rows]
    result_df = result_df.iloc[:min_rows]

# 假设原文件的前两列是ID和POS
id_col = original_df.columns[0]
pos_col = original_df.columns[1]

print(f"\n假设ID列: {id_col}")
print(f"假设POS列: {pos_col}")

# 计算原文件中的样本数
num_original_columns = original_df.shape[1] - 2  # 减去ID和POS列
num_samples = num_original_columns // 2

# 计算结果文件中的样本数（每两列一个样本）
num_result_samples = result_df.shape[1] // 2

print(f"\n原文件中非ID/POS列数: {num_original_columns}")
print(f"原文件中的样本数（每个样本2列）: {num_samples}")
print(f"结果文件中的样本数（每个样本2列）: {num_result_samples}")

if num_samples != num_result_samples:
    print(f"警告：样本数不匹配！原文件有{num_samples}个样本，结果文件有{num_result_samples}个样本")
    print(f"将使用较小的样本数: {min(num_samples, num_result_samples)}")
    num_samples = min(num_samples, num_result_samples)

# 创建新的DataFrame，保留原文件的ID和POS列
new_df = pd.DataFrame()
new_df[id_col] = original_df[id_col]
new_df[pos_col] = original_df[pos_col]

# 将结果文件的数据按原文件样本列的顺序填充
result_col_idx = 0
for i in range(2, 2 + num_samples * 2, 2):  # 确保不超出范围
    if i < original_df.shape[1] and i+1 < original_df.shape[1]:
        # 获取原文件中的列名
        hap1_col = original_df.columns[i]
        hap2_col = original_df.columns[i+1]
        
        # 将结果文件的数据赋值到新DataFrame中
        new_df[hap1_col] = result_df[result_col_idx]
        new_df[hap2_col] = result_df[result_col_idx + 1]
        
        result_col_idx += 2
        
        print(f"映射: 结果文件列{result_col_idx-2},{result_col_idx-1} -> {hap1_col},{hap2_col}")
    else:
        print(f"警告: 原文件列索引{i}或{i+1}超出范围")
        break

# 保存为新的文件（TAB分隔，与原文件一致）
output_file = 'gen100.local'
new_df.to_csv(output_file, sep='\t', index=False)

print(f"\n转换完成！已保存为 {output_file}")
print(f"新文件形状：{new_df.shape}")
print(f"处理了 {num_samples} 个样本")

# 显示前几行预览
print("\n前5行数据预览（前5列）：")
print(new_df.iloc[:5, :5])
