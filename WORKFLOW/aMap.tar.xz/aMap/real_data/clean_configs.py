#!/usr/bin/env python3
import os
import sys
import glob

def clean_all_configs(base_dir):
    """删除所有生成的配置文件"""
    print("开始清理所有配置文件...")
    
    # 查找所有 config_*.xml 文件
    pattern = os.path.join(base_dir, "chr*", "*_Group", "config_*.xml")
    config_files = glob.glob(pattern)
    
    if not config_files:
        print("未找到任何配置文件")
        return
    
    print(f"找到 {len(config_files)} 个配置文件:")
    for f in config_files:
        print(f"  - {f}")
    
    # 确认删除
    response = input("\n确认删除以上所有配置文件? (y/n): ")
    if response.lower() == 'y':
        for f in config_files:
            os.remove(f)
            print(f"  已删除: {f}")
        print(f"\n✅ 已删除 {len(config_files)} 个配置文件")
    else:
        print("取消删除操作")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python clean_configs.py <base_dir>")
        sys.exit(1)
    
    base_dir = sys.argv[1]
    clean_all_configs(base_dir)
