import subprocess
import sys
import os
import logging
from datetime import datetime
from config import LOG_DIR

# 定义步骤菜单
steps = [
    {"id": "1", "name": "1_copy_and_init.py", "desc": "复制文件并初始化目录"},
    {"id": "2", "name": "2_generate_config.py", "desc": "生成 aMAP 配置文件"},
    {"id": "3", "name": "3_run_amap.py", "desc": "运行 aMAP 软件 (耗时较长)"},
    {"id": "4", "name": "4_convert_results.py", "desc": "转换结果为 local 格式"},
    {"id": "5", "name": "clean_configs.py", "desc": "清理所有配置文件"},
    {"id": "6", "name": "copy_missing_chs_yri_ceu.py", "desc": "复制缺失的 CHS_YRI_CEU 文件"},
]
s
def setup_logger():
    """配置日志记录器"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"{timestamp}_main_pipeline.log"
    log_path = os.path.join(LOG_DIR, log_filename)

    logger = logging.getLogger("PipelineMain")
    logger.setLevel(logging.INFO)

    if logger.hasHandlers():
        logger.handlers.clear()
        
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s - %(message)s', datefmt='%H:%M:%S')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger, log_path

def run_step(script_name, logger):
    """运行指定的脚本"""
    logger.info(f"")
    logger.info(f"▶ 正在执行: {script_name}")
    logger.info(f"{'='*50}")

    try:
        if script_name.endswith('.py'):
            cmd = [sys.executable, script_name]
        elif script_name.endswith('.sh'):
            cmd = ['bash', script_name]
        else:
            logger.error(f"未知脚本类型: {script_name}")
            return False
        
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        if process.stdout:
            for line in process.stdout:
                clean_line = line.rstrip()
                print(clean_line)
                logger.info(clean_line)
        
        process.wait()
        
        if process.returncode == 0:
            logger.info(f"✅ {script_name} 执行成功。")
            return True
        else:
            logger.error(f"❌ {script_name} 执行失败 (返回值 {process.returncode})。")
            return False
            
    except Exception as e:
        logger.error(f"❌ 发生系统错误: {str(e)}")
        return False

def show_menu(logger):
    logger.info("="*40)
    logger.info("  aMAP 自动化分析流程")
    logger.info("="*40)
    for step in steps:
        logger.info(f"[{step['id']}] {step['desc']}")
    logger.info("[q] 退出程序")
    logger.info("="*40)

def main():
    logger, log_path = setup_logger()

    logger.info("欢迎使用 aMAP 自动化分析流程")
    logger.info(f"本次会话日志保存于: {log_path}")

    while True:
        show_menu(logger)
        
        choice = input("\n请输入指令编号: ").strip().lower()
        logger.info(f"用户输入: {choice}")
        
        if choice == 'q':
            logger.info("退出程序。")
            break
            
        selected_step = next((step for step in steps if step['id'] == choice), None)
        
        if selected_step:
            success = run_step(selected_step['name'], logger)
            if success:
                logger.info(f"👉 步骤 [{choice}] 已完成，等待下一个指令...")
        else:
            logger.warning("无效指令，请输入 1-6 或 q")

if __name__ == "__main__":
    main()
