#!/usr/bin/env python3
import os
import shutil
from config import BASE_DIR, SOURCE_DIR, CHROMOSOMES

def copy_correct_files():
    for chr_num in CHROMOSOMES:
        chr_str = f"chr{chr_num}"
        src_file = os.path.join(SOURCE_DIR, chr_str, f"CHS_CEU_YRI_{chr_str}.phased")
        if not os.path.exists(src_file):
            print(f"警告: 源文件不存在 {src_file}，跳过")
            continue
        
        control_dir = os.path.join(BASE_DIR, chr_str, "Control_Group")
        experiment_dir = os.path.join(BASE_DIR, chr_str, "Experiment_Group")
        os.makedirs(control_dir, exist_ok=True)
        os.makedirs(experiment_dir, exist_ok=True)
        
        # 目标文件名固定为 CHS_YRI_CEU_*.phased
        target_filename = f"CHS_YRI_CEU_{chr_str}.phased"
        dst_control = os.path.join(control_dir, target_filename)
        dst_exp = os.path.join(experiment_dir, target_filename)
        
        shutil.copy2(src_file, dst_control)
        shutil.copy2(src_file, dst_exp)
        print(f"已复制正确文件: {src_file} -> {dst_control}")
        print(f"已复制正确文件: {src_file} -> {dst_exp}")

    print("所有正确文件复制完成。")

if __name__ == "__main__":
    copy_correct_files()
