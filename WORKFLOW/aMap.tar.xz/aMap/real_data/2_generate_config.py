#!/usr/bin/env python3
import os
import sys
from config import BASE_DIR, CHROMOSOMES, LOG_FILE

def log(msg):
    with open(LOG_FILE, 'a') as f:
        f.write(f"[CONFIG] {msg}\n")
    print(msg)

def count_snps_skip_header(file_path):
    """统计真实 SNP 数量（跳过标题行）"""
    if not os.path.exists(file_path):
        return 0
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            # 跳过第一行（标题行）
            f.readline()
            count = 0
            for line in f:
                if line.strip():
                    count += 1
            return count
    except Exception as e:
        log(f"统计 SNP 失败: {e}")
        return 0

def generate_control_config(base_path, chr_num, snp_count):
    """
    生成对照组配置 (参考群体: CHS + CEU + YRI)
    使用绝对路径，符合 aMAP 模板格式
    """
    chr_str = f"chr{chr_num}"
    output_dir = os.path.join(base_path, "Control_Group")
    
    # 构建文件绝对路径
    sample_file = os.path.join(output_dir, f"your_asw_chr{chr_num}.phased")
    chs_file = os.path.join(output_dir, f"your_chs_chr{chr_num}.phased")
    ceu_file = os.path.join(output_dir, f"your_ceu_chr{chr_num}.phased")
    yri_file = os.path.join(output_dir, f"your_yri_chr{chr_num}.phased")
    
    config_content = f"""<?xml version="1.0" ?>
<case>
\t<positionCount>{snp_count}</positionCount>
\t<populations>
\t\t<population id="sample">
\t\t\t<type>sample</type>
\t\t\t<ordinal>0</ordinal>
\t\t\t<fileName>{sample_file}</fileName>
\t\t</population>
\t\t<population id="chs">
\t\t\t<type>reference</type>
\t\t\t<ordinal>1</ordinal>
\t\t\t<fileName>{chs_file}</fileName>
\t\t</population>
\t\t<population id="ceu">
\t\t\t<type>reference</type>
\t\t\t<ordinal>2</ordinal>
\t\t\t<fileName>{ceu_file}</fileName>
\t\t</population>
\t\t<population id="yri">
\t\t\t<type>reference</type>
\t\t\t<ordinal>3</ordinal>
\t\t\t<fileName>{yri_file}</fileName>
\t\t</population>
\t</populations>
\t<outputDir>{output_dir}</outputDir>
\t<minWinSize>100</minWinSize>
\t<winStep>50</winStep>
\t<maxWinSize>200</maxWinSize>
</case>"""
    
    config_path = os.path.join(output_dir, f"config_{chr_str}.xml")
    with open(config_path, 'w') as f:
        f.write(config_content)
    return config_path

def generate_experiment_config(base_path, chr_num, snp_count):
    """
    生成实验组配置 (参考群体: CHS + CEU，不含 YRI)
    使用绝对路径，符合 aMAP 模板格式
    """
    chr_str = f"chr{chr_num}"
    output_dir = os.path.join(base_path, "Experiment_Group")
    
    # 构建文件绝对路径
    sample_file = os.path.join(output_dir, f"your_asw_chr{chr_num}.phased")
    chs_file = os.path.join(output_dir, f"your_chs_chr{chr_num}.phased")
    ceu_file = os.path.join(output_dir, f"your_ceu_chr{chr_num}.phased")
    
    config_content = f"""<?xml version="1.0" ?>
<case>
\t<positionCount>{snp_count}</positionCount>
\t<populations>
\t\t<population id="sample">
\t\t\t<type>sample</type>
\t\t\t<ordinal>0</ordinal>
\t\t\t<fileName>{sample_file}</fileName>
\t\t</population>
\t\t<population id="chs">
\t\t\t<type>reference</type>
\t\t\t<ordinal>1</ordinal>
\t\t\t<fileName>{chs_file}</fileName>
\t\t</population>
\t\t<population id="ceu">
\t\t\t<type>reference</type>
\t\t\t<ordinal>2</ordinal>
\t\t\t<fileName>{ceu_file}</fileName>
\t\t</population>
\t</populations>
\t<outputDir>{output_dir}</outputDir>
\t<minWinSize>100</minWinSize>
\t<winStep>50</winStep>
\t<maxWinSize>200</maxWinSize>
</case>"""
    
    config_path = os.path.join(output_dir, f"config_{chr_str}.xml")
    with open(config_path, 'w') as f:
        f.write(config_content)
    return config_path

def main():
    log(">>> 开始生成配置文件（符合 aMAP 模板格式，实验组为 CHS+CEU）")
    
    for chr_num in CHROMOSOMES:  # CHROMOSOMES 应为 range(1, 23)
        chr_str = f"chr{chr_num}"
        base_path = os.path.join(BASE_DIR, chr_str)
        
        # 检查目录是否存在
        if not os.path.exists(base_path):
            log(f"警告: 目录 {base_path} 不存在，跳过")
            continue
        
        # 样本文件路径（用于统计 SNP 数量，从 Control_Group 中取）
        sample_file = os.path.join(base_path, "Control_Group", f"your_asw_chr{chr_num}.phased")
        
        if not os.path.exists(sample_file):
            log(f"错误: 找不到 {sample_file}，跳过 {chr_str}")
            continue
        
        # 统计 SNP 数量
        snp_count = count_snps_skip_header(sample_file)
        log(f"{chr_str} 真实 SNP 数量: {snp_count}")
        
        if snp_count == 0:
            log(f"错误: {chr_str} SNP 数量为 0，跳过")
            continue
        
        # 生成配置文件
        control_cfg = generate_control_config(base_path, chr_num, snp_count)
        experiment_cfg = generate_experiment_config(base_path, chr_num, snp_count)
        
        log(f"✅ {chr_str} 配置生成完毕")
        log(f"   对照组: {control_cfg}")
        log(f"   实验组: {experiment_cfg}")
    
    log("所有染色体配置文件生成完毕")

if __name__ == "__main__":
    main()
