import os
import shutil
from config import BASE_DIR, SOURCE_DIR, CHROMOSOMES, LOG_FILE

def log(msg):
    with open(LOG_FILE, 'a') as f:
        f.write(f"[COPY] {msg}\n")
    print(msg)

def main():
    log("开始复制文件流程 (Chr 1-22, 修正小写)")
    try:
        for chr_num in CHROMOSOMES:  # CHROMOSOMES 现在是 range(1, 23)
            chr_str = f"chr{chr_num}"
            source_chr_path = os.path.join(SOURCE_DIR, chr_str)

            # 创建项目结构
            project_chr_path = os.path.join(BASE_DIR, chr_str)
            os.makedirs(project_chr_path, exist_ok=True)
            
            control_dir = os.path.join(project_chr_path, "Control_Group")
            experiment_dir = os.path.join(project_chr_path, "Experiment_Group")
            os.makedirs(control_dir, exist_ok=True)
            os.makedirs(experiment_dir, exist_ok=True)
            
            # 定义需要复制的文件 (修正为全小写 chr)
            files_to_copy = [
                f"your_asw_chr{chr_num}.phased",
                f"your_chs_chr{chr_num}.phased",
                f"your_ceu_chr{chr_num}.phased",
                f"your_yri_chr{chr_num}.phased"
            ]
            
            for file_name in files_to_copy:
                src_file = os.path.join(source_chr_path, file_name)
                if os.path.exists(src_file):
                    # 复制到对照组
                    shutil.copy(src_file, os.path.join(control_dir, file_name))
                    # 复制到实验组
                    shutil.copy(src_file, os.path.join(experiment_dir, file_name))
                    log(f"复制 {file_name} 完成")
                else:
                    log(f"警告: 找不到源文件 {src_file}")
                    
        log("文件复制流程结束")
    except Exception as e:
        log(f"错误: {str(e)}")

if __name__ == "__main__":
    main()
