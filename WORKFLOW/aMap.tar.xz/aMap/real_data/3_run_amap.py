#!/usr/bin/env python3
import os
import subprocess
import glob
import time
import shutil
from config import BASE_DIR, CHROMOSOMES, LOG_FILE, AMAP_JAR

def log(msg):
    with open(LOG_FILE, 'a') as f:
        f.write(f"[RUN] {msg}\n")
    print(msg)

def ensure_output_dir_in_config(config_path, target_dir):
    """
    确保配置文件中有 <outputDir> 标签并设置为 target_dir。
    如果没有，则添加；如果有，则替换。
    """
    with open(config_path, 'r') as f:
        content = f.read()
    
    import re
    # 查找 <outputDir>...</outputDir>
    pattern = r'(<outputDir>).*?(</outputDir>)'
    if re.search(pattern, content, re.DOTALL):
        new_content = re.sub(pattern, rf'\1{target_dir}\2', content, flags=re.DOTALL)
    else:
        # 没有找到，在 </case> 前插入
        new_content = content.replace('</case>', f'\t<outputDir>{target_dir}</outputDir>\n</case>')
    
    if new_content != content:
        with open(config_path, 'w') as f:
            f.write(new_content)
        log(f"  已更新配置文件中的 outputDir 为: {target_dir}")
    else:
        log(f"  配置文件中的 outputDir 已是: {target_dir}")

def run_amap_and_rename(config_path, group_name, chr_num):
    chr_str = f"chr{chr_num}"
    work_dir = os.path.dirname(config_path)
    os.makedirs(work_dir, exist_ok=True)
    
    # 修改配置文件中的 outputDir
    ensure_output_dir_in_config(config_path, work_dir)
    
    # 记录运行前该目录下的所有 CSV 文件（用于后续对比）
    before_csv = set(glob.glob(os.path.join(work_dir, "*.csv")))
    
    log(f"正在运行: {chr_str} - {group_name}")
    log(f"  配置文件: {config_path}")
    log(f"  工作目录: {work_dir}")
    
    original_cwd = os.getcwd()
    os.chdir(work_dir)
    
    try:
        cmd = ['java', '-jar', AMAP_JAR, config_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            log(f"❌ 失败: {chr_str} {group_name}")
            if result.stderr:
                log(f"错误信息: {result.stderr[:500]}")
            os.chdir(original_cwd)
            return False
        
        log(f"✅ 成功: {chr_str} {group_name}")
        time.sleep(2)  # 等待文件写入
        
        # 查找新生成的 CSV
        after_csv = set(glob.glob(os.path.join(work_dir, "*.csv")))
        new_csv = after_csv - before_csv
        
        if new_csv:
            src = list(new_csv)[0]
            dst = os.path.join(work_dir, f"{chr_str}_result_{group_name}.csv")
            os.rename(src, dst)
            log(f"   ✅ 结果已保存: {dst}")
        else:
            # 如果没有新文件，则取目录中最新的 CSV（容错）
            all_csv = glob.glob(os.path.join(work_dir, "*.csv"))
            if all_csv:
                latest = max(all_csv, key=os.path.getmtime)
                dst = os.path.join(work_dir, f"{chr_str}_result_{group_name}.csv")
                os.rename(latest, dst)
                log(f"   ✅ 结果已保存（使用最新 CSV）: {dst}")
            else:
                log(f"   ⚠️ 警告: 在 {work_dir} 中未找到任何 CSV 文件")
                # 输出当前目录内容帮助调试
                files = os.listdir(work_dir)
                log(f"      目录内容: {files}")
                os.chdir(original_cwd)
                return False
        
        os.chdir(original_cwd)
        return True
        
    except Exception as e:
        log(f"❌ 异常: {str(e)}")
        os.chdir(original_cwd)
        return False

def main():
    log("开始运行 aMAP (增强目录切换版)")
    if not os.path.exists(AMAP_JAR):
        log(f"错误: 找不到 amap.jar: {AMAP_JAR}")
        return
    
    for chr_num in CHROMOSOMES:
        chr_str = f"chr{chr_num}"
        chr_path = os.path.join(BASE_DIR, chr_str)
        if not os.path.exists(chr_path):
            log(f"警告: 目录 {chr_path} 不存在，跳过")
            continue
        
        control_cfg = os.path.join(chr_path, "Control_Group", f"config_{chr_str}.xml")
        exp_cfg = os.path.join(chr_path, "Experiment_Group", f"config_{chr_str}.xml")
        
        if os.path.exists(control_cfg):
            run_amap_and_rename(control_cfg, "control", chr_num)
        else:
            log(f"跳过对照组: 配置文件不存在 {control_cfg}")
        
        if os.path.exists(exp_cfg):
            run_amap_and_rename(exp_cfg, "experiment", chr_num)
        else:
            log(f"跳过实验组: 配置文件不存在 {exp_cfg}")
    
    log("所有染色体运行及重命名完毕")

if __name__ == "__main__":
    main()
