import os

# --- 路径配置 (请确保这些路径正确) ---
BASE_DIR = r"your_project_url"       # 你的项目总文件夹
SOURCE_DIR = r"your_real_data_urlS"  

# --- 日志配置 ---
# 在 BASE_DIR 下创建一个 logs 文件夹专门存日志
LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True) # 确保文件夹存在

# 统一使用 LOG_FILE 作为变量名，指向主日志文件
# 注意：main.py 会在运行时动态生成带时间戳的文件名覆盖这个路径，
# 但子脚本只需要引用这个变量来确保日志目录存在即可，或者我们直接用它作为通用日志路径
LOG_FILE = os.path.join(LOG_DIR, "pipeline.log")

# 软件路径
AMAP_JAR = os.path.join(BASE_DIR, "amap.jar")

# 染色体范围
CHROMOSOMES = range(1, 23) # 1-22
