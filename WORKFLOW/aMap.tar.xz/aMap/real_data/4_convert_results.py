#!/usr/bin/env python3
import os
import pandas as pd
from config import BASE_DIR, CHROMOSOMES, LOG_FILE

def log(msg):
    with open(LOG_FILE, 'a') as f:
        f.write(f"[CONVERT] {msg}\n")
    print(msg)

def convert_csv_to_local(original_phased, result_csv, output_local):
    """
    将 aMAP 输出的 CSV 结果转换为 local 格式。
    参数：
        original_phased: 原始 phased 文件（包含 ID, POS 及所有样本的单倍型列）
        result_csv: aMAP 输出的 CSV 文件（每两列为一个样本的单倍型，与原始文件样本顺序一致）
        output_local: 输出的 local 文件路径
    """
    if not os.path.exists(original_phased):
        log(f"错误: 找不到原始文件 {original_phased}")
        return False
    if not os.path.exists(result_csv):
        log(f"错误: 找不到结果文件 {result_csv}")
        return False

    try:
        # 读取原始 phased 文件（制表符分隔，通常第一行为表头）
        original_df = pd.read_csv(original_phased, sep='\t')
        log(f"  原始文件形状: {original_df.shape}")

        # 读取结果 CSV（无表头，逗号分隔）
        result_df = pd.read_csv(result_csv, header=None)
        log(f"  结果文件形状: {result_df.shape}")

        # 检查行数是否匹配
        if result_df.shape[0] != original_df.shape[0]:
            log(f"  警告: 行数不匹配！原始文件 {original_df.shape[0]} 行，结果文件 {result_df.shape[0]} 行，将截断至较小行数")
            min_rows = min(result_df.shape[0], original_df.shape[0])
            original_df = original_df.iloc[:min_rows]
            result_df = result_df.iloc[:min_rows]

        # 假设原始文件的前两列是 ID 和 POS
        id_col = original_df.columns[0]
        pos_col = original_df.columns[1]

        # 计算原始文件中的样本数（每样本两列，即两个单倍型）
        num_original_cols = original_df.shape[1] - 2
        num_samples_original = num_original_cols // 2

        # 计算结果文件中的样本数
        num_result_cols = result_df.shape[1]
        num_samples_result = num_result_cols // 2

        if num_samples_original != num_samples_result:
            log(f"  警告: 样本数不匹配！原始文件 {num_samples_original} 个样本，结果文件 {num_samples_result} 个样本")
            num_samples = min(num_samples_original, num_samples_result)
        else:
            num_samples = num_samples_original

        # 创建新的 DataFrame，保留 ID 和 POS
        new_df = pd.DataFrame()
        new_df[id_col] = original_df[id_col]
        new_df[pos_col] = original_df[pos_col]

        # 按样本顺序填充结果数据
        result_col_idx = 0
        for i in range(2, 2 + num_samples * 2, 2):
            if i < original_df.shape[1] and i+1 < original_df.shape[1]:
                hap1_col = original_df.columns[i]
                hap2_col = original_df.columns[i+1]
                new_df[hap1_col] = result_df[result_col_idx]
                new_df[hap2_col] = result_df[result_col_idx + 1]
                result_col_idx += 2
            else:
                break

        # 保存为 local 文件（制表符分隔，不保存索引）
        new_df.to_csv(output_local, sep='\t', index=False)
        log(f"  ✅ 转换成功: {output_local}")
        return True

    except Exception as e:
        log(f"  ❌ 转换失败: {str(e)}")
        return False

def main():
    log("开始批量转换结果文件为 local 格式")

    for chr_num in CHROMOSOMES:
        chr_str = f"chr{chr_num}"
        chr_path = os.path.join(BASE_DIR, chr_str)
        if not os.path.exists(chr_path):
            log(f"警告: 目录 {chr_path} 不存在，跳过")
            continue

        # 原始 phased 文件路径（位于 Control_Group 子目录下，作为模板）
        original_phased = os.path.join(chr_path, "Control_Group", f"asw12_chr{chr_num}.phased")
        if not os.path.exists(original_phased):
            log(f"警告: 找不到原始文件 {original_phased}，跳过染色体 {chr_str}")
            continue

        # 对照组转换
        control_csv = os.path.join(chr_path, "Control_Group.csv")
        if os.path.exists(control_csv):
            control_local = os.path.join(chr_path, "Control_Group.local")
            log(f"处理染色体 {chr_str} 对照组")
            convert_csv_to_local(original_phased, control_csv, control_local)
        else:
            log(f"警告: 找不到对照组结果文件 {control_csv}")

        # 实验组转换
        experiment_csv = os.path.join(chr_path, "Experiment_Group.csv")
        if os.path.exists(experiment_csv):
            experiment_local = os.path.join(chr_path, "Experiment_Group.local")
            log(f"处理染色体 {chr_str} 实验组")
            convert_csv_to_local(original_phased, experiment_csv, experiment_local)
        else:
            log(f"警告: 找不到实验组结果文件 {experiment_csv}")

    log("所有转换任务完成")

if __name__ == "__main__":
    main()
